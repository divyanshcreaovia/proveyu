import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <footer class="footer">
      <div class="container footer-content">
        <div class="footer-grid">
          <!-- Brand Column -->
          <div class="footer-brand">
            <div class="logo-group">
              <div class="logo-shield">
                <svg width="20" height="24" viewBox="0 0 24 28" fill="none">
                  <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
                  <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
                </svg>
              </div>
              <span class="logo-title">PROVEYU</span>
            </div>
            <p class="brand-desc">
              Skill Speaks Louder Than a Resume. Replacing the unverified resume with invigilated, physical-centre skill proof for merit-based hiring.
            </p>
            <div class="trust-badge">
              <span class="shield-icon">🛡️</span>
              <span>Supervised In-Person Proctoring Network</span>
            </div>
          </div>

          <!-- Candidates Links -->
          <div class="footer-col">
            <h4 class="col-title">For Candidates</h4>
            <ng-container *ngIf="!authService.isLoggedIn() || authService.currentRole() !== 'candidate'; else candidateAuthFooter">
              <a routerLink="/register/candidate">Get Skill Verified</a>
              <a routerLink="/fresher-model">Universal Fresher Test</a>
              <a routerLink="/login">Candidate Login</a>
              <a routerLink="/how-it-works">Exam Center Locations</a>
              <a routerLink="/why-in-person">Admit Card Process</a>
            </ng-container>

            <ng-template #candidateAuthFooter>
              <a routerLink="/dashboard/candidate">My Dashboard</a>
              <a routerLink="/candidate/passport">Skill Passport</a>
              <a routerLink="/candidate/book-slot">Book Exam Slot</a>
              <a routerLink="/how-it-works">Exam Center Locations</a>
              <a routerLink="/why-in-person">Invigilation Protocol</a>
            </ng-template>
          </div>

          <!-- Recruiters Links -->
          <div class="footer-col">
            <h4 class="col-title">For Recruiters & Agencies</h4>
            <ng-container *ngIf="!authService.isLoggedIn() || authService.currentRole() === 'candidate'; else recruiterAuthFooter">
              <a routerLink="/register/recruiter">Browse Verified Talent</a>
              <a routerLink="/register/recruiter">Placement Agency Portal</a>
              <a routerLink="/login">Recruiter Login</a>
              <a routerLink="/why-in-person">Anti-Cheating Architecture</a>
            </ng-container>

            <ng-template #recruiterAuthFooter>
              <a routerLink="/dashboard/recruiter">Recruiter Dashboard</a>
              <a routerLink="/recruiter/verifiedtalents">Verified Candidates</a>
              <a routerLink="/recruiter/invites">Direct Candidate Invites</a>
              <a routerLink="/why-in-person">Anti-Cheating Security</a>
            </ng-template>
          </div>

          <!-- Domains & Tracks -->
          <div class="footer-col">
            <h4 class="col-title">Verification Tracks</h4>
            <a routerLink="/fresher-model">Universal Fresher Competency</a>
            <a routerLink="/register/candidate">Java Backend (Spring Boot)</a>
            <a routerLink="/register/candidate">QA & Automation Testing</a>
            <a routerLink="/register/candidate">Python Backend & Data</a>
            <a routerLink="/register/candidate">Web Development (Full Stack)</a>
          </div>
        </div>

        <div class="footer-bottom">
          <p>© 2026 Proveyu Inc. All rights reserved.</p>
          <div class="legal-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Centre Security Protocol</a>
          </div>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background: #111827;
      color: #9CA3AF;
      padding: 4rem 0 2rem 0;
      border-top: 1px solid #1F2937;
      font-size: 0.9rem;
    }
    .footer-grid {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 3rem;
      margin-bottom: 3rem;
    }
    .logo-group {
      display: flex;
      align-items: center;
      gap: 0.65rem;
      margin-bottom: 1rem;
    }
    .logo-shield {
      width: 34px;
      height: 34px;
      background: rgba(15, 122, 92, 0.2);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .logo-title {
      font-family: 'Outfit', sans-serif;
      font-weight: 800;
      font-size: 1.4rem;
      color: #FFFFFF;
      letter-spacing: 0.5px;
    }
    .brand-desc {
      line-height: 1.6;
      margin-bottom: 1.25rem;
      color: #9CA3AF;
      max-width: 340px;
    }
    .trust-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(15, 122, 92, 0.15);
      border: 1px solid rgba(15, 122, 92, 0.3);
      color: #34D399;
      padding: 0.4rem 0.85rem;
      border-radius: 9999px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    .col-title {
      color: #FFFFFF;
      font-size: 1rem;
      margin-bottom: 1.25rem;
      font-weight: 700;
    }
    .footer-col {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }
    .footer-col a {
      color: #9CA3AF;
      transition: color 0.15s;
    }
    .footer-col a:hover {
      color: #34D399;
    }
    .footer-bottom {
      border-top: 1px solid #1F2937;
      padding-top: 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 1rem;
      font-size: 0.85rem;
    }
    .legal-links {
      display: flex;
      gap: 1.5rem;
    }
    .legal-links a {
      color: #9CA3AF;
    }
    .legal-links a:hover {
      color: #FFFFFF;
    }

    @media (max-width: 900px) {
      .footer-grid {
        grid-template-columns: 1fr 1fr;
      }
    }
    @media (max-width: 600px) {
      .footer-grid {
        grid-template-columns: 1fr;
      }
      .footer-bottom {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  `]
})
export class FooterComponent {
  authService = inject(AuthService);
}
