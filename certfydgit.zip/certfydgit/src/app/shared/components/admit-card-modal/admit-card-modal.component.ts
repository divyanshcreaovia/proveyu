import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdmitCard } from '../../../core/models/deservify.models';

@Component({
  selector: 'app-admit-card-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeOnBackdrop($event)">
      <div class="modal-content admit-card-content">
        <!-- Header -->
        <div class="modal-top">
          <div class="modal-title-group">
            <span class="badge badge-teal">Official Examination Admit Card</span>
            <h2>Supervised Physical Test Hall Ticket</h2>
          </div>
          <button (click)="close.emit()" class="close-btn">&times;</button>
        </div>

        <div class="admit-body-scroll">
          <!-- Admit Card Body -->
          <div class="admit-ticket-box" id="printable-admit-card">
            <div class="ticket-header">
              <div class="ticket-logo">
                <svg width="24" height="28" viewBox="0 0 24 28" fill="none">
                  <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
                  <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
                </svg>
                <div class="brand-name">PROVEYU VERIFICATION</div>
              </div>
              <div class="ticket-status">
                <span class="status-verified">STATUS: VERIFIED & CONFIRMED</span>
              </div>
            </div>

            <div class="ticket-body" *ngIf="admitCard">
              <!-- Left Info Column -->
              <div class="candidate-details">
                <div class="detail-grid">
                  <div class="info-block">
                    <span class="label">CANDIDATE NAME</span>
                    <span class="value main-name">{{ admitCard.candidateName }}</span>
                  </div>
                  <div class="info-block">
                    <span class="label">ROLL NUMBER</span>
                    <span class="value roll-highlight">{{ admitCard.rollNumber }}</span>
                  </div>
                  <div class="info-block">
                    <span class="label">VERIFICATION TRACK</span>
                    <span class="value">{{ admitCard.trackName }}</span>
                  </div>
                  <div class="info-block">
                    <span class="label">CONTACT EMAIL / PHONE</span>
                    <span class="value">{{ admitCard.email }} | {{ admitCard.phone }}</span>
                  </div>
                  <div class="info-block full-width">
                    <span class="label">TEST CENTRE LOCATION</span>
                    <span class="value centre-name">{{ admitCard.centerName }}</span>
                    <span class="sub-value">{{ admitCard.centerAddress }}</span>
                  </div>
                </div>
              </div>

              <!-- Right QR & Photo Column -->
              <div class="candidate-photo-qr">
                <div class="photo-placeholder">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200" alt="Candidate Photo">
                  <span class="photo-tag">GOVT ID MATCHED</span>
                </div>
                <div class="qr-placeholder">
                  <img [src]="admitCard.qrCodeMock" alt="Verification QR Code">
                  <span class="qr-tag">SCAN AT CENTRE GATE</span>
                </div>
              </div>
            </div>

            <!-- Guidelines Box -->
            <div class="instructions-box">
              <h4>📋 Mandatory Invigilation Protocol</h4>
              <ul>
                <li>Bring physical original government ID proof (Aadhaar / PAN / Voter ID) matching registration details.</li>
                <li>Calculators, smartphones, smartwatches, and relay devices are strictly prohibited inside the lab hall.</li>
                <li>Biometric fingerprint scan and CCTV photo identity log will be captured prior to seat allocation.</li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Actions -->
        <div class="admit-actions">
          <button (click)="printCard()" class="btn btn-secondary">
            <span>🖨️ Print / Download PDF</span>
          </button>
          <button (click)="close.emit()" class="btn btn-primary">
            <span>Done</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .admit-card-content {
      max-width: 780px;
      width: 100%;
      max-height: calc(100vh - 3rem);
      display: flex;
      flex-direction: column;
    }
    .modal-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.25rem 1.75rem;
      border-bottom: 1px solid var(--border-color);
      background: var(--bg-card);
      color: var(--heading);
      flex-shrink: 0;
    }
    .modal-title-group h2 {
      font-size: 1.25rem;
      margin-top: 0.25rem;
      margin-bottom: 0;
      color: var(--heading);
    }
    .close-btn {
      background: var(--bg-subtle);
      border: none;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      font-size: 1.35rem;
      color: var(--text-muted);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all var(--transition-fast);
      line-height: 1;
    }
    .close-btn:hover {
      background: var(--border-color);
      color: var(--heading);
    }
    .admit-body-scroll {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      padding: 1.5rem 1.75rem;
      background: var(--bg-main);
    }
    .admit-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.1rem 1.75rem;
      border-top: 1px solid var(--border-color);
      background: var(--bg-card);
      flex-shrink: 0;
    }
    .admit-ticket-box {
      border: 2px solid var(--primary);
      border-radius: var(--radius-lg);
      padding: 1.75rem;
      background: var(--bg-card);
      color: var(--text-main);
      box-shadow: var(--shadow-md);
      margin-bottom: 1.5rem;
    }
    .ticket-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 1rem;
      border-bottom: 2px solid var(--primary-subtle);
      margin-bottom: 1.25rem;
    }
    .ticket-logo {
      display: flex;
      align-items: center;
      gap: 0.65rem;
    }
    .brand-name {
      font-family: 'Outfit', sans-serif;
      font-weight: 800;
      font-size: 1.1rem;
      color: var(--heading);
      letter-spacing: 0.5px;
    }
    .status-verified {
      background: var(--primary-subtle);
      color: var(--primary);
      font-weight: 700;
      font-size: 0.75rem;
      padding: 0.3rem 0.75rem;
      border-radius: var(--radius-full);
      border: 1px solid var(--primary-glow);
    }
    .ticket-body {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .detail-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .info-block {
      display: flex;
      flex-direction: column;
    }
    .info-block.full-width {
      grid-column: span 2;
    }
    .label {
      font-size: 0.7rem;
      font-weight: 700;
      color: var(--text-muted);
      letter-spacing: 0.5px;
    }
    .value {
      font-size: 0.95rem;
      font-weight: 600;
      color: var(--heading);
    }
    .main-name {
      font-size: 1.15rem;
      color: var(--primary);
      font-weight: 700;
    }
    .roll-highlight {
      font-family: monospace;
      font-weight: 700;
      color: var(--accent-blue);
      font-size: 1.05rem;
    }
    .centre-name {
      font-weight: 700;
      color: var(--primary);
    }
    .sub-value {
      font-size: 0.8rem;
      color: var(--text-muted);
    }
    .candidate-photo-qr {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }
    .photo-placeholder, .qr-placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      padding: 0.5rem;
      border-radius: var(--radius-md);
      width: 120px;
    }
    .photo-placeholder img {
      width: 100px;
      height: 110px;
      object-fit: cover;
      border-radius: var(--radius-sm);
    }
    .qr-placeholder img {
      width: 90px;
      height: 90px;
      background: #FFFFFF;
      padding: 4px;
      border-radius: var(--radius-sm);
    }
    .photo-tag, .qr-tag {
      font-size: 0.65rem;
      font-weight: 700;
      color: var(--text-muted);
      margin-top: 0.35rem;
    }
    .instructions-box {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1rem;
      font-size: 0.825rem;
      color: var(--text-main);
    }
    .instructions-box h4 {
      font-size: 0.875rem;
      margin-bottom: 0.5rem;
      color: var(--heading);
    }
    .instructions-box ul {
      padding-left: 1.25rem;
      color: var(--text-main);
    }
    .instructions-box li {
      margin-bottom: 0.25rem;
    }
    @media (max-width: 650px) {
      .ticket-body {
        grid-template-columns: 1fr;
      }
      .detail-grid {
        grid-template-columns: 1fr;
      }
      .info-block.full-width {
        grid-column: span 1;
      }
    }
  `]
})
export class AdmitCardModalComponent {
  @Input() isOpen = false;
  @Input() admitCard: AdmitCard | null = null;
  @Output() close = new EventEmitter<void>();

  printCard() {
    window.print();
  }

  closeOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.close.emit();
    }
  }
}
