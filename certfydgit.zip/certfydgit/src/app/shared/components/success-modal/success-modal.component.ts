import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-success-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeOnBackdrop($event)">
      <div class="modal-content success-card padded">
        <div class="success-icon-wrap">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </div>

        <h3 class="success-title">{{ title }}</h3>
        <p class="success-desc">{{ message }}</p>

        <div class="success-details" *ngIf="details?.length">
          <div class="detail-row" *ngFor="let item of details">
            <span class="detail-label">{{ item.label }}:</span>
            <span class="detail-value">{{ item.value }}</span>
          </div>
        </div>

        <div class="modal-actions">
          <button (click)="confirmAction()" class="btn btn-primary btn-lg full-width">
            {{ actionLabel }}
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .success-card {
      text-align: center;
      max-width: 480px;
    }
    .success-icon-wrap {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      background: var(--primary-subtle);
      border: 2px solid var(--primary);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1.25rem auto;
    }
    .success-title {
      font-size: 1.4rem;
      color: var(--heading);
      margin-bottom: 0.5rem;
    }
    .success-desc {
      color: var(--text-muted);
      font-size: 0.95rem;
      margin-bottom: 1.5rem;
    }
    .success-details {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1rem;
      margin-bottom: 1.5rem;
      text-align: left;
    }
    .detail-row {
      display: flex;
      justify-content: space-between;
      font-size: 0.875rem;
      padding: 0.35rem 0;
      border-bottom: 1px dashed var(--border-color);
    }
    .detail-row:last-child {
      border-bottom: none;
    }
    .detail-label {
      color: var(--text-muted);
    }
    .detail-value {
      font-weight: 600;
      color: var(--heading);
    }
    .full-width {
      width: 100%;
    }
  `]
})
export class SuccessModalComponent {
  @Input() isOpen = false;
  @Input() title = 'Action Successful!';
  @Input() message = 'Your action has been processed successfully.';
  @Input() actionLabel = 'Continue to Dashboard';
  @Input() details: Array<{ label: string; value: string }> = [];

  @Output() confirmed = new EventEmitter<void>();
  @Output() closed = new EventEmitter<void>();

  confirmAction() {
    this.confirmed.emit();
  }

  closeOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.closed.emit();
    }
  }
}
