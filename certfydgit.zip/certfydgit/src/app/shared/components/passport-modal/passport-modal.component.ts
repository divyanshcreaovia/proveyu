import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SkillPassport } from '../../../core/models/deservify.models';

@Component({
  selector: 'app-passport-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeOnBackdrop($event)">
      <div class="modal-content passport-modal-card">
        <!-- Header -->
        <div class="passport-modal-header">
          <div class="modal-title-group">
            <span class="badge badge-teal">Official Invigilated Skill Passport</span>
            <h2>Supervised Physical Verification Record</h2>
          </div>
          <button (click)="close.emit()" class="close-btn">&times;</button>
        </div>

        <!-- Scrollable Body -->
        <div class="passport-body" *ngIf="passport">
          <!-- Framed Certificate / Ticket Container -->
          <div class="passport-ticket-box" id="printable-passport">
            
            <!-- Ticket Top Branding & Status Header -->
            <div class="ticket-header">
              <div class="ticket-logo">
                <svg width="24" height="28" viewBox="0 0 24 28" fill="none">
                  <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
                  <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
                </svg>
                <div class="brand-name">PROVEYU VERIFICATION</div>
              </div>
              <div class="ticket-status">
                <span class="status-verified"><i class="fa-solid fa-shield-check me-1"></i> STATUS: VERIFIED & CONFIRMED</span>
              </div>
            </div>

            <!-- Summary Spotlight Banner -->
            <div class="passport-banner">
              <div class="score-circle-box">
                <div class="score-num">{{ passport.overallScore }}</div>
                <div class="score-label">PASSPORT SCORE</div>
                <div class="score-subtext">OUT OF 100</div>
              </div>

              <div class="passport-summary-info">
                <span class="badge badge-gold"><i class="fa-solid fa-award me-1"></i> {{ passport.tierBadge }}</span>
                <h3 class="candidate-headline">Verified Skill Passport #{{ passport.passportId }}</h3>
                <div class="invigilation-meta">
                  <span class="meta-item"><i class="fa-solid fa-location-dot me-1"></i> {{ passport.verificationCenter }}</span>
                  <span class="meta-item"><i class="fa-regular fa-calendar-check me-1"></i> Issued: {{ passport.issueDate }}</span>
                  <span class="meta-item verified-tag"><i class="fa-solid fa-circle-check me-1"></i> Invigilator CCTV Logged</span>
                </div>
              </div>
            </div>

            <!-- Role Recommendations Box -->
            <div class="role-fit-card">
              <h4 class="card-section-title"><i class="fa-solid fa-bullseye text-primary me-2"></i> Multi-Dimensional Role Match Recommendation</h4>
              <div class="role-grid">
                <div class="role-box primary-role">
                  <span class="role-tag">PRIMARY FIT</span>
                  <span class="role-name">{{ passport.primaryRoleRecommendation }}</span>
                </div>
                <div class="role-box secondary-role">
                  <span class="role-tag">SECONDARY FIT</span>
                  <span class="role-name">{{ passport.secondaryRoleRecommendation }}</span>
                </div>
              </div>
            </div>

            <!-- Competency Breakdown -->
            <div class="section-block">
              <h4 class="card-section-title"><i class="fa-solid fa-chart-column text-primary me-2"></i> Verified Competency Matrix</h4>
              <div class="competency-list">
                <div class="competency-item" *ngFor="let comp of passport.competencies">
                  <div class="comp-header">
                    <span class="comp-name">{{ comp.name }}</span>
                    <div class="comp-score-tag">
                      <span class="status-pill" [ngClass]="{
                        'status-strong': comp.status === 'Strong',
                        'status-proficient': comp.status === 'Proficient',
                        'status-developing': comp.status === 'Developing'
                      }">
                        <span class="status-dot"></span>
                        {{ comp.status }}
                      </span>
                      <div class="comp-score-badge">
                        <span class="score-val">{{ comp.score }}</span>
                        <span class="score-denom">/100</span>
                      </div>
                    </div>
                  </div>
                  <div class="progress-bar-bg">
                    <div class="progress-fill" [style.width.%]="comp.score"></div>
                  </div>
                  <p class="comp-desc">{{ comp.description }}</p>
                </div>
              </div>
            </div>

            <!-- Practical Build & Evaluator Observations -->
            <div class="section-block evaluator-section">
              <h4 class="card-section-title"><i class="fa-solid fa-code text-primary me-2"></i> Practical Hands-on Build & Technical Evaluation</h4>
              <div class="build-summary-box">
                <p><strong>Exam Build Scenario:</strong> {{ passport.practicalBuildSummary }}</p>
              </div>

              <div class="feedback-box">
                <span class="feedback-title"><i class="fa-solid fa-shield-halved me-1"></i> Green Flag Evaluator Observations:</span>
                <ul>
                  <li *ngFor="let item of passport.evaluatorFeedback">
                    <i class="fa-solid fa-check text-success me-2"></i> {{ item }}
                  </li>
                </ul>
              </div>
            </div>

            <!-- Audit & Anti-Fraud Protocol Footer Box -->
            <div class="instructions-box">
              <h4>📋 Official Verification & Audit Protocol</h4>
              <ul>
                <li>Evaluation was conducted under 100% in-person invigilation at an authorized Proveyu test center.</li>
                <li>Candidate photo identity and physical Govt ID were cross-verified via biometric fingerprint match.</li>
                <li>This passport document is cryptographically signed and immutable on the Proveyu registry.</li>
              </ul>
            </div>

          </div>
        </div>

        <!-- Footer actions -->
        <div class="passport-actions">
          <button (click)="copyShareLink()" class="btn btn-secondary">
            <i class="fa-solid fa-link me-1"></i> Copy Shareable Link
          </button>
          <button (click)="downloadPDF()" class="btn btn-primary">
            <i class="fa-solid fa-file-pdf me-1"></i> Download Official PDF Passport
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .passport-modal-card {
      max-width: 820px;
      width: 100%;
      max-height: calc(100vh - 3rem);
      display: flex;
      flex-direction: column;
      background: var(--bg-card);
      color: var(--text-main);
    }
    .passport-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.25rem 1.75rem;
      border-bottom: 1px solid var(--border-color);
      background: var(--bg-card);
      color: var(--heading);
      flex-shrink: 0;
      border-radius: var(--radius-xl) var(--radius-xl) 0 0;
    }
    .modal-title-group h2 {
      font-size: 1.25rem;
      margin-top: 0.25rem;
      margin-bottom: 0;
      font-weight: 700;
      color: var(--heading);
    }
    .close-btn {
      background: var(--bg-subtle);
      border: none;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      font-size: 1.35rem;
      color: var(--text-muted);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all var(--transition-fast);
      line-height: 1;
    }
    .close-btn:hover {
      background: var(--border-color);
      color: var(--heading);
    }
    .passport-body {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      padding: 1.5rem 1.75rem;
      background: var(--bg-main);
    }
    .passport-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.1rem 1.75rem;
      border-top: 1px solid var(--border-color);
      background: var(--bg-card);
      flex-shrink: 0;
      border-radius: 0 0 var(--radius-xl) var(--radius-xl);
    }
    .passport-ticket-box {
      border: 2px solid var(--primary);
      border-radius: var(--radius-lg);
      padding: 1.75rem;
      background: var(--bg-card);
      color: var(--text-main);
      box-shadow: var(--shadow-md);
    }
    .ticket-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--border-color);
      padding-bottom: 1rem;
      margin-bottom: 1.5rem;
    }
    .ticket-logo {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .brand-name {
      font-weight: 800;
      font-size: 0.95rem;
      color: var(--primary);
      letter-spacing: 0.5px;
    }
    .status-verified {
      background: var(--primary-subtle);
      color: var(--primary);
      font-weight: 700;
      border: 1px solid var(--primary-glow);
      padding: 0.35rem 0.75rem;
      border-radius: 20px;
      font-size: 0.725rem;
      letter-spacing: 0.5px;
    }
    .passport-banner {
      display: flex;
      align-items: center;
      gap: 1.5rem;
      background: linear-gradient(135deg, #0F7A5C 0%, #0B5E46 100%);
      color: #FFFFFF;
      padding: 1.5rem;
      border-radius: var(--radius-md);
      margin-bottom: 1.5rem;
      box-shadow: 0 6px 20px rgba(15, 122, 92, 0.25);
    }
    .score-circle-box {
      width: 102px;
      height: 102px;
      min-width: 102px;
      min-height: 102px;
      border-radius: 50%;
      background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.35), rgba(255, 255, 255, 0.12));
      border: 3.5px solid #FFFFFF;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2), inset 0 0 12px rgba(255, 255, 255, 0.25);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      text-align: center;
      padding: 0.25rem;
    }
    .score-num {
      font-family: 'Outfit', sans-serif;
      font-size: 2.2rem;
      font-weight: 800;
      line-height: 0.95;
      color: #FFFFFF;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    .score-label {
      font-size: 0.58rem;
      font-weight: 800;
      letter-spacing: 0.6px;
      color: #FFFFFF;
      margin-top: 3px;
      white-space: nowrap;
      text-transform: uppercase;
    }
    .score-subtext {
      font-size: 0.5rem;
      font-weight: 700;
      color: rgba(255, 255, 255, 0.85);
      letter-spacing: 0.5px;
      margin-top: 1px;
    }
    .passport-summary-info {
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }
    .candidate-headline {
      font-size: 1.15rem;
      color: #FFFFFF;
      margin: 0;
      font-weight: 700;
    }
    .invigilation-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 0.85rem;
      font-size: 0.775rem;
      opacity: 0.95;
    }
    .verified-tag {
      font-weight: 700;
      color: #34D399;
    }
    .card-section-title {
      font-size: 0.95rem;
      font-weight: 700;
      color: var(--heading);
      margin-bottom: 0.85rem;
    }
    .role-fit-card {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1.25rem;
      margin-bottom: 1.5rem;
      color: var(--text-main);
    }
    .role-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .role-box {
      border-radius: var(--radius-md);
      padding: 0.85rem 1rem;
      display: flex;
      flex-direction: column;
      border: 1px solid var(--border-color);
      background: var(--bg-card);
      box-shadow: var(--shadow-sm);
      color: var(--text-main);
    }
    .primary-role {
      background: var(--bg-card);
      border-left: 3px solid var(--primary);
    }
    .secondary-role {
      background: var(--bg-card);
      border-left: 3px solid var(--accent-blue);
    }
    .role-tag {
      font-size: 0.65rem;
      font-weight: 800;
      letter-spacing: 0.5px;
      color: var(--primary);
      margin-bottom: 0.2rem;
    }
    .secondary-role .role-tag {
      color: var(--accent-blue);
    }
    .role-name {
      font-weight: 700;
      font-size: 0.9rem;
      color: var(--heading);
    }
    .section-block {
      margin-bottom: 1.5rem;
    }
    .competency-list {
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
    }
    .competency-item {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1rem 1.15rem;
      color: var(--text-main);
      transition: all var(--transition-fast);
    }
    .competency-item:hover {
      border-color: var(--primary-glow);
      box-shadow: var(--shadow-sm);
    }
    .comp-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
    .comp-name {
      font-weight: 700;
      color: var(--heading);
      font-size: 0.95rem;
    }
    .comp-score-tag {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      padding: 0.25rem 0.75rem;
      border-radius: var(--radius-full);
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.4px;
      text-transform: uppercase;
      line-height: 1;
    }
    .status-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      display: inline-block;
      flex-shrink: 0;
    }
    .status-strong {
      background: rgba(16, 185, 129, 0.14);
      color: #10B981;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }
    .status-strong .status-dot {
      background: #10B981;
      box-shadow: 0 0 6px #10B981;
    }
    .status-proficient {
      background: rgba(59, 130, 246, 0.14);
      color: #3B82F6;
      border: 1px solid rgba(59, 130, 246, 0.3);
    }
    .status-proficient .status-dot {
      background: #3B82F6;
      box-shadow: 0 0 6px #3B82F6;
    }
    .status-developing {
      background: rgba(245, 158, 11, 0.14);
      color: #F59E0B;
      border: 1px solid rgba(245, 158, 11, 0.3);
    }
    .status-developing .status-dot {
      background: #F59E0B;
      box-shadow: 0 0 6px #F59E0B;
    }
    .comp-score-badge {
      display: inline-flex;
      align-items: baseline;
      font-family: 'Outfit', sans-serif;
      line-height: 1;
    }
    .score-val {
      font-size: 1.15rem;
      font-weight: 800;
      color: var(--heading);
    }
    .score-denom {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--text-muted);
      margin-left: 1px;
    }
    .progress-bar-bg {
      height: 8px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-full);
      overflow: hidden;
      margin-bottom: 0.45rem;
    }
    .progress-fill {
      height: 100%;
      background: var(--gradient-primary);
      border-radius: var(--radius-full);
      transition: width 0.6s ease-out;
    }
    .comp-desc {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.45;
    }
    .build-summary-box {
      background: var(--bg-subtle);
      border-left: 4px solid var(--primary);
      padding: 0.85rem 1rem;
      border-radius: 0 var(--radius-md) var(--radius-md) 0;
      font-size: 0.825rem;
      margin-bottom: 1rem;
      color: var(--text-main);
    }
    .feedback-box {
      background: var(--primary-subtle);
      border: 1px solid var(--primary-glow);
      padding: 0.85rem 1rem;
      border-radius: var(--radius-md);
      color: var(--text-main);
    }
    .feedback-title {
      font-weight: 700;
      color: var(--primary);
      font-size: 0.825rem;
      display: block;
      margin-bottom: 0.4rem;
    }
    .feedback-box ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .feedback-box li {
      font-size: 0.825rem;
      color: var(--text-main);
      margin-bottom: 0.25rem;
    }
    .instructions-box {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1rem;
      font-size: 0.825rem;
      margin-top: 1rem;
      color: var(--text-main);
    }
    .instructions-box h4 {
      font-size: 0.875rem;
      margin-bottom: 0.5rem;
      color: var(--heading);
      font-weight: 700;
    }
    .instructions-box ul {
      padding-left: 1.25rem;
      color: var(--text-main);
      margin: 0;
    }
    .instructions-box li {
      margin-bottom: 0.25rem;
    }
    @media (max-width: 650px) {
      .passport-banner {
        flex-direction: column;
        text-align: center;
      }
      .role-grid {
        grid-template-columns: 1fr;
      }
      .passport-actions {
        flex-direction: column;
      }
    }
  `]
})
export class PassportModalComponent {
  @Input() isOpen = false;
  @Input() passport: SkillPassport | null = null;
  @Output() close = new EventEmitter<void>();

  copyShareLink() {
    navigator.clipboard.writeText(`https://proveyu.org/passport/${this.passport?.passportId}`);
    alert('Shareable Skill Passport link copied to clipboard!');
  }

  downloadPDF() {
    window.print();
  }

  closeOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.close.emit();
    }
  }
}

