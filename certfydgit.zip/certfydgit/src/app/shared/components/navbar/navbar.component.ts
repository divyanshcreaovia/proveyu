import { Component, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ThemeService } from '../../../core/services/theme.service';
import { UserRole } from '../../../core/models/deservify.models';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar" [class.navbar-minimal]="isMinimal">
      <div class="container navbar-inner">
        <!-- Logo -->
        <a routerLink="/" class="logo-group">
          <div class="logo-shield">
            <svg width="22" height="26" viewBox="0 0 24 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
              <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
            </svg>
          </div>
          <div class="logo-text-box">
            <span class="logo-title">PROVEYU</span>
            <span class="logo-tagline">Skill Speaks Louder Than a Resume</span>
          </div>
        </a>

        <!-- Minimal Header Status Badge when in Registration / Stepper -->
        <ng-container *ngIf="isMinimal">
          <div class="stepper-nav-badge">
            <span class="badge-dot"></span>
            <span><i class="fa-solid fa-shield-halved me-1"></i> Onboarding Mode</span>
          </div>
        </ng-container>

        <!-- Nav Links (Only visible when NOT in minimal/stepper mode) -->
        <div class="nav-links" *ngIf="!isMinimal">
          <ng-container *ngIf="!authService.isLoggedIn(); else authenticatedNavLinks">
            <a routerLink="/how-it-works" class="nav-item" routerLinkActive="active">How It Works</a>
            <a routerLink="/why-in-person" class="nav-item" routerLinkActive="active">Why In-Person</a>
            <a routerLink="/fresher-model" class="nav-item" routerLinkActive="active">Fresher Model</a>
            <a routerLink="/select-role" class="nav-item highlight" routerLinkActive="active">Register</a>
          </ng-container>

          <ng-template #authenticatedNavLinks>
            <ng-container *ngIf="authService.currentRole() === 'candidate'">
              <a routerLink="/dashboard/candidate" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-chart-pie me-1"></i> Dashboard</a>
              <a routerLink="/candidate/passport" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-id-card me-1"></i> Skill Passport</a>
              <a routerLink="/candidate/book-slot" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-calendar-check me-1"></i> Book Slot</a>
            </ng-container>

            <ng-container *ngIf="authService.currentRole() !== 'candidate'">
              <a routerLink="/dashboard/recruiter" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-briefcase me-1"></i> Dashboard</a>
              <a routerLink="/recruiter/verifiedtalents" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-user-shield me-1"></i> Verified Talent</a>
              <a routerLink="/recruiter/invites" class="nav-item" routerLinkActive="active"><i class="fa-solid fa-paper-plane me-1"></i> Direct Invites</a>
            </ng-container>
          </ng-template>
        </div>

        <!-- Right Navigation Cluster -->
        <div class="nav-right-cluster">
          <!-- Highly Visible Theme Switch Button Pill -->
          <button 
            (click)="toggleTheme($event)" 
            class="theme-switch-pill" 
            [class.is-dark]="themeService.isDarkMode()"
            [attr.aria-label]="themeService.isDarkMode() ? 'Switch to Light Mode' : 'Switch to Dark Mode'"
            [title]="themeService.isDarkMode() ? 'Switch to Light Mode' : 'Switch to Dark Mode'">
            <div class="switch-track">
              <div class="switch-thumb">
                <!-- Sun Icon SVG -->
                <svg *ngIf="!themeService.isDarkMode()" class="icon-sun" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="12" cy="12" r="5"></circle>
                  <line x1="12" y1="1" x2="12" y2="3"></line>
                  <line x1="12" y1="21" x2="12" y2="23"></line>
                  <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                  <line x1="1" y1="12" x2="3" y2="12"></line>
                  <line x1="21" y1="12" x2="23" y2="12"></line>
                  <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                  <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                </svg>
                <!-- Moon Icon SVG -->
                <svg *ngIf="themeService.isDarkMode()" class="icon-moon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                </svg>
              </div>
              <span class="switch-label">{{ themeService.isDarkMode() ? 'Dark' : 'Light' }}</span>
            </div>
          </button>

          <!-- Auth Action Buttons (Only visible when NOT in minimal mode) -->
          <div class="nav-actions" *ngIf="!isMinimal">
            <ng-container *ngIf="authService.isLoggedIn(); else guestActions">
              <!-- Active User Info Pill -->
              <div class="user-profile-badge">
                <span class="user-avatar-dot"></span>
                <div class="user-meta-text">
                  <span class="user-name">{{ authService.userName() }}</span>
                  <span class="user-role-label">{{ getRoleLabel(authService.currentRole()) }}</span>
                </div>
              </div>

              <!-- Logout -->
              <button (click)="logout()" class="btn btn-sm btn-secondary logout-btn" title="Logout" aria-label="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
              </button>
            </ng-container>

            <ng-template #guestActions>
              <a routerLink="/login" class="btn btn-sm btn-secondary"><i class="fa-solid fa-right-to-bracket me-1"></i> Login</a>
              <a routerLink="/select-role" class="btn btn-sm btn-primary"><i class="fa-solid fa-user-check me-1"></i> Get Verified</a>
            </ng-template>
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      width: 100%;
      position: sticky;
      top: 0;
      z-index: 500;
      background: var(--bg-card);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border-bottom: 1px solid var(--border-color);
      height: 72px;
      display: flex;
      align-items: center;
      transition: background-color 0.35s ease, border-color 0.35s ease;
    }
    .navbar-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      max-width: 100%;
      padding: 0 2rem;
    }
    .logo-group {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      text-decoration: none;
      transition: transform var(--transition-fast);
    }
    .logo-group:hover {
      transform: scale(1.02);
    }
    .logo-shield {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 42px;
      height: 42px;
      background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%);
      border-radius: var(--radius-md);
      border: 1px solid rgba(15, 122, 92, 0.25);
      box-shadow: 0 4px 10px rgba(15, 122, 92, 0.12);
    }
    .logo-text-box {
      display: flex;
      flex-direction: column;
    }
    .logo-title {
      font-family: 'Outfit', sans-serif;
      font-weight: 900;
      font-size: 1.4rem;
      letter-spacing: 0.8px;
      color: var(--heading);
      line-height: 1;
    }
    .logo-tagline {
      font-size: 0.65rem;
      font-weight: 700;
      color: var(--primary);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-top: 2px;
    }

    .stepper-nav-badge {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: var(--primary-subtle);
      border: 1px solid var(--border-color);
      color: var(--primary);
      padding: 0.35rem 0.9rem;
      border-radius: 9999px;
      font-size: 0.825rem;
      font-weight: 600;
      letter-spacing: 0.2px;
    }
    .badge-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: #10B981;
      box-shadow: 0 0 6px rgba(16, 185, 129, 0.6);
      animation: pulseDot 2s infinite;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    .nav-item {
      font-weight: 600;
      font-size: 0.875rem;
      color: var(--text-muted);
      padding: 0.4rem 0.75rem;
      border-radius: var(--radius-sm);
      transition: all var(--transition-fast);
      position: relative;
    }
    .nav-item:hover {
      color: var(--primary);
      background: var(--primary-subtle);
    }
    .nav-item.active {
      color: var(--primary);
      background: var(--primary-subtle);
      font-weight: 700;
      box-shadow: inset 0 0 0 1px var(--primary-glow);
    }

    .nav-right-cluster {
      display: flex;
      align-items: center;
      gap: 0.85rem;
    }

    /* Highly Visible Theme Switch Button Pill */
    .theme-switch-pill {
      display: inline-flex;
      align-items: center;
      background: var(--bg-main);
      border: 1.5px solid var(--border-color);
      border-radius: 9999px;
      padding: 3px 12px 3px 4px;
      cursor: pointer;
      outline: none;
      box-shadow: var(--shadow-sm);
      transition: all 0.25s ease;
      user-select: none;
      height: 38px;
    }

    .theme-switch-pill:hover {
      border-color: var(--primary);
      box-shadow: 0 0 12px var(--primary-glow);
      transform: translateY(-1px);
    }

    .switch-track {
      display: flex;
      align-items: center;
      gap: 7px;
    }

    .switch-thumb {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: #F59E0B;
      color: #FFFFFF;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), background 0.3s ease;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .theme-switch-pill.is-dark .switch-thumb {
      background: #6366F1;
    }

    .switch-label {
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      color: var(--heading);
    }

    .nav-actions {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      position: relative;
    }
    .user-profile-badge {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.35rem 0.85rem;
      background: var(--bg-main);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-full);
      box-shadow: var(--shadow-sm);
    }
    .user-avatar-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #10B981;
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
      animation: pulseDot 2s infinite;
    }
    .user-meta-text {
      display: flex;
      flex-direction: column;
      line-height: 1.1;
    }
    .user-name {
      font-size: 0.825rem;
      font-weight: 700;
      color: var(--heading);
    }
    .user-role-label {
      font-size: 0.675rem;
      font-weight: 600;
      color: var(--primary);
    }
    .logout-btn {
      color: var(--accent-red);
      border-color: rgba(239, 68, 68, 0.25);
    }
    .logout-btn:hover {
      background: rgba(239, 68, 68, 0.1);
      color: #DC2626;
      border-color: #EF4444;
    }

    @media (max-width: 850px) {
      .nav-links { display: none; }
    }
  `]
})
export class NavbarComponent {
  @Input() minimal = false;

  authService = inject(AuthService);
  themeService = inject(ThemeService);
  router = inject(Router);

  toggleTheme(event: MouseEvent) {
    this.themeService.toggleTheme(event);
  }

  get isMinimal(): boolean {
    const path = this.router.url || '';
    const isRegisterRoute = path.includes('/register') || path.includes('/candidate-register') || path.includes('/recruiter-register');
    if (!isRegisterRoute) {
      return false;
    }
    return this.minimal || isRegisterRoute;
  }

  getRoleLabel(role: UserRole | null): string {
    if (!role) return 'Guest';
    switch (role) {
      case 'candidate': return 'Candidate';
      case 'recruiter_agency': return 'Placement Agency';
      case 'recruiter_startup': return 'Startup Recruiter';
      case 'recruiter_company': return 'Enterprise Hire';
    }
  }

  goToDashboard() {
    const role = this.authService.currentRole();
    if (role === 'candidate') {
      this.router.navigate(['/dashboard/candidate']);
    } else {
      this.router.navigate(['/dashboard/recruiter']);
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}
