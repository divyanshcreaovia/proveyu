import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { HowItWorksComponent } from './pages/how-it-works/how-it-works.component';
import { WhyInPersonComponent } from './pages/why-in-person/why-in-person.component';
import { FresherModelComponent } from './pages/fresher-model/fresher-model.component';
import { RoleSelectionComponent } from './pages/role-selection/role-selection.component';
import { LoginComponent } from './pages/login/login.component';
import { CandidateRegisterComponent } from './pages/candidate-register/candidate-register.component';
import { RecruiterRegisterComponent } from './pages/recruiter-register/recruiter-register.component';
import { CandidateDashboardComponent } from './pages/candidate-dashboard/candidate-dashboard.component';
import { CandidatePassportComponent } from './pages/candidate-passport/candidate-passport.component';
import { BookSlotComponent } from './pages/book-slot/book-slot.component';
import { RecruiterDashboardComponent } from './pages/recruiter-dashboard/recruiter-dashboard.component';
import { RecruiterCandidatesComponent } from './pages/recruiter-candidates/recruiter-candidates.component';
import { RecruiterInvitesComponent } from './pages/recruiter-invites/recruiter-invites.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'how-it-works', component: HowItWorksComponent },
  { path: 'why-in-person', component: WhyInPersonComponent },
  { path: 'fresher-model', component: FresherModelComponent },
  { path: 'select-role', component: RoleSelectionComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register/candidate', component: CandidateRegisterComponent },
  { path: 'register/recruiter', component: RecruiterRegisterComponent },
  { path: 'dashboard/candidate', component: CandidateDashboardComponent },
  { path: 'candidate/passport', component: CandidatePassportComponent },
  { path: 'candidate/book-slot', component: BookSlotComponent },
  { path: 'dashboard/recruiter', component: RecruiterDashboardComponent },
  { path: 'recruiter/verifiedtalents', component: RecruiterCandidatesComponent },
  { path: 'recruiter/candidates', redirectTo: 'recruiter/verifiedtalents', pathMatch: 'full' },
  { path: 'recruiter/invites', component: RecruiterInvitesComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: '**', redirectTo: '' }
];
