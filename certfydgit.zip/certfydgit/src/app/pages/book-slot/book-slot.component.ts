import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { CandidateService } from '../../core/services/candidate.service';
import { AdmitCardModalComponent } from '../../shared/components/admit-card-modal/admit-card-modal.component';
import { SuccessModalComponent } from '../../shared/components/success-modal/success-modal.component';

@Component({
  selector: 'app-book-slot',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NavbarComponent,
    FooterComponent,
    AdmitCardModalComponent,
    SuccessModalComponent
  ],
  template: `
    <app-navbar></app-navbar>

    <main class="book-slot-page">
      <div class="container">
        
        <div class="top-bar">
          <a routerLink="/dashboard/candidate" class="back-link">← Back to Candidate Dashboard</a>
          <span class="badge badge-teal">TCS iON / JEE Infrastructure Partner Network</span>
        </div>

        <div class="page-title-box">
          <h2>📅 Book In-Person Exam Centre Slot</h2>
          <p>Select your preferred partner centre, test date, and time slot for supervised in-person skill evaluation.</p>
        </div>

        <!-- Layout Grid: Booking Form / Active Slot & Centre Info -->
        <div class="booking-grid">
          
          <!-- Booking Form / Active Slot Card -->
          <div class="deservify-card booking-card">
            
            <!-- Case 1: Slot Already Booked -->
            <div *ngIf="profile().slotBooking; else bookingForm" class="booked-state-card">
              <div class="confirmed-header">
                <div class="circle-check">✓</div>
                <div>
                  <span class="status-tag">CONFIRMED RESERVATION</span>
                  <h3>Exam Centre Slot Booked</h3>
                </div>
              </div>

              <div class="booked-details-grid">
                <div class="detail-box">
                  <span class="lbl">Exam Centre:</span>
                  <strong class="val">{{ profile().slotBooking?.centerName }}</strong>
                </div>
                <div class="detail-box">
                  <span class="lbl">Address:</span>
                  <span class="val">{{ profile().slotBooking?.centerAddress }}</span>
                </div>
                <div class="detail-box">
                  <span class="lbl">Scheduled Date:</span>
                  <strong class="val text-green">{{ profile().slotBooking?.date }}</strong>
                </div>
                <div class="detail-box">
                  <span class="lbl">Time Slot:</span>
                  <strong class="val text-green">{{ profile().slotBooking?.timeSlot }}</strong>
                </div>
                <div class="detail-box">
                  <span class="lbl">Reporting Time:</span>
                  <span class="val">{{ profile().slotBooking?.reportingTime }}</span>
                </div>
                <div class="detail-box">
                  <span class="lbl">Roll Number:</span>
                  <code class="val-code">{{ profile().slotBooking?.rollNumber }}</code>
                </div>
              </div>

              <div class="booked-actions">
                <button (click)="isAdmitModalOpen = true" class="btn btn-primary btn-lg full-width">
                  🖨️ View & Download Official Admit Card
                </button>
                <button (click)="reschedule()" class="btn btn-secondary btn-sm full-width margin-top">
                  🔄 Change / Reschedule Slot
                </button>
              </div>
            </div>

            <!-- Case 2: New Slot Booking Form -->
            <ng-template #bookingForm>
              <form (ngSubmit)="onFormSubmit()" class="slot-form-full">
                <h3>Select Exam Centre Location</h3>

                <div class="centres-radio-list">
                  <label 
                    class="centre-radio-card" 
                    *ngFor="let centre of centres" 
                    [class.selected]="selectedCenter === centre.name"
                    (click)="selectedCenter = centre.name">
                    <input 
                      type="radio" 
                      name="centre" 
                      [value]="centre.name" 
                      [(ngModel)]="selectedCenter">
                    <div class="radio-content">
                      <div class="radio-title-row">
                        <strong>{{ centre.city }} — {{ centre.name }}</strong>
                        <span class="capacity-tag">Available Seats: {{ centre.seats }}</span>
                      </div>
                      <p class="centre-addr">{{ centre.address }}</p>
                    </div>
                  </label>
                </div>

                <div class="form-row-2">
                  <div class="form-group">
                    <label class="form-label">Preferred Date</label>
                    <input 
                      type="date" 
                      class="form-control" 
                      [(ngModel)]="selectedDate" 
                      name="selectedDate" 
                      required>
                  </div>

                  <div class="form-group">
                    <label class="form-label">Preferred Time Slot</label>
                    <select class="form-control" [(ngModel)]="selectedTimeSlot" name="selectedTimeSlot">
                      <option value="09:30 AM - 12:30 PM">Morning: 09:30 AM - 12:30 PM (Reporting 08:30 AM)</option>
                      <option value="01:30 PM - 04:30 PM">Afternoon: 01:30 PM - 04:30 PM (Reporting 12:30 PM)</option>
                    </select>
                  </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg full-width">
                  Reserve Slot & Generate Admit Card →
                </button>
              </form>
            </ng-template>
          </div>

          <!-- Right Sidebar Instructions & Security Protocol -->
          <div class="side-info-col">
            <div class="deservify-card protocol-card">
              <h3>🛡️ Exam Centre Protocol</h3>
              <p class="desc">Proveyu assessments are conducted strictly inside physical TCS iON Digital Zones to guarantee 100% invigilated authenticity.</p>

              <div class="checklist">
                <div class="check-item">
                  <span class="icon">🪪</span>
                  <div>
                    <strong>Valid Govt Photo ID Required</strong>
                    <span>Bring original Aadhaar Card, PAN, or Passport for gate entry.</span>
                  </div>
                </div>

                <div class="check-item">
                  <span class="icon">👆</span>
                  <div>
                    <strong>Biometric Gate Logging</strong>
                    <span>Fingerprint scanning and AI face verification before entering computer lab.</span>
                  </div>
                </div>

                <div class="check-item">
                  <span class="icon">💻</span>
                  <div>
                    <strong>Restricted Sandbox System</strong>
                    <span>Tests are taken on locked TCS terminals with screen recording and zero external web access.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </main>

    <app-admit-card-modal
      [isOpen]="isAdmitModalOpen"
      [admitCard]="admitCardData"
      (close)="isAdmitModalOpen = false">
    </app-admit-card-modal>

    <app-success-modal
      [isOpen]="isSuccessModalOpen"
      title="Exam Slot Reserved!"
      message="Your slot at the TCS iON Exam Centre has been confirmed. Your admit card is now ready."
      actionLabel="Open Admit Card →"
      (confirmed)="onSuccessConfirmed()"
      (closed)="isSuccessModalOpen = false">
    </app-success-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .book-slot-page {
      padding: 2.5rem 0 5rem 0;
      background: var(--bg-subtle);
      min-height: calc(100vh - 72px - 300px);
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    .back-link {
      font-weight: 600;
      color: var(--primary-dark);
      font-size: 0.9rem;
    }
    .page-title-box {
      margin-bottom: 2rem;
    }
    .page-title-box h2 {
      font-size: 1.8rem;
      margin-bottom: 0.35rem;
    }
    .page-title-box p {
      color: var(--text-muted);
      font-size: 0.95rem;
    }
    .booking-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 2rem;
    }
    
    /* Booked state styling */
    .confirmed-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding-bottom: 1.25rem;
      border-bottom: 1px dashed var(--border-color);
      margin-bottom: 1.5rem;
    }
    .circle-check {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: var(--primary);
      color: #FFFFFF;
      font-size: 1.5rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .status-tag {
      font-size: 0.725rem;
      font-weight: 800;
      color: var(--primary);
      letter-spacing: 0.5px;
    }
    .confirmed-header h3 {
      font-size: 1.3rem;
      margin: 0;
    }
    .booked-details-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.25rem;
      background: var(--bg-subtle);
      padding: 1.25rem;
      border-radius: var(--radius-md);
      border: 1px solid var(--border-color);
      margin-bottom: 1.5rem;
    }
    .detail-box {
      display: flex;
      flex-direction: column;
      gap: 0.2rem;
    }
    .detail-box .lbl {
      font-size: 0.775rem;
      color: var(--text-muted);
      font-weight: 600;
    }
    .detail-box .val {
      font-size: 0.9rem;
      color: var(--heading);
    }
    .val-code {
      font-family: monospace;
      font-weight: 700;
      font-size: 0.9rem;
      background: var(--bg-card);
      color: var(--heading);
      padding: 0.2rem 0.5rem;
      border-radius: 4px;
      border: 1px solid var(--border-color);
    }
    .margin-top { margin-top: 0.75rem; }
    .full-width { width: 100%; }

    /* Booking form styling */
    .slot-form-full h3 {
      font-size: 1.15rem;
      margin-bottom: 1.25rem;
      color: var(--heading);
    }
    .centres-radio-list {
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
      margin-bottom: 1.5rem;
    }
    .centre-radio-card {
      display: flex;
      align-items: flex-start;
      gap: 1rem;
      padding: 1rem;
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      background: var(--bg-card);
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .centre-radio-card:hover, .centre-radio-card.selected {
      border-color: var(--primary);
      background: var(--primary-subtle);
    }
    .centre-radio-card input {
      margin-top: 0.25rem;
    }
    .radio-content {
      flex: 1;
    }
    .radio-title-row {
      display: flex;
      justify-content: space-between;
      font-size: 0.9rem;
      color: var(--heading);
      margin-bottom: 0.25rem;
    }
    .capacity-tag {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--primary);
      background: var(--primary-subtle);
      padding: 0.15rem 0.5rem;
      border-radius: var(--radius-full);
      border: 1px solid rgba(15, 122, 92, 0.2);
    }
    .centre-addr {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin: 0;
    }
    .form-row-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.25rem;
      margin-bottom: 1.5rem;
    }

    /* Right protocol sidebar */
    .protocol-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      color: var(--text-main);
    }
    .protocol-card h3 { font-size: 1.15rem; margin-bottom: 0.5rem; color: var(--heading); }
    .protocol-card .desc { font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.5rem; }
    .checklist { display: flex; flex-direction: column; gap: 1.25rem; }
    .check-item { display: flex; gap: 0.85rem; font-size: 0.85rem; }
    .check-item .icon { font-size: 1.4rem; }
    .check-item strong { display: block; color: var(--heading); margin-bottom: 0.15rem; }
    .check-item span { color: var(--text-muted); font-size: 0.8rem; }

    @media (max-width: 850px) {
      .booking-grid { grid-template-columns: 1fr; }
      .booked-details-grid { grid-template-columns: 1fr; }
      .form-row-2 { grid-template-columns: 1fr; }
    }
  `]
})
export class BookSlotComponent {
  candidateService = inject(CandidateService);
  profile = this.candidateService.currentProfile;

  isAdmitModalOpen = false;
  isSuccessModalOpen = false;

  centres = [
    {
      city: 'Bengaluru',
      name: 'TCS iON Digital Zone Koramangala',
      address: 'Plot No. 42, 80 Feet Road, Koramangala 4th Block, Bengaluru, Karnataka 560034',
      seats: 48
    },
    {
      city: 'Noida / NCR',
      name: 'TCS iON Digital Zone Sector 62',
      address: 'C-56/12, Institutional Area, Sector 62, Noida, Uttar Pradesh 201309',
      seats: 62
    },
    {
      city: 'Mumbai',
      name: 'TCS iON iDZ Powai',
      address: 'Technology Park, Saki Vihar Road, Powai, Mumbai, Maharashtra 400072',
      seats: 35
    },
    {
      city: 'Hyderabad',
      name: 'TCS iON HITECH City',
      address: 'Block 2, Cyber Towers, HITECH City, Hyderabad, Telangana 500081',
      seats: 50
    }
  ];

  selectedCenter = 'TCS iON Digital Zone Koramangala';
  selectedDate = '2026-09-22';
  selectedTimeSlot = '09:30 AM - 12:30 PM';

  get admitCardData() {
    return this.profile().slotBooking ? this.candidateService.getAdmitCard() : null;
  }

  onFormSubmit() {
    this.candidateService.bookSlot(this.selectedCenter, this.selectedDate, this.selectedTimeSlot);
    this.isSuccessModalOpen = true;
  }

  onSuccessConfirmed() {
    this.isSuccessModalOpen = false;
    this.isAdmitModalOpen = true;
  }

  reschedule() {
    if (confirm('Are you sure you want to change your exam centre slot?')) {
      // Clear slot booking to allow re-booking
      this.profile().slotBooking = undefined;
    }
  }
}
