import { Component, inject, ChangeDetectorRef, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="forgot-page">
      <div class="container container-narrow">
        <div class="forgot-card deservify-card">
          <!-- Step Indicator -->
          <div class="step-progress-bar" *ngIf="step < 4">
            <div class="progress-step" [class.active]="step >= 1" [class.completed]="step > 1">
              <div class="step-icon"><i class="fa-solid" [class.fa-check]="step > 1" [class.fa-1]="step <= 1"></i></div>
              <span class="step-label">Identify</span>
            </div>
            <div class="step-line" [class.active]="step > 1"></div>
            <div class="progress-step" [class.active]="step >= 2" [class.completed]="step > 2">
              <div class="step-icon"><i class="fa-solid" [class.fa-check]="step > 2" [class.fa-2]="step <= 2"></i></div>
              <span class="step-label">Verify</span>
            </div>
            <div class="step-line" [class.active]="step > 2"></div>
            <div class="progress-step" [class.active]="step >= 3" [class.completed]="step > 3">
              <div class="step-icon"><i class="fa-solid" [class.fa-check]="step > 3" [class.fa-3]="step <= 3"></i></div>
              <span class="step-label">Reset</span>
            </div>
          </div>

          <!-- Notification Toast -->
          <div class="toast-alert" *ngIf="toastMessage" [class.toast-error]="toastType === 'error'" [class.toast-success]="toastType === 'success'">
            <i class="fa-solid" [class.fa-circle-check]="toastType === 'success'" [class.fa-circle-exclamation]="toastType === 'error'"></i>
            <span>{{ toastMessage }}</span>
          </div>


          <!-- STEP 1: Enter Email -->
          <div class="step-container" *ngIf="step === 1">
            <div class="forgot-header text-center">
              <div class="icon-shield-wrapper">
                <i class="fa-solid fa-key"></i>
              </div>
              <h2>Forgot Password?</h2>
              <p>No worries! Enter your registered email address below and we'll send you a 6-digit verification code.</p>
            </div>

            <!-- Quick Demo Select -->
            <div class="demo-quick-box">
              <span class="demo-title"><i class="fa-solid fa-wand-magic-sparkles me-1"></i> Quick Demo Accounts (Click to select):</span>
              <div class="demo-pills">
                <button type="button" class="demo-pill" (click)="selectDemoEmail('rahul.sharma@example.com')">
                  <strong>Rahul Sharma:</strong> rahul.sharma@example.com
                </button>
                <button type="button" class="demo-pill" (click)="selectDemoEmail('priya.verma@techcorp.in')">
                  <strong>Priya Verma:</strong> priya.verma@techcorp.in
                </button>
                <button type="button" class="demo-pill" (click)="selectDemoEmail('admin@deservify.com')">
                  <strong>Admin Demo:</strong> admin@deservify.com
                </button>
              </div>
            </div>

            <form (ngSubmit)="sendOtp()" class="forgot-form">
              <div class="form-group">
                <label class="form-label">Account Email Address</label>
                <div class="input-with-icon">
                  <i class="fa-solid fa-envelope input-icon"></i>
                  <input 
                    type="email" 
                    class="form-control padded-icon-input" 
                    [(ngModel)]="email" 
                    name="email" 
                    placeholder="e.g. rahul.sharma@example.com" 
                    [disabled]="isLoading"
                    required>
                </div>
              </div>

              <button 
                type="submit" 
                class="btn btn-primary btn-lg full-width submit-btn" 
                [disabled]="isLoading || !email">
                <span *ngIf="!isLoading">Send Verification Code <i class="fa-solid fa-arrow-right ms-1"></i></span>
                <span *ngIf="isLoading"><i class="fa-solid fa-circle-notch fa-spin me-2"></i> Generating Code...</span>
              </button>

              <div class="back-to-login">
                <a routerLink="/login" class="link-back">
                  <i class="fa-solid fa-arrow-left me-1"></i> Back to Sign In
                </a>
              </div>
            </form>
          </div>

          <!-- STEP 2: Verify OTP Code -->
          <div class="step-container" *ngIf="step === 2">
            <div class="forgot-header text-center">
              <div class="icon-shield-wrapper icon-shield-blue">
                <i class="fa-solid fa-shield-halved"></i>
              </div>
              <h2>Enter Security Code</h2>
              <p>We've sent a 6-digit verification code to <strong class="user-email-tag">{{ email }}</strong>.</p>
            </div>

            <!-- Demo OTP Banner -->
            <div class="demo-otp-banner">
              <div class="demo-otp-header">
                <i class="fa-solid fa-key me-1"></i> Security Code for Testing: <strong class="demo-code-highlight">{{ generatedOtp }}</strong>
              </div>
              <button type="button" (click)="autoFillOtp()" class="btn-autofill-chip">
                ⚡ Auto-Fill Demo Security Code
              </button>
            </div>

            <div class="otp-container">
              <div class="otp-inputs">
                <input 
                  *ngFor="let digit of otp; let i = index" 
                  type="text" 
                  maxlength="1" 
                  class="otp-box" 
                  [id]="'otp-' + i" 
                  [(ngModel)]="otp[i]" 
                  (keyup)="onOtpInput($event, i)"
                  (focus)="onOtpFocus(i)"
                  [disabled]="isLoading"
                  autocomplete="off">
              </div>

              <div class="resend-box">
                <span *ngIf="resendTimer > 0" class="timer-text">
                  <i class="fa-solid fa-clock me-1"></i> Resend code in <strong>{{ resendTimer }}s</strong>
                </span>
                <button 
                  *ngIf="resendTimer === 0" 
                  (click)="resendOtp()" 
                  class="btn-text-link"
                  type="button">
                  <i class="fa-solid fa-rotate-right me-1"></i> Resend OTP Code
                </button>
              </div>
            </div>

            <button 
              (click)="verifyOtp()" 
              class="btn btn-primary btn-lg full-width submit-btn" 
              [disabled]="isLoading || !isOtpComplete()">
              <span *ngIf="!isLoading">Verify Code & Continue <i class="fa-solid fa-arrow-right ms-1"></i></span>
              <span *ngIf="isLoading"><i class="fa-solid fa-circle-notch fa-spin me-2"></i> Verifying Code...</span>
            </button>

            <div class="back-to-login">
              <button (click)="step = 1" [disabled]="isLoading" class="btn-text-link" type="button">
                <i class="fa-solid fa-pen-to-square me-1"></i> Change Email Address
              </button>
            </div>
          </div>

          <!-- STEP 3: Set New Password -->
          <div class="step-container" *ngIf="step === 3">
            <div class="forgot-header text-center">
              <div class="icon-shield-wrapper icon-shield-emerald">
                <i class="fa-solid fa-lock"></i>
              </div>
              <h2>Create New Password</h2>
              <p>Your identity has been verified. Set a strong new password for your account.</p>
            </div>

            <!-- Demo Password Autofill Banner -->
            <div class="demo-otp-banner">
              <div class="demo-otp-header">
                <i class="fa-solid fa-shield-halved me-1"></i> Fast Testing Shortcut
              </div>
              <button type="button" (click)="autoFillPassword()" class="btn-autofill-chip">
                ⚡ Auto-Fill Strong Test Password
              </button>
            </div>


            <form (ngSubmit)="resetPassword()" class="forgot-form">
              <!-- New Password -->
              <div class="form-group">
                <label class="form-label">New Password</label>
                <div class="input-with-icon">
                  <i class="fa-solid fa-key input-icon"></i>
                  <input 
                    [type]="showPassword ? 'text' : 'password'" 
                    class="form-control padded-icon-input" 
                    [(ngModel)]="newPassword" 
                    (ngModelChange)="checkPasswordStrength()"
                    name="newPassword" 
                    placeholder="Enter at least 8 characters" 
                    [disabled]="isLoading"
                    required>
                  <button 
                    type="button" 
                    class="password-toggle-btn" 
                    (click)="showPassword = !showPassword">
                    <i class="fa-solid" [class.fa-eye]="!showPassword" [class.fa-eye-slash]="showPassword"></i>
                  </button>
                </div>
              </div>

              <!-- Realtime Password Strength Bar -->
              <div class="strength-meter-box" *ngIf="newPassword">
                <div class="strength-bar-track">
                  <div 
                    class="strength-bar-fill" 
                    [style.width.%]="strengthScore * 25"
                    [class.strength-weak]="strengthScore === 1"
                    [class.strength-fair]="strengthScore === 2"
                    [class.strength-good]="strengthScore === 3"
                    [class.strength-strong]="strengthScore === 4">
                  </div>
                </div>
                <div class="strength-label-text">
                  <span>Strength: </span>
                  <strong [ngClass]="{
                    'text-red': strengthScore === 1,
                    'text-amber': strengthScore === 2,
                    'text-blue': strengthScore === 3,
                    'text-green': strengthScore === 4
                  }">{{ strengthLabel }}</strong>
                </div>

                <!-- Password Rules List -->
                <div class="rules-list">
                  <div class="rule-item" [class.passed]="hasMinLength">
                    <i class="fa-solid" [class.fa-check]="hasMinLength" [class.fa-xmark]="!hasMinLength"></i> 8+ characters
                  </div>
                  <div class="rule-item" [class.passed]="hasUpper">
                    <i class="fa-solid" [class.fa-check]="hasUpper" [class.fa-xmark]="!hasUpper"></i> Upper & lowercase
                  </div>
                  <div class="rule-item" [class.passed]="hasNumber">
                    <i class="fa-solid" [class.fa-check]="hasNumber" [class.fa-xmark]="!hasNumber"></i> Number (0-9)
                  </div>
                  <div class="rule-item" [class.passed]="hasSpecial">
                    <i class="fa-solid" [class.fa-check]="hasSpecial" [class.fa-xmark]="!hasSpecial"></i> Special char (!@#$)
                  </div>
                </div>
              </div>

              <!-- Confirm Password -->
              <div class="form-group mt-3">
                <label class="form-label">Confirm New Password</label>
                <div class="input-with-icon">
                  <i class="fa-solid fa-lock input-icon"></i>
                  <input 
                    [type]="showPassword ? 'text' : 'password'" 
                    class="form-control padded-icon-input" 
                    [(ngModel)]="confirmPassword" 
                    name="confirmPassword" 
                    placeholder="Re-enter your new password" 
                    [disabled]="isLoading"
                    required>
                </div>
                <div class="match-status" *ngIf="confirmPassword">
                  <span *ngIf="newPassword === confirmPassword" class="text-green"><i class="fa-solid fa-circle-check"></i> Passwords match</span>
                  <span *ngIf="newPassword !== confirmPassword" class="text-red"><i class="fa-solid fa-circle-xmark"></i> Passwords do not match</span>
                </div>
              </div>

              <button 
                type="submit" 
                class="btn btn-primary btn-lg full-width submit-btn" 
                [disabled]="isLoading || !isPasswordValid()">
                <span *ngIf="!isLoading">Update Password & Finish <i class="fa-solid fa-check ms-1"></i></span>
                <span *ngIf="isLoading"><i class="fa-solid fa-circle-notch fa-spin me-2"></i> Resetting Password...</span>
              </button>
            </form>
          </div>

          <!-- STEP 4: Success Confirmation -->
          <div class="step-container text-center" *ngIf="step === 4">
            <div class="success-animation-wrapper">
              <div class="success-shield-icon">
                <svg width="60" height="70" viewBox="0 0 24 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#10B981"/>
                  <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
                </svg>
              </div>
            </div>

            <h2 class="mt-3">Password Successfully Changed!</h2>
            <p class="success-desc">
              Your password for <strong>{{ email }}</strong> has been updated to <code>{{ newPassword || 'Deservify#2026' }}</code>. You can now sign in with your new password.
            </p>

            <button (click)="goToLogin()" class="btn btn-primary btn-lg full-width mt-4" type="button">
              <i class="fa-solid fa-right-to-bracket me-2"></i> Proceed to Sign In
            </button>
          </div>

        </div>
      </div>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .forgot-page {
      padding: 4rem 0 6rem 0;
      background: radial-gradient(circle at 50% 20%, rgba(15, 122, 92, 0.06) 0%, transparent 65%);
      min-height: calc(100vh - 72px - 300px);
    }

    .forgot-card {
      max-width: 510px;
      margin: 0 auto;
      padding: 2.5rem 2.25rem;
      border-radius: var(--radius-lg);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-md);
      transition: all 0.3s ease;
    }

    /* Step Progress Indicator */
    .step-progress-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 2rem;
      padding: 0 0.5rem;
    }

    .progress-step {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.35rem;
      z-index: 2;
    }

    .step-icon {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--bg-main);
      border: 2px solid var(--border-color);
      color: var(--text-muted);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.8rem;
      font-weight: 700;
      transition: all 0.3s ease;
    }

    .progress-step.active .step-icon {
      border-color: var(--primary);
      color: var(--primary);
      background: var(--primary-subtle);
    }

    .progress-step.completed .step-icon {
      background: var(--primary);
      border-color: var(--primary);
      color: #FFFFFF;
    }

    .step-label {
      font-size: 0.725rem;
      font-weight: 700;
      color: var(--text-muted);
      letter-spacing: 0.3px;
      text-transform: uppercase;
    }

    .progress-step.active .step-label {
      color: var(--primary);
    }

    .step-line {
      flex: 1;
      height: 2px;
      background: var(--border-color);
      margin: 0 0.5rem -1rem 0.5rem;
      transition: background 0.3s ease;
    }

    .step-line.active {
      background: var(--primary);
    }

    /* Process Loading Box */
    .process-banner-box {
      background: linear-gradient(135deg, rgba(15, 122, 92, 0.08) 0%, rgba(16, 185, 129, 0.12) 100%);
      border: 1.5px solid var(--primary);
      border-radius: var(--radius-md);
      padding: 0.9rem 1rem;
      margin-bottom: 1.5rem;
      display: flex;
      flex-direction: column;
      gap: 0.65rem;
      animation: fadeIn 0.3s ease;
    }

    .spinner-ring {
      width: 24px;
      height: 24px;
      border: 3px solid rgba(15, 122, 92, 0.2);
      border-top-color: var(--primary);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      flex-shrink: 0;
    }

    .process-text-box {
      display: flex;
      flex-direction: column;
      gap: 0.15rem;
    }

    .process-title {
      font-size: 0.925rem;
      font-weight: 800;
      color: var(--heading);
    }

    .process-sub {
      font-size: 0.8rem;
      color: var(--text-muted);
    }

    .btn-skip-chip {
      background: var(--primary);
      color: #ffffff;
      border: none;
      padding: 0.35rem 0.75rem;
      border-radius: var(--radius-sm);
      font-size: 0.775rem;
      font-weight: 700;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.2s ease;
    }

    .btn-skip-chip:hover {
      background: var(--primary-dark, #0B5C45);
      transform: translateY(-1px);
    }

    .process-bar-track {
      height: 6px;
      background: rgba(15, 122, 92, 0.15);
      border-radius: 999px;
      overflow: hidden;
    }

    .process-bar-fill {
      height: 100%;
      background: var(--primary);
      transition: width 0.4s ease;
    }

    @keyframes spin {
      100% { transform: rotate(360deg); }
    }

    /* Header Icons */
    .forgot-header h2 {
      font-size: 1.65rem;
      font-weight: 800;
      color: var(--heading);
      margin-bottom: 0.4rem;
    }

    .forgot-header p {
      color: var(--text-muted);
      font-size: 0.9rem;
      line-height: 1.5;
      margin-bottom: 1.5rem;
    }

    .icon-shield-wrapper {
      width: 56px;
      height: 56px;
      border-radius: var(--radius-md);
      background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%);
      border: 1px solid rgba(15, 122, 92, 0.2);
      color: #0F7A5C;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      margin: 0 auto 1rem auto;
      box-shadow: 0 4px 12px rgba(15, 122, 92, 0.12);
    }

    .icon-shield-blue {
      background: linear-gradient(135deg, #EFF6FF 0%, #DBEAFE 100%);
      border-color: rgba(37, 99, 235, 0.2);
      color: #2563EB;
      box-shadow: 0 4px 12px rgba(37, 99, 235, 0.12);
    }

    .icon-shield-emerald {
      background: linear-gradient(135deg, #ECFDF5 0%, #A7F3D0 100%);
      border-color: rgba(16, 185, 129, 0.2);
      color: #10B981;
    }

    .user-email-tag {
      color: var(--heading);
      background: var(--primary-subtle);
      padding: 0.15rem 0.5rem;
      border-radius: var(--radius-sm);
      word-break: break-all;
    }

    /* Demo Helper Component Styles */
    .demo-quick-box {
      background: var(--bg-subtle);
      border: 1px dashed var(--primary);
      border-radius: var(--radius-md);
      padding: 0.75rem 0.85rem;
      margin-bottom: 1.25rem;
    }

    .demo-title {
      font-size: 0.775rem;
      font-weight: 700;
      color: var(--primary);
      display: block;
      margin-bottom: 0.4rem;
    }

    .demo-pills {
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }

    .demo-pill {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-sm);
      padding: 0.35rem 0.65rem;
      font-size: 0.775rem;
      font-weight: 600;
      color: var(--heading);
      text-align: left;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .demo-pill:hover {
      border-color: var(--primary);
      background: var(--primary-subtle);
      color: var(--primary);
    }

    .demo-otp-banner {
      background: #FFFBEB;
      border: 1px solid #FDE68A;
      border-radius: var(--radius-md);
      padding: 0.75rem 0.85rem;
      margin-bottom: 1.25rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
    }

    .demo-otp-header {
      font-size: 0.825rem;
      color: #92400E;
    }

    .demo-code-highlight {
      font-size: 1rem;
      letter-spacing: 2px;
      color: #B45309;
      background: #FEF3C7;
      padding: 0.1rem 0.4rem;
      border-radius: 4px;
    }

    .btn-autofill-chip {
      background: var(--primary);
      color: #FFFFFF;
      border: none;
      padding: 0.35rem 0.85rem;
      border-radius: var(--radius-sm);
      font-size: 0.775rem;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .btn-autofill-chip:hover {
      background: var(--primary-dark, #0B5C45);
    }

    /* Toast Alert */
    .toast-alert {
      display: flex;
      align-items: center;
      gap: 0.65rem;
      padding: 0.75rem 1rem;
      border-radius: var(--radius-md);
      font-size: 0.875rem;
      font-weight: 600;
      margin-bottom: 1.5rem;
      animation: fadeIn 0.3s ease;
    }

    .toast-success {
      background: #ECFDF5;
      color: #065F46;
      border: 1px solid #A7F3D0;
    }

    .toast-error {
      background: #FEF2F2;
      color: #991B1B;
      border: 1px solid #FCA5A5;
    }

    /* Form & Input Icons */
    .forgot-form {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }

    .input-with-icon {
      position: relative;
      display: flex;
      align-items: center;
    }

    .input-icon {
      position: absolute;
      left: 1rem;
      color: var(--text-muted);
      font-size: 0.95rem;
      pointer-events: none;
    }

    .padded-icon-input {
      padding-left: 2.75rem !important;
      padding-right: 2.75rem !important;
    }

    .password-toggle-btn {
      position: absolute;
      right: 0.85rem;
      background: none;
      border: none;
      color: var(--text-muted);
      cursor: pointer;
      padding: 0.35rem;
      font-size: 1rem;
      transition: color 0.2s ease;
    }

    .password-toggle-btn:hover {
      color: var(--primary);
    }

    /* OTP Inputs */
    .otp-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1.25rem;
      margin-bottom: 1.75rem;
    }

    .otp-inputs {
      display: flex;
      gap: 0.5rem;
      justify-content: center;
    }

    .otp-box {
      width: 50px;
      height: 56px;
      text-align: center;
      font-size: 1.5rem;
      font-weight: 800;
      border: 2px solid var(--border-color);
      border-radius: var(--radius-md);
      background: var(--bg-main);
      color: var(--heading);
      transition: all 0.2s ease;
      outline: none;
    }

    .otp-box:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px var(--primary-glow);
      background: var(--bg-card);
    }

    .resend-box {
      font-size: 0.85rem;
      color: var(--text-muted);
    }

    .btn-text-link {
      background: none;
      border: none;
      color: var(--primary);
      font-weight: 700;
      cursor: pointer;
      font-size: 0.85rem;
      padding: 0;
      text-decoration: underline;
    }

    .btn-text-link:hover {
      color: var(--primary-dark, #0B5C45);
    }

    /* Password Strength Meter */
    .strength-meter-box {
      background: var(--bg-main);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 0.85rem;
      display: flex;
      flex-direction: column;
      gap: 0.6rem;
      margin-top: 0.5rem;
    }

    .strength-bar-track {
      height: 6px;
      background: var(--border-color);
      border-radius: 9999px;
      overflow: hidden;
    }

    .strength-bar-fill {
      height: 100%;
      transition: width 0.3s ease, background 0.3s ease;
      border-radius: 9999px;
    }

    .strength-weak { background: #EF4444; }
    .strength-fair { background: #F59E0B; }
    .strength-good { background: #3B82F6; }
    .strength-strong { background: #10B981; }

    .strength-label-text {
      font-size: 0.8rem;
      color: var(--text-muted);
    }

    .rules-list {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.35rem 0.65rem;
      font-size: 0.75rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
    }

    .rule-item {
      display: flex;
      align-items: center;
      gap: 0.35rem;
    }

    .rule-item.passed {
      color: #10B981;
      font-weight: 600;
    }

    .match-status {
      font-size: 0.8rem;
      font-weight: 600;
      margin-top: 0.35rem;
    }

    .text-red { color: #EF4444; }
    .text-amber { color: #F59E0B; }
    .text-blue { color: #3B82F6; }
    .text-green { color: #10B981; }

    /* Success Card */
    .success-animation-wrapper {
      margin-bottom: 1rem;
    }

    .success-shield-icon {
      width: 80px;
      height: 80px;
      background: #ECFDF5;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
      border: 3px solid #A7F3D0;
      box-shadow: 0 0 20px rgba(16, 185, 129, 0.2);
      animation: popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .success-desc {
      color: var(--text-muted);
      font-size: 0.925rem;
      line-height: 1.5;
      margin-top: 0.5rem;
    }

    /* Back link */
    .back-to-login {
      text-align: center;
      margin-top: 0.85rem;
    }

    .link-back {
      font-weight: 600;
      font-size: 0.875rem;
      color: var(--text-muted);
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .link-back:hover {
      color: var(--primary);
    }

    .full-width {
      width: 100%;
    }

    @keyframes popIn {
      0% { transform: scale(0.6); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-6px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 480px) {
      .forgot-card {
        padding: 1.75rem 1.25rem;
      }

      .otp-box {
        width: 42px;
        height: 48px;
        font-size: 1.25rem;
      }
    }
  `]
})
export class ForgotPasswordComponent {
  router = inject(Router);
  cdRef = inject(ChangeDetectorRef);
  ngZone = inject(NgZone);

  step = 1;
  email = '';
  generatedOtp = '849201';
  otp = ['', '', '', '', '', ''];
  newPassword = '';
  confirmPassword = '';
  showPassword = false;
  
  isLoading = false;
  loadingTitle = '';
  loadingSeconds = 5;
  processTimer: any;
  onCompleteCallback: (() => void) | null = null;

  resendTimer = 0;
  timerInterval: any;

  toastMessage: string | null = null;
  toastType: 'success' | 'error' | null = null;

  // Password rules checks
  hasMinLength = false;
  hasUpper = false;
  hasNumber = false;
  hasSpecial = false;
  strengthScore = 0;
  strengthLabel = 'Weak';

  selectDemoEmail(email: string) {
    this.email = email;
    this.showToast(`Selected demo account: ${email}`, 'success');
  }

  runProcess(title: string, onComplete: () => void) {
    this.isLoading = true;
    this.loadingTitle = title;
    this.toastMessage = null;

    if (this.processTimer) clearTimeout(this.processTimer);

    this.processTimer = setTimeout(() => {
      this.ngZone.run(() => {
        this.isLoading = false;
        if (onComplete) onComplete();
        this.cdRef.detectChanges();
      });
    }, 400);
  }

  skipProcessNow() {
    this.finishProcess();
  }

  finishProcess() {
    if (this.processTimer) clearTimeout(this.processTimer);
    this.isLoading = false;
    this.cdRef.detectChanges();
  }

  sendOtp() {
    if (!this.email || !this.email.includes('@')) {
      this.showToast('Please enter a valid email address.', 'error');
      return;
    }

    // Generate random 6-digit OTP code for dummy testing
    this.generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();

    this.runProcess('Sending Security Code...', () => {
      this.step = 2;
      this.showToast(`OTP Code (${this.generatedOtp}) sent to ${this.email}!`, 'success');
      this.startResendTimer();
    });
  }

  autoFillOtp() {
    this.otp = this.generatedOtp.split('');
    this.showToast('Demo OTP Code auto-filled!', 'success');
  }

  onOtpInput(event: KeyboardEvent, index: number) {
    const input = event.target as HTMLInputElement;
    const value = input.value;

    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`) as HTMLInputElement;
      if (nextInput) nextInput.focus();
    } else if (event.key === 'Backspace' && index > 0 && !value) {
      const prevInput = document.getElementById(`otp-${index - 1}`) as HTMLInputElement;
      if (prevInput) prevInput.focus();
    }
  }

  onOtpFocus(index: number) {
    const input = document.getElementById(`otp-${index}`) as HTMLInputElement;
    if (input) input.select();
  }

  isOtpComplete(): boolean {
    return this.otp.every(d => d.trim().length === 1);
  }

  verifyOtp() {
    if (!this.isOtpComplete()) return;

    this.runProcess('Verifying 6-Digit Security Code...', () => {
      this.step = 3;
      this.showToast('Security Code verified! Now enter your new password.', 'success');
    });
  }

  startResendTimer() {
    this.resendTimer = 30;
    if (this.timerInterval) clearInterval(this.timerInterval);

    this.timerInterval = setInterval(() => {
      this.ngZone.run(() => {
        this.resendTimer--;
        if (this.resendTimer <= 0) {
          clearInterval(this.timerInterval);
        }
        this.cdRef.detectChanges();
      });
    }, 1000);
  }

  resendOtp() {
    this.generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otp = ['', '', '', '', '', ''];
    this.showToast(`New OTP Code generated: ${this.generatedOtp}`, 'success');
    this.startResendTimer();
  }

  autoFillPassword() {
    const strongPass = 'Deservify#2026';
    this.newPassword = strongPass;
    this.confirmPassword = strongPass;
    this.checkPasswordStrength();
    this.showToast('Strong test password auto-filled!', 'success');
  }

  checkPasswordStrength() {
    const p = this.newPassword;
    this.hasMinLength = p.length >= 8;
    this.hasUpper = /[A-Z]/.test(p) && /[a-z]/.test(p);
    this.hasNumber = /[0-9]/.test(p);
    this.hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(p);

    let score = 0;
    if (this.hasMinLength) score++;
    if (this.hasUpper) score++;
    if (this.hasNumber) score++;
    if (this.hasSpecial) score++;

    this.strengthScore = score;

    switch (score) {
      case 0:
      case 1:
        this.strengthLabel = 'Weak';
        break;
      case 2:
        this.strengthLabel = 'Fair';
        break;
      case 3:
        this.strengthLabel = 'Good';
        break;
      case 4:
        this.strengthLabel = 'Strong';
        break;
    }
  }

  isPasswordValid(): boolean {
    return (
      this.hasMinLength &&
      this.hasNumber &&
      this.newPassword === this.confirmPassword &&
      this.confirmPassword.length > 0
    );
  }

  resetPassword() {
    if (!this.isPasswordValid()) return;

    this.runProcess('Updating Account Security Credentials...', () => {
      this.step = 4;
    });
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  showToast(message: string, type: 'success' | 'error') {
    this.toastMessage = message;
    this.toastType = type;
    this.cdRef.detectChanges();
    setTimeout(() => {
      this.ngZone.run(() => {
        if (this.toastMessage === message) {
          this.toastMessage = null;
          this.cdRef.detectChanges();
        }
      });
    }, 4000);
  }
}
