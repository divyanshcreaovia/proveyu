import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { RecruiterService } from '../../core/services/recruiter.service';

@Component({
  selector: 'app-recruiter-invites',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="invites-page">
      <div class="container">
        
        <div class="top-bar">
          <a routerLink="/dashboard/recruiter" class="back-link">← Back to Recruiter Dashboard</a>
          <button (click)="createNewInvite()" class="btn btn-primary btn-sm">
            + New Candidate Invite
          </button>
        </div>

        <div class="page-title-box">
          <h2>📩 Direct Candidate Interview Invites</h2>
          <p>Track direct interview requests sent to invigilated Skill Passport holders.</p>
        </div>

        <!-- Invites Table Card -->
        <div class="deservify-card invites-card">
          <div class="invites-table-responsive">
            <table class="invites-table">
              <thead>
                <tr>
                  <th>Candidate Name</th>
                  <th>Target Role</th>
                  <th>Invigilated Score</th>
                  <th>Proposed Interview Time</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let item of invites">
                  <td>
                    <div class="cand-cell">
                      <strong>{{ item.candidateName }}</strong>
                      <span class="sub">ID: {{ item.passportId }}</span>
                    </div>
                  </td>
                  <td>
                    <span class="role-text">{{ item.role }}</span>
                  </td>
                  <td>
                    <span class="badge badge-teal">{{ item.passportScore }} / 100</span>
                  </td>
                  <td>
                    <span class="time-text">🗓️ {{ item.date }}</span>
                  </td>
                  <td>
                    <span class="status-pill" [ngClass]="{
                      'status-accepted': item.status === 'accepted',
                      'status-pending': item.status === 'pending',
                      'status-declined': item.status === 'declined'
                    }">{{ item.status | uppercase }}</span>
                  </td>
                  <td>
                    <button *ngIf="item.status === 'accepted'" class="btn btn-sm btn-primary" (click)="launchMeeting(item)">
                      🎥 Join Video Call
                    </button>
                    <button *ngIf="item.status === 'pending'" class="btn btn-sm btn-secondary" (click)="resendReminder(item)">
                      🔔 Send Reminder
                    </button>
                    <span *ngIf="item.status === 'declined'" class="text-muted text-sm">Archived</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .invites-page {
      padding: 2.5rem 0 5rem 0;
      background: var(--bg-subtle);
      min-height: calc(100vh - 72px - 300px);
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    .back-link {
      font-weight: 600;
      color: var(--primary-dark);
      font-size: 0.9rem;
    }
    .page-title-box h2 {
      font-size: 1.8rem;
      margin-bottom: 0.35rem;
    }
    .page-title-box p {
      color: var(--text-muted);
      font-size: 0.95rem;
      margin-bottom: 1.5rem;
    }
    .invites-table-responsive {
      overflow-x: auto;
    }
    .invites-table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }
    .invites-table th {
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--text-muted);
      padding: 0.85rem 1rem;
      border-bottom: 2px solid var(--border-color);
    }
    .invites-table td {
      padding: 1rem;
      border-bottom: 1px solid var(--border-color);
      font-size: 0.9rem;
    }
    .cand-cell {
      display: flex;
      flex-direction: column;
    }
    .cand-cell strong { color: var(--heading); }
    .cand-cell .sub { font-size: 0.75rem; color: var(--text-muted); }
    .role-text { font-weight: 600; color: var(--primary-dark); }
    .time-text { color: var(--heading); font-size: 0.85rem; }

    .status-pill {
      font-size: 0.75rem;
      font-weight: 800;
      padding: 0.25rem 0.65rem;
      border-radius: var(--radius-full);
      display: inline-block;
    }
    .status-accepted {
      background: #D1FAE5;
      color: #065F46;
    }
    .status-pending {
      background: #FEF3C7;
      color: #92400E;
    }
    .status-declined {
      background: #FEE2E2;
      color: #991B1B;
    }
    .text-sm { font-size: 0.8rem; }
  `]
})
export class RecruiterInvitesComponent {
  recruiterService = inject(RecruiterService);

  invites = [
    {
      passportId: 'CF-9842',
      candidateName: 'Rahul Sharma',
      role: 'Fullstack Java & Angular Engineer',
      passportScore: 92,
      date: '2026-09-24 at 02:30 PM',
      status: 'accepted'
    },
    {
      passportId: 'CF-7412',
      candidateName: 'Priya Nambiar',
      role: 'QA & Automation Engineer',
      passportScore: 95,
      date: '2026-09-25 at 11:00 AM',
      status: 'pending'
    },
    {
      passportId: 'CF-8820',
      candidateName: 'Amitav Ghosh',
      role: 'Python & Cloud Developer',
      passportScore: 86,
      date: '2026-09-22 at 04:00 PM',
      status: 'accepted'
    }
  ];

  createNewInvite() {
    alert('Select candidate from the Verified Candidates search page to trigger a new interview invitation!');
  }

  launchMeeting(item: any) {
    alert(`Launching Deservify Verified Video Room with ${item.candidateName} for ${item.role}`);
  }

  resendReminder(item: any) {
    alert(`Reminder notification sent to ${item.candidateName}!`);
  }
}
