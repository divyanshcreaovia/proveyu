import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { RecruiterService } from '../../core/services/recruiter.service';
import { SkillPassport } from '../../core/models/deservify.models';
import { PassportModalComponent } from '../../shared/components/passport-modal/passport-modal.component';

@Component({
  selector: 'app-recruiter-candidates',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent, PassportModalComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="candidates-page">
      <div class="container">
        
        <div class="top-bar">
          <a routerLink="/dashboard/recruiter" class="back-link">← Back to Recruiter Dashboard</a>
          <span class="badge badge-gold">100% In-Person Invigilated Talent Pool</span>
        </div>

        <div class="page-title-box">
          <h2>🔍 Search Verified Skill Passports</h2>
          <p>Browse candidates who have completed supervised in-person TCS iON examinations. Zero resume fluff.</p>
        </div>

        <!-- Filter Controls Bar -->
        <div class="deservify-card filters-card">
          <div class="filters-grid">
            <div class="filter-item search-box">
              <label class="filter-label">Search Candidate / College / Skill</label>
              <input 
                type="text" 
                class="form-control" 
                [(ngModel)]="searchQuery" 
                placeholder="e.g. Java, System Design, RV College, Rahul">
            </div>

            <div class="filter-item">
              <label class="filter-label">Role Track</label>
              <select class="form-control" [(ngModel)]="selectedTrack">
                <option value="all">All Tracks</option>
                <option value="Universal Fresher Competency">Universal Fresher</option>
                <option value="Java Backend (Spring Boot)">Java Backend</option>
                <option value="QA & Automation Testing">QA & Testing</option>
                <option value="Python Backend & Data">Python & Data</option>
              </select>
            </div>

            <div class="filter-item">
              <label class="filter-label">Min Passport Score ({{ minScore }}+)</label>
              <input 
                type="range" 
                class="form-range" 
                min="60" 
                max="95" 
                step="5" 
                [(ngModel)]="minScore">
            </div>
          </div>
        </div>

        <!-- Candidates Grid -->
        <div class="candidates-grid">
          <div class="candidate-card deservify-card" *ngFor="let cand of filteredCandidates">
            <div class="cand-header">
              <div class="cand-meta-col">
                <span class="badge badge-gold">{{ cand.tierBadge }}</span>
                <h3 class="cand-name">{{ cand.unlocked ? cand.realName : cand.maskedName }}</h3>
                <p class="cand-college">{{ cand.college }} ({{ cand.experienceLevel }})</p>
              </div>

              <div class="score-circle">
                <span class="score-num">{{ cand.overallScore }}</span>
                <span class="score-lbl">SCORE</span>
              </div>
            </div>

            <div class="rec-roles">
              <span>🎯 <strong>Primary Track:</strong> {{ cand.track }}</span>
              <span>📍 Location: {{ cand.location }} • Verified at TCS iON Digital Zone</span>
            </div>

            <div class="mini-comps">
              <span class="mini-comp-chip">System Design: <strong>88%</strong></span>
              <span class="mini-comp-chip">Backend APIs: <strong>92%</strong></span>
              <span class="mini-comp-chip">DSA & Algorithmic: <strong>85%</strong></span>
            </div>

            <div class="cand-card-footer">
              <button (click)="openPassportModal(cand)" class="btn btn-secondary btn-sm">
                📜 View Passport Preview
              </button>
              <button (click)="requestInterview(cand)" class="btn btn-primary btn-sm">
                ⚡ Send Interview Invite
              </button>
            </div>
          </div>
        </div>

      </div>
    </main>

    <app-passport-modal
      [isOpen]="isModalOpen"
      [passport]="selectedPassport"
      (close)="isModalOpen = false">
    </app-passport-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .candidates-page {
      padding: 2.5rem 0 5rem 0;
      background: var(--bg-subtle);
      min-height: calc(100vh - 72px - 300px);
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }
    .back-link {
      font-weight: 600;
      color: var(--primary-dark);
      font-size: 0.9rem;
    }
    .page-title-box h2 {
      font-size: 1.8rem;
      margin-bottom: 0.35rem;
    }
    .page-title-box p {
      color: var(--text-muted);
      font-size: 0.95rem;
      margin-bottom: 1.5rem;
    }
    .filters-card {
      margin-bottom: 2rem;
      padding: 1.25rem;
    }
    .filters-grid {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr;
      gap: 1.25rem;
      align-items: center;
    }
    .filter-label {
      font-size: 0.8rem;
      font-weight: 700;
      color: var(--heading);
      margin-bottom: 0.35rem;
      display: block;
    }
    .form-range {
      width: 100%;
      accent-color: var(--primary);
    }
    .candidates-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
    }
    .cand-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }
    .cand-name {
      font-size: 1.25rem;
      margin: 0.25rem 0 0.15rem 0;
      color: var(--heading);
    }
    .cand-college {
      font-size: 0.85rem;
      color: var(--text-muted);
    }
    .score-circle {
      width: 68px;
      height: 68px;
      border-radius: 50%;
      background: var(--primary);
      color: #FFFFFF;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 10px rgba(15, 122, 92, 0.2);
    }
    .score-num {
      font-family: 'Outfit', sans-serif;
      font-size: 1.4rem;
      font-weight: 800;
      line-height: 1;
    }
    .score-lbl {
      font-size: 0.55rem;
      font-weight: 700;
      letter-spacing: 0.5px;
    }
    .rec-roles {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
      font-size: 0.825rem;
      color: var(--heading);
      background: var(--bg-subtle);
      padding: 0.75rem;
      border-radius: var(--radius-sm);
      margin-bottom: 1rem;
    }
    .mini-comps {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-bottom: 1.25rem;
    }
    .mini-comp-chip {
      background: var(--bg-card);
      color: var(--text-main);
      border: 1px solid var(--border-color);
      padding: 0.25rem 0.6rem;
      border-radius: var(--radius-sm);
      font-size: 0.775rem;
    }
    .cand-card-footer {
      display: flex;
      justify-content: space-between;
      gap: 0.75rem;
      border-top: 1px dashed var(--border-color);
      padding-top: 1rem;
    }

    @media (max-width: 850px) {
      .filters-grid { grid-template-columns: 1fr; }
      .candidates-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class RecruiterCandidatesComponent {
  recruiterService = inject(RecruiterService);

  searchQuery = '';
  selectedTrack = 'all';
  minScore = 70;

  isModalOpen = false;
  selectedPassport: SkillPassport | null = null;

  get filteredCandidates() {
    return this.recruiterService.candidatesCatalog().filter(c => {
      const name = c.unlocked ? c.realName || c.maskedName : c.maskedName;
      const matchesSearch = !this.searchQuery ||
        name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        c.college.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        c.track.toLowerCase().includes(this.searchQuery.toLowerCase());

      const matchesTrack = this.selectedTrack === 'all' || c.track === this.selectedTrack;
      const matchesScore = c.overallScore >= this.minScore;

      return matchesSearch && matchesTrack && matchesScore;
    });
  }

  openPassportModal(candidate: any) {
    const candidateName = candidate.unlocked ? candidate.realName || candidate.maskedName : candidate.maskedName;
    this.selectedPassport = {
      passportId: `PASSPORT-${candidate.candidateId}`,
      issueDate: '2026-09-10',
      overallScore: candidate.overallScore,
      tierBadge: candidate.tierBadge,
      verificationCenter: 'TCS iON Digital Zone, Bengaluru',
      primaryRoleRecommendation: candidate.track,
      secondaryRoleRecommendation: 'Software Development Engineer (SDE-1)',
      competencies: [
        { name: 'System Architecture & Design', score: candidate.overallScore, description: 'Supervised hands-on test', status: 'Strong' },
        { name: 'API Engineering & Security', score: Math.min(100, candidate.overallScore + 3), description: 'Supervised hands-on test', status: 'Strong' },
        { name: 'Data Structures & Algorithms', score: Math.max(50, candidate.overallScore - 4), description: 'Supervised hands-on test', status: 'Proficient' }
      ],
      practicalBuildSummary: 'Designed and deployed scalable REST microservices under 3-hour invigilated sandbox environment.',
      evaluatorFeedback: ['Clean modular architecture', 'Passed 100% automated unit tests', 'Zero external help detected'],
      invigilatorVerified: true
    };
    this.isModalOpen = true;
  }

  requestInterview(candidate: any) {
    const name = candidate.unlocked ? candidate.realName || candidate.maskedName : candidate.maskedName;
    const date = prompt(`Propose interview date & time for ${name}:`, '2026-09-25 at 03:00 PM');
    if (date) {
      alert(`Interview Invitation sent to ${name} for ${date}!`);
    }
  }
}
