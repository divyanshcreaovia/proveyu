import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { SuccessModalComponent } from '../../shared/components/success-modal/success-modal.component';
import { AuthService } from '../../core/services/auth.service';
import { RecruiterService } from '../../core/services/recruiter.service';
import { UserRole } from '../../core/models/deservify.models';

@Component({
  selector: 'app-recruiter-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent, SuccessModalComponent],
  template: `
    <app-navbar [minimal]="true"></app-navbar>

    <main class="register-page">
      <div class="container container-narrow">
        <div class="register-card deservify-card">
          <!-- Stepper Header -->
          <div class="stepper-header">
            <div class="stepper-step" [class.active]="currentStep === 1" [class.completed]="currentStep > 1">
              <div class="step-number">1</div>
              <span class="step-label">Org Type</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 2" [class.completed]="currentStep > 2">
              <div class="step-number">2</div>
              <span class="step-label">Company Details</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 3" [class.completed]="currentStep > 3">
              <div class="step-number">3</div>
              <span class="step-label">Contact Person</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 4" [class.completed]="currentStep > 4">
              <div class="step-number">4</div>
              <span class="step-label">Hiring Needs</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 5" [class.completed]="currentStep > 5">
              <div class="step-number">5</div>
              <span class="step-label">Review & Submit</span>
            </div>
          </div>

          <!-- Step Header -->
          <div class="step-title-box">
            <h2>{{ getStepTitle() }}</h2>
            <p class="step-sub">{{ getStepSub() }}</p>
          </div>

          <!-- STEP 1: Organization Type Selector -->
          <div *ngIf="currentStep === 1" class="step-form-content">
            <div class="org-cards-grid">
              <!-- Startup Card -->
              <div 
                class="org-type-card" 
                [class.selected]="formData.orgType === 'startup'" 
                (click)="formData.orgType = 'startup'">
                <div class="card-icon">🚀</div>
                <h3>High-Growth Startup</h3>
                <p>Early/Series A-C startups hiring fast, self-sufficient engineers without resume overhead.</p>
              </div>

              <!-- Agency Card -->
              <div 
                class="org-type-card" 
                [class.selected]="formData.orgType === 'agency'" 
                (click)="formData.orgType = 'agency'">
                <div class="card-icon">🤝</div>
                <h3>Placement Agency</h3>
                <p>Staffing & agency partners placing candidates across multiple corporate clients. Activates "My Clients" management tab.</p>
              </div>

              <!-- Enterprise Company Card -->
              <div 
                class="org-type-card" 
                [class.selected]="formData.orgType === 'company'" 
                (click)="formData.orgType = 'company'">
                <div class="card-icon">🏢</div>
                <h3>Enterprise / Company</h3>
                <p>Direct employer hiring tech talent with GST/CIN verification and dedicated recruiter seats.</p>
              </div>
            </div>
          </div>

          <!-- STEP 2: Organization Details (Branching) -->
          <div *ngIf="currentStep === 2" class="step-form-content">
            <div class="form-group">
              <label class="form-label">Organization Name</label>
              <input type="text" class="form-control" [(ngModel)]="formData.orgName" placeholder="e.g. Apex Placement Solutions" required>
            </div>

            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Official Website URL</label>
                <input type="url" class="form-control" [(ngModel)]="formData.website" placeholder="https://example.com" required>
              </div>

              <div class="form-group">
                <label class="form-label">Industry Sector</label>
                <select class="form-control" [(ngModel)]="formData.industry">
                  <option value="IT Services & Consulting">IT Services & Consulting</option>
                  <option value="Placement & Staffing Agency">Placement & Staffing Agency</option>
                  <option value="FinTech & Banking">FinTech & Banking</option>
                  <option value="SaaS & Cloud Software">SaaS & Cloud Software</option>
                  <option value="E-Commerce & Retail">E-Commerce & Retail</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Company Size</label>
              <select class="form-control" [(ngModel)]="formData.companySize">
                <option value="1-10 Employees">1-10 Employees (Early Startup)</option>
                <option value="11-50 Employees">11-50 Employees</option>
                <option value="51-200 Employees">51-200 Employees (Agency / Growth)</option>
                <option value="201-500 Employees">201-500 Employees</option>
                <option value="500+ Employees">500+ Employees (Enterprise)</option>
              </select>
            </div>

            <!-- Branching Conditional Field: Agency License for Agencies -->
            <div class="form-group conditional-box" *ngIf="formData.orgType === 'agency'">
              <label class="form-label">Agency License / Staffing Registration Number (Optional)</label>
              <input type="text" class="form-control" [(ngModel)]="formData.agencyLicense" placeholder="LIC-KA-2024-8849">
              <span class="form-hint">Enables multi-client mapping and agency commission invoice generation.</span>
            </div>

            <!-- Branching Conditional Field: GST / CIN for Companies & Startups -->
            <div class="form-group conditional-box" *ngIf="formData.orgType === 'company' || formData.orgType === 'startup'">
              <label class="form-label">Company GSTIN or Corporate CIN</label>
              <input type="text" class="form-control" [(ngModel)]="formData.gstOrCin" placeholder="29ABCDE1234F1Z5">
              <span class="form-hint">Used for official corporate billing and candidate unlock tax invoices.</span>
            </div>
          </div>

          <!-- STEP 3: Contact Person Details -->
          <div *ngIf="currentStep === 3" class="step-form-content">
            <div class="form-group">
              <label class="form-label">Contact Person Name</label>
              <input type="text" class="form-control" [(ngModel)]="formData.contactName" placeholder="e.g. Vikram Malhotra" required>
            </div>

            <div class="form-group">
              <label class="form-label">Designation / Role</label>
              <input type="text" class="form-control" [(ngModel)]="formData.contactRole" placeholder="e.g. Lead Placement Director / Head of Talent">
            </div>

            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Official Work Email</label>
                <input type="email" class="form-control" [(ngModel)]="formData.email" placeholder="vikram@apexplacements.com" required>
              </div>

              <div class="form-group">
                <label class="form-label">Direct Mobile Number</label>
                <input type="tel" class="form-control" [(ngModel)]="formData.phone" placeholder="+91 98112 34567" required>
              </div>
            </div>
          </div>

          <!-- STEP 4: Hiring Needs -->
          <div *ngIf="currentStep === 4" class="step-form-content">
            <div class="form-group">
              <label class="form-label">Target Skill Domains (Select all that apply)</label>
              <div class="domains-chips-grid">
                <label 
                  *ngFor="let domain of domainOptions" 
                  class="chip-card" 
                  [class.selected]="isDomainSelected(domain.name)"
                  (click)="toggleDomain(domain.name)">
                  <span>{{ domain.icon }} {{ domain.name }}</span>
                </label>
              </div>
            </div>

            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Expected Monthly Hiring Volume</label>
                <select class="form-control" [(ngModel)]="formData.monthlyVolume">
                  <option value="1-5 Candidates">1-5 Candidates / month</option>
                  <option value="5-15 Candidates">5-15 Candidates / month</option>
                  <option value="15-50 Candidates">15-50 Candidates / month</option>
                  <option value="50+ Bulk Hiring">50+ Bulk Hiring (Batch / Agency)</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Experience Level Focus</label>
                <select class="form-control" [(ngModel)]="formData.experienceFocus">
                  <option value="fresher">Freshers Only (Universal Competency)</option>
                  <option value="experienced">Experienced Only (1-5 Yrs)</option>
                  <option value="both">Both Freshers & Experienced Hires</option>
                </select>
              </div>
            </div>
          </div>

          <!-- STEP 5: Review & Submit -->
          <div *ngIf="currentStep === 5" class="step-form-content">
            <div class="review-summary-card">
              <h3 class="review-title">Review Recruiter Account Setup</h3>
              <div class="review-grid">
                <div class="review-item">
                  <span class="lbl">Organization Type:</span>
                  <span class="val uppercase">{{ formData.orgType }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">Company Name:</span>
                  <span class="val">{{ formData.orgName }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">Contact Person:</span>
                  <span class="val">{{ formData.contactName }} ({{ formData.contactRole }})</span>
                </div>
                <div class="review-item">
                  <span class="lbl">Work Email:</span>
                  <span class="val">{{ formData.email }}</span>
                </div>
                <div class="review-item full-width">
                  <span class="lbl">Hiring Domains:</span>
                  <span class="val highlight-domains">{{ formData.hiringDomains.join(', ') }}</span>
                </div>
                <div class="review-item" *ngIf="formData.agencyLicense">
                  <span class="lbl">Agency Registration:</span>
                  <span class="val text-green">{{ formData.agencyLicense }}</span>
                </div>
              </div>
            </div>

            <label class="checkbox-row">
              <input type="checkbox" [(ngModel)]="termsAgreed" required>
              <span>I agree to Proveyu's Verified Candidate Integrity Policy and anti-circumvention terms.</span>
            </label>
          </div>

          <!-- Actions -->
          <div class="stepper-actions">
            <button 
              *ngIf="currentStep > 1" 
              (click)="prevStep()" 
              class="btn btn-secondary">
              ← Back
            </button>

            <button 
              *ngIf="currentStep < 5" 
              (click)="nextStep()" 
              class="btn btn-primary margin-left-auto">
              Continue to Step {{ currentStep + 1 }} →
            </button>

            <button 
              *ngIf="currentStep === 5" 
              (click)="submitRecruiterRegistration()" 
              [disabled]="!termsAgreed" 
              class="btn btn-primary btn-lg margin-left-auto">
              Create Recruiter Account & Open Dashboard →
            </button>
          </div>
        </div>
      </div>
    </main>

    <app-success-modal
      [isOpen]="showSuccessModal"
      title="Recruiter Registration Completed!"
      message="Your organization account is active. You have received 12 Complimentary Candidate Passport Unlock Credits."
      actionLabel="Open Recruiter Workspace →"
      [details]="modalDetails"
      (confirmed)="onModalConfirmed()">
    </app-success-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .register-page {
      padding: 4rem 0 6rem 0;
      background: radial-gradient(circle at 50% 15%, rgba(15, 122, 92, 0.06) 0%, transparent 60%);
    }
    .register-card {
      padding: 2.5rem;
    }
    .step-title-box {
      margin-bottom: 2rem;
      text-align: center;
    }
    .step-title-box h2 {
      font-size: 1.6rem;
      color: var(--heading);
    }
    .step-sub {
      color: var(--text-muted);
      font-size: 0.95rem;
    }
    .step-form-content {
      margin-bottom: 2rem;
    }
    .org-cards-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.25rem;
    }
    .org-type-card {
      border: 2px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      cursor: pointer;
      background: var(--bg-main);
      transition: all var(--transition-fast);
    }
    .org-type-card:hover {
      border-color: rgba(15, 122, 92, 0.4);
    }
    .org-type-card.selected {
      border-color: var(--primary);
      background: var(--primary-subtle);
      box-shadow: 0 0 0 3px var(--primary-glow);
    }
    .card-icon {
      font-size: 2rem;
      margin-bottom: 0.75rem;
    }
    .org-type-card h3 {
      font-size: 1.1rem;
      margin-bottom: 0.5rem;
      color: var(--heading);
    }
    .org-type-card p {
      font-size: 0.85rem;
      color: var(--text-muted);
    }

    .form-grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .conditional-box {
      background: var(--bg-subtle);
      padding: 1rem;
      border-radius: var(--radius-md);
      border: 1px dashed var(--primary);
    }

    .domains-chips-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 0.75rem;
    }
    .chip-card {
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 0.75rem;
      font-size: 0.85rem;
      font-weight: 600;
      cursor: pointer;
      background: var(--bg-subtle);
      display: flex;
      align-items: center;
    }
    .chip-card.selected {
      border-color: var(--primary);
      background: var(--primary-subtle);
      color: var(--primary);
    }

    .review-summary-card {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .review-title {
      font-size: 1.05rem;
      margin-bottom: 1rem;
    }
    .review-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.85rem;
      font-size: 0.875rem;
    }
    .review-item {
      display: flex;
      flex-direction: column;
    }
    .review-item.full-width {
      grid-column: span 2;
    }
    .review-item .lbl {
      color: var(--text-muted);
      font-size: 0.775rem;
    }
    .review-item .val {
      font-weight: 600;
      color: var(--heading);
    }
    .uppercase {
      text-transform: uppercase;
    }
    .highlight-domains {
      color: var(--primary);
      font-weight: 700;
    }
    .text-green {
      color: var(--primary);
      font-weight: 700;
    }
    .checkbox-row {
      display: flex;
      gap: 0.65rem;
      align-items: flex-start;
      font-size: 0.875rem;
      cursor: pointer;
    }
    .checkbox-row input {
      margin-top: 3px;
    }
    .stepper-actions {
      display: flex;
      align-items: center;
      border-top: 1px solid var(--border-color);
      padding-top: 1.5rem;
    }
    .margin-left-auto {
      margin-left: auto;
    }

    @media (max-width: 768px) {
      .org-cards-grid, .form-grid-2, .review-grid {
        grid-template-columns: 1fr;
      }
      .review-item.full-width {
        grid-column: span 1;
      }
    }
  `]
})
export class RecruiterRegisterComponent {
  authService = inject(AuthService);
  recruiterService = inject(RecruiterService);
  router = inject(Router);

  currentStep = 1;
  showSuccessModal = false;
  termsAgreed = true;

  formData = {
    orgType: 'agency' as 'startup' | 'agency' | 'company',
    orgName: 'Apex Placement Solutions',
    website: 'https://apexplacements.example.com',
    industry: 'Placement & Staffing Agency',
    companySize: '51-200 Employees',
    contactName: 'Vikram Malhotra',
    contactRole: 'Lead Placement Director',
    email: 'vikram@apexplacements.com',
    phone: '+91 98112 34567',
    agencyLicense: 'LIC-KA-2024-8849',
    gstOrCin: '',
    hiringDomains: ['Universal Fresher', 'Java Backend', 'QA & Testing'],
    monthlyVolume: '15-50 Candidates',
    experienceFocus: 'both' as 'fresher' | 'experienced' | 'both'
  };

  domainOptions = [
    { name: 'Universal Fresher', icon: '✨' },
    { name: 'Java Backend', icon: '☕' },
    { name: 'QA & Testing', icon: '🧪' },
    { name: 'Python Backend', icon: '🐍' },
    { name: 'Web Development', icon: '💻' }
  ];

  modalDetails: Array<{ label: string; value: string }> = [];

  getStepTitle(): string {
    switch (this.currentStep) {
      case 1: return 'Step 1: Select Organization Type';
      case 2: return 'Step 2: Organization Profile Details';
      case 3: return 'Step 3: Primary Contact Person';
      case 4: return 'Step 4: Hiring Requirements & Volume';
      case 5: return 'Step 5: Review & Account Activation';
      default: return '';
    }
  }

  getStepSub(): string {
    switch (this.currentStep) {
      case 1: return 'Choose Startup, Placement Agency, or Corporate Enterprise.';
      case 2: return 'Provide company domain, size, and regulatory licensing.';
      case 3: return 'Details of the talent director or lead recruiter.';
      case 4: return 'Select target domains and experience filters.';
      case 5: return 'Confirm organization details to claim 12 unlock credits.';
      default: return '';
    }
  }

  isDomainSelected(name: string): boolean {
    return this.formData.hiringDomains.includes(name);
  }

  toggleDomain(name: string) {
    if (this.isDomainSelected(name)) {
      this.formData.hiringDomains = this.formData.hiringDomains.filter(d => d !== name);
    } else {
      this.formData.hiringDomains.push(name);
    }
  }

  nextStep() {
    if (this.currentStep < 5) this.currentStep++;
  }

  prevStep() {
    if (this.currentStep > 1) this.currentStep--;
  }

  submitRecruiterRegistration() {
    let role: UserRole = 'recruiter_agency';
    if (this.formData.orgType === 'startup') role = 'recruiter_startup';
    else if (this.formData.orgType === 'company') role = 'recruiter_company';

    this.modalDetails = [
      { label: 'Organization Name', value: this.formData.orgName },
      { label: 'Account Type', value: this.formData.orgType.toUpperCase() },
      { label: 'Free Unlock Credits', value: '12 Credits Granted' }
    ];

    this.authService.login(this.formData.email, role);
    this.showSuccessModal = true;
  }

  onModalConfirmed() {
    this.showSuccessModal = false;
    this.router.navigate(['/dashboard/recruiter']);
  }
}
