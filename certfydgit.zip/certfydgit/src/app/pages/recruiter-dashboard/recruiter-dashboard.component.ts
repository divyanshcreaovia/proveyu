import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { PassportModalComponent } from '../../shared/components/passport-modal/passport-modal.component';
import { SuccessModalComponent } from '../../shared/components/success-modal/success-modal.component';
import { RecruiterService } from '../../core/services/recruiter.service';
import { CandidateService } from '../../core/services/candidate.service';
import { AuthService } from '../../core/services/auth.service';
import { PipelineCandidate, SkillPassport } from '../../core/models/deservify.models';

@Component({
  selector: 'app-recruiter-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NavbarComponent,
    FooterComponent,
    PassportModalComponent,
    SuccessModalComponent
  ],
  template: `
    <app-navbar></app-navbar>

    <main class="dashboard-page">
      <div class="container">
        <!-- Dashboard Top Header -->
        <div class="dash-header">
          <div>
            <div class="badge-group">
              <span class="badge badge-teal" *ngIf="recruiterProfile().orgType === 'agency'"><i class="fa-solid fa-handshake me-1"></i> Placement Agency Portal</span>
              <span class="badge badge-teal" *ngIf="recruiterProfile().orgType === 'startup'"><i class="fa-solid fa-rocket me-1"></i> Startup Workspace</span>
              <span class="badge badge-teal" *ngIf="recruiterProfile().orgType === 'company'"><i class="fa-solid fa-building me-1"></i> Enterprise Hiring Portal</span>
              <span class="badge badge-gold"><i class="fa-solid fa-bolt me-1"></i> {{ recruiterProfile().unlockedCredits }} Unlock Credits Left</span>
            </div>
            <h1 class="dash-title">{{ recruiterProfile().orgName }}</h1>
            <p class="dash-sub">
              Logged in as: <strong>{{ recruiterProfile().contactName }}</strong> ({{ recruiterProfile().contactRole }})
            </p>
          </div>

          <div class="header-action-group">
            <button (click)="openPostReqModal()" class="btn btn-primary btn-lg">
              <i class="fa-solid fa-plus me-2"></i> Post New Hiring Requirement
            </button>
          </div>
        </div>

        <!-- Metrics Strip -->
        <div class="metrics-grid">
          <div class="metric-card deservify-card">
            <span class="metric-icon"><i class="fa-solid fa-clipboard-list text-primary"></i></span>
            <div>
              <span class="val">{{ recruiterService.jobRequirements().length }}</span>
              <span class="lbl">Active Requirements</span>
            </div>
          </div>

          <div class="metric-card deservify-card">
            <span class="metric-icon"><i class="fa-solid fa-lock-open text-success"></i></span>
            <div>
              <span class="val">{{ getUnlockedCount() }}</span>
              <span class="lbl">Candidates Unlocked</span>
            </div>
          </div>

          <div class="metric-card deservify-card">
            <span class="metric-icon"><i class="fa-solid fa-bullseye text-warning"></i></span>
            <div>
              <span class="val">{{ getInterviewingCount() }}</span>
              <span class="lbl">Interviews Scheduled</span>
            </div>
          </div>

          <div class="metric-card deservify-card">
            <span class="metric-icon"><i class="fa-solid fa-award text-info"></i></span>
            <div>
              <span class="val">{{ getHiredCount() }}</span>
              <span class="lbl">Verified Hires Closed</span>
            </div>
          </div>
        </div>

        <!-- Dashboard Navigation Tabs -->
        <div class="dashboard-tabs">
          <button 
            class="dash-tab-btn" 
            [class.active]="activeTab === 'browse'" 
            (click)="activeTab = 'browse'">
            <i class="fa-solid fa-magnifying-glass me-1"></i> Browse Verified Candidates
          </button>

          <button 
            class="dash-tab-btn" 
            [class.active]="activeTab === 'pipeline'" 
            (click)="activeTab = 'pipeline'">
            <i class="fa-solid fa-bars-staggered me-1"></i> Hiring Pipeline (Kanban)
          </button>

          <button 
            class="dash-tab-btn" 
            [class.active]="activeTab === 'requirements'" 
            (click)="activeTab = 'requirements'">
            <i class="fa-solid fa-file-lines me-1"></i> Posted Requirements ({{ recruiterService.jobRequirements().length }})
          </button>

          <!-- Placement Agency Exclusive Tab -->
          <button 
            *ngIf="recruiterProfile().orgType === 'agency'" 
            class="dash-tab-btn agency-tab" 
            [class.active]="activeTab === 'agency_clients'" 
            (click)="activeTab = 'agency_clients'">
            <i class="fa-solid fa-handshake-simple me-1"></i> My Clients & Commission Tracking
          </button>
        </div>

        <!-- TAB 1: BROWSE VERIFIED CANDIDATES -->
        <div id="candidates" *ngIf="activeTab === 'browse'" class="tab-content">
          <!-- Filters Bar -->
          <div class="filter-bar deservify-card">
            <div class="filter-group">
              <label class="filter-lbl">Domain Track:</label>
              <select class="form-control" [(ngModel)]="filterDomain">
                <option value="ALL">All Tracks</option>
                <option value="Universal Fresher Competency">Universal Fresher</option>
                <option value="Java Backend (Spring Boot)">Java Backend</option>
                <option value="QA & Automation Testing">QA & Testing</option>
                <option value="Python Backend & Data">Python Backend</option>
              </select>
            </div>

            <div class="filter-group">
              <label class="filter-lbl">Experience Filter:</label>
              <select class="form-control" [(ngModel)]="filterExp">
                <option value="ALL">All Experience</option>
                <option value="Fresher">Freshers Only</option>
                <option value="Experienced">Experienced Hires</option>
              </select>
            </div>

            <div class="filter-group">
              <label class="filter-lbl">Min Passport Score: {{ filterMinScore }}</label>
              <input type="range" class="range-slider" min="70" max="98" [(ngModel)]="filterMinScore">
            </div>
          </div>

          <!-- Candidates Cards Catalog Grid -->
          <div class="candidates-grid">
            <div class="candidate-catalog-card deservify-card" *ngFor="let candidate of filteredCandidates">
              
              <!-- Card Header -->
              <div class="cand-header">
                <div class="cand-info">
                  <img [src]="candidate.photoAvatar" alt="Avatar" class="avatar-small">
                  <div>
                    <h3 class="cand-name" *ngIf="candidate.unlocked">{{ candidate.realName }}</h3>
                    <h3 class="cand-name masked" *ngIf="!candidate.unlocked">{{ candidate.maskedName }}</h3>
                    <span class="cand-college">{{ candidate.college }} | {{ candidate.location }}</span>
                  </div>
                </div>
                <span class="badge badge-gold">{{ candidate.tierBadge }}</span>
              </div>

              <!-- Track & Score Pill -->
              <div class="track-score-bar">
                <div class="track-lbl">{{ candidate.track }}</div>
                <div class="score-pill-badge">
                  <span class="score-num">{{ candidate.overallScore }}</span>
                  <span class="score-lbl">VERIFIED SCORE</span>
                </div>
              </div>

              <!-- Unlocked Identity / Masked Notice -->
              <div class="identity-box" *ngIf="candidate.unlocked; else maskedBox">
                <div class="unlocked-header">✓ UNLOCKED CONTACT DETAILS</div>
                <div class="contact-line">📧 {{ candidate.realEmail }}</div>
                <div class="contact-line">📱 {{ candidate.realPhone }}</div>
                <div class="contact-line" *ngIf="candidate.targetClient">🏢 Client Mapped: <strong>{{ candidate.targetClient }}</strong></div>
              </div>

              <ng-template #maskedBox>
                <div class="identity-box masked-box">
                  <span class="lock-icon">🔒</span>
                  <span>Identity Masked to Prevent Bias. Unlock to view full contact details & direct interview scheduling.</span>
                </div>
              </ng-template>

              <!-- Card Action Buttons -->
              <div class="cand-card-actions">
                <button (click)="viewPassportDetail(candidate)" class="btn btn-outline-primary btn-sm">
                  📜 View Skill Passport
                </button>

                <button 
                  *ngIf="!candidate.unlocked" 
                  (click)="unlockCandidate(candidate.candidateId)" 
                  class="btn btn-primary btn-sm margin-left-auto">
                  🔓 Unlock Contact (1 Credit)
                </button>

                <span *ngIf="candidate.unlocked" class="unlocked-tag margin-left-auto">
                  ✓ Profile Unlocked
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- TAB 2: PIPELINE TRACKER (KANBAN) -->
        <div id="pipeline" *ngIf="activeTab === 'pipeline'" class="tab-content">

          <!-- Column 1: Shortlisted -->
          <div class="kanban-board">
            <div class="kanban-col">
              <div class="col-header shortlisted-header">
                <h3>Shortlisted ({{ getStageCount('shortlisted') }})</h3>
              </div>
              <div class="kanban-cards-list">
                <div class="kanban-card" *ngFor="let c of getCandidatesByStage('shortlisted')">
                  <div class="k-title">{{ c.unlocked ? c.realName : c.maskedName }}</div>
                  <div class="k-track">{{ c.track }}</div>
                  <div class="k-score">Score: <strong>{{ c.overallScore }}/100</strong></div>
                  <div class="k-actions">
                    <button (click)="moveStage(c.candidateId, 'interviewing')" class="btn btn-sm btn-secondary">
                      Move to Interview →
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Column 2: Interviewing -->
            <div class="kanban-col">
              <div class="col-header interviewing-header">
                <h3>Interviewing ({{ getStageCount('interviewing') }})</h3>
              </div>
              <div class="kanban-cards-list">
                <div class="kanban-card" *ngFor="let c of getCandidatesByStage('interviewing')">
                  <div class="k-title">{{ c.unlocked ? c.realName : c.maskedName }}</div>
                  <div class="k-track">{{ c.track }}</div>
                  <div class="k-score">Score: <strong>{{ c.overallScore }}/100</strong></div>
                  <div class="k-actions">
                    <button (click)="moveStage(c.candidateId, 'offered')" class="btn btn-sm btn-primary">
                      Extend Offer →
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Column 3: Offered -->
            <div class="kanban-col">
              <div class="col-header offered-header">
                <h3>Offered ({{ getStageCount('offered') }})</h3>
              </div>
              <div class="kanban-cards-list">
                <div class="kanban-card" *ngFor="let c of getCandidatesByStage('offered')">
                  <div class="k-title">{{ c.unlocked ? c.realName : c.maskedName }}</div>
                  <div class="k-track">{{ c.track }}</div>
                  <div class="k-score">Score: <strong>{{ c.overallScore }}/100</strong></div>
                  <div class="k-actions">
                    <button (click)="moveStage(c.candidateId, 'hired')" class="btn btn-sm btn-gold">
                      Mark as Hired 🎉
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- Column 4: Hired -->
            <div class="kanban-col">
              <div class="col-header hired-header">
                <h3>Hired ({{ getStageCount('hired') }})</h3>
              </div>
              <div class="kanban-cards-list">
                <div class="kanban-card hired-card" *ngFor="let c of getCandidatesByStage('hired')">
                  <div class="k-title">🎉 {{ c.unlocked ? c.realName : c.maskedName }}</div>
                  <div class="k-track">{{ c.track }}</div>
                  <div class="k-score">Score: <strong>{{ c.overallScore }}/100</strong></div>
                  <span class="hired-badge">CLOSED & PLACED</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- TAB 3: POSTED REQUIREMENTS -->
        <div id="requests" *ngIf="activeTab === 'requirements'" class="tab-content">
          <div class="reqs-header-flex">
            <h2>Active Job Requirements</h2>
            <button (click)="openPostReqModal()" class="btn btn-primary btn-sm">
              ➕ Post New Requirement
            </button>
          </div>

          <div class="requirements-list">
            <div class="req-card deservify-card" *ngFor="let req of recruiterService.jobRequirements()">
              <div class="req-top">
                <div>
                  <span class="badge badge-teal">{{ req.domain }}</span>
                  <h3 class="req-title">{{ req.title }}</h3>
                  <span class="client-tag" *ngIf="req.clientCompany">Client: <strong>{{ req.clientCompany }}</strong></span>
                </div>
                <div class="req-salary">{{ req.salaryRange }}</div>
              </div>

              <div class="req-meta-grid">
                <div>📍 Location: <strong>{{ req.location }}</strong></div>
                <div>🎓 Experience: <strong>{{ req.experienceLevel }}</strong></div>
                <div>🎯 Min Passport Score: <strong>{{ req.minScore }}+</strong></div>
                <div>👥 Candidates Matched: <strong>{{ req.applicantsCount }}</strong></div>
              </div>
            </div>
          </div>
        </div>

        <!-- TAB 4: MY CLIENTS & COMMISSION (PLACEMENT AGENCY EXCLUSIVE) -->
        <div id="agency_clients" *ngIf="activeTab === 'agency_clients'" class="tab-content">
          <div class="agency-banner deservify-card">
            <div class="banner-text">
              <span class="badge badge-gold">Placement Agency Master Workspace</span>
              <h2>Client Companies & Commission Mapping</h2>
              <p>Map invigilated candidates to client openings and track placement commissions.</p>
            </div>
          </div>

          <div class="clients-grid">
            <div class="client-card deservify-card" *ngFor="let client of recruiterService.agencyClients()">
              <div class="client-head">
                <div>
                  <h3 class="c-name">{{ client.clientName }}</h3>
                  <span class="c-ind">{{ client.industry }}</span>
                </div>
                <span class="comm-badge">{{ client.commissionRate }} Commission</span>
              </div>

              <div class="client-stats-row">
                <div class="stat">
                  <span class="val">{{ client.activeOpenings }}</span>
                  <span class="lbl">Active Roles</span>
                </div>
                <div class="stat">
                  <span class="val text-green">{{ client.placedCandidates }}</span>
                  <span class="lbl">Candidates Placed</span>
                </div>
              </div>

              <div class="client-contact">
                <span>👤 Contact: {{ client.contactPerson }}</span>
              </div>

              <button class="btn btn-secondary btn-sm full-width margin-top">
                Map Verified Candidate to {{ client.clientName }} →
              </button>
            </div>
          </div>
        </div>

      </div>
    </main>

    <!-- Post Requirement Modal -->
    <div class="modal-overlay" *ngIf="isPostReqModalOpen" (click)="closeOnPostReqBackdrop($event)">
      <div class="modal-content padded">
        <div class="modal-top">
          <h2>Post New Verified Requirement</h2>
          <button (click)="isPostReqModalOpen = false" class="close-btn">&times;</button>
        </div>

        <form (ngSubmit)="submitNewReq()" class="req-form">
          <div class="form-group">
            <label class="form-label">Job Title</label>
            <input type="text" class="form-control" [(ngModel)]="newReqForm.title" name="title" placeholder="e.g. Associate QA Automation Engineer" required>
          </div>

          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label">Domain Track</label>
              <select class="form-control" [(ngModel)]="newReqForm.domain" name="domain">
                <option value="QA & Testing">QA & Testing</option>
                <option value="Java Backend">Java Backend</option>
                <option value="Universal Fresher">Universal Fresher</option>
                <option value="Python Backend">Python Backend</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Target Client (Agencies)</label>
              <input type="text" class="form-control" [(ngModel)]="newReqForm.clientCompany" name="client" placeholder="e.g. CloudScale Tech (Optional)">
            </div>
          </div>

          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label">Location</label>
              <input type="text" class="form-control" [(ngModel)]="newReqForm.location" name="location" placeholder="Bengaluru / Remote">
            </div>

            <div class="form-group">
              <label class="form-label">Salary / CTC Package</label>
              <input type="text" class="form-control" [(ngModel)]="newReqForm.salaryRange" name="salary" placeholder="₹8 - 12 LPA">
            </div>
          </div>

          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label">Min Passport Score Threshold</label>
              <input type="number" class="form-control" [(ngModel)]="newReqForm.minScore" name="minScore" placeholder="85">
            </div>

            <div class="form-group">
              <label class="form-label">Experience Level</label>
              <select class="form-control" [(ngModel)]="newReqForm.experienceLevel" name="exp">
                <option value="Fresher / 0-1 Yrs">Fresher / 0-1 Yrs</option>
                <option value="1-3 Yrs">1-3 Yrs</option>
                <option value="3-5 Yrs">3-5 Yrs</option>
              </select>
            </div>
          </div>

          <div class="modal-actions margin-top">
            <button type="button" (click)="isPostReqModalOpen = false" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">Post Requirement →</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Skill Passport Modal -->
    <app-passport-modal
      [isOpen]="isPassportModalOpen"
      [passport]="selectedPassport"
      (close)="isPassportModalOpen = false">
    </app-passport-modal>

    <!-- Confirmation Modal -->
    <app-success-modal
      [isOpen]="isSuccessModalOpen"
      [title]="successTitle"
      [message]="successMsg"
      actionLabel="Got It"
      (confirmed)="isSuccessModalOpen = false"
      (closed)="isSuccessModalOpen = false">
    </app-success-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .dashboard-page {
      padding: 3rem 0 5rem 0;
      background: var(--bg-subtle);
      min-height: calc(100vh - 72px - 300px);
    }
    .dash-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      flex-wrap: wrap;
      gap: 1rem;
    }
    .badge-group {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 0.35rem;
    }
    .dash-title {
      font-size: 2rem;
      margin: 0;
      color: var(--heading);
    }
    .dash-sub {
      color: var(--text-muted);
      font-size: 0.9rem;
    }

    /* Metrics Grid */
    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.25rem;
      margin-bottom: 2rem;
    }
    .metric-card {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1.25rem;
    }
    .metric-icon { font-size: 2rem; }
    .metric-card .val {
      font-family: 'Outfit', sans-serif;
      font-size: 1.8rem;
      font-weight: 800;
      color: var(--heading);
      line-height: 1;
      display: block;
    }
    .metric-card .lbl {
      font-size: 0.775rem;
      color: var(--text-muted);
      font-weight: 600;
    }

    /* Tabs Bar */
    .dashboard-tabs {
      display: flex;
      gap: 0.5rem;
      background: var(--bg-card);
      padding: 0.5rem;
      border-radius: var(--radius-lg);
      border: 1px solid var(--border-color);
      margin-bottom: 2rem;
      overflow-x: auto;
      box-shadow: var(--shadow-sm);
    }
    .dash-tab-btn {
      padding: 0.75rem 1.35rem;
      background: transparent;
      border: 1px solid transparent;
      border-radius: var(--radius-md);
      font-size: 0.925rem;
      font-weight: 600;
      color: var(--text-muted);
      cursor: pointer;
      white-space: nowrap;
      transition: all var(--transition-fast);
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .dash-tab-btn:hover {
      color: var(--heading);
      background: var(--bg-subtle);
    }
    .dash-tab-btn.active {
      background: var(--primary);
      color: #FFFFFF !important;
      font-weight: 700;
      box-shadow: 0 4px 12px rgba(15, 122, 92, 0.25);
    }
    .agency-tab {
      color: var(--accent-gold);
    }
    .agency-tab:hover {
      background: rgba(245, 158, 11, 0.1);
    }
    .agency-tab.active {
      background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
      color: #FFFFFF !important;
      box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
    }

    /* Filters Bar */
    .filter-bar {
      display: flex;
      gap: 1.5rem;
      align-items: center;
      margin-bottom: 1.5rem;
      flex-wrap: wrap;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.25rem;
    }
    .filter-group {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .filter-lbl {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--heading);
      white-space: nowrap;
    }

    /* Candidate Catalog Grid */
    .candidates-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
    }
    .candidate-catalog-card {
      display: flex;
      flex-direction: column;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
    }
    .cand-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }
    .cand-info {
      display: flex;
      align-items: center;
      gap: 0.85rem;
    }
    .avatar-small {
      width: 46px;
      height: 46px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid var(--primary);
    }
    .cand-name {
      font-size: 1.05rem;
      margin: 0;
      color: var(--heading);
    }
    .cand-name.masked {
      color: var(--heading);
      font-weight: 700;
    }
    .cand-college {
      font-size: 0.775rem;
      color: var(--text-muted);
      display: block;
    }

    .track-score-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--bg-subtle);
      padding: 0.65rem 0.85rem;
      border-radius: var(--radius-md);
      margin-bottom: 1rem;
    }
    .track-lbl {
      font-weight: 700;
      font-size: 0.85rem;
      color: var(--heading);
    }
    .score-pill-badge {
      display: flex;
      align-items: center;
      gap: 0.35rem;
      background: var(--primary);
      color: #FFFFFF;
      padding: 0.2rem 0.6rem;
      border-radius: var(--radius-full);
    }
    .score-pill-badge .score-num {
      font-weight: 800;
      font-size: 0.9rem;
    }
    .score-pill-badge .score-lbl {
      font-size: 0.55rem;
      font-weight: 700;
    }

    .identity-box {
      background: var(--primary-subtle);
      border: 1px solid rgba(15, 122, 92, 0.3);
      border-radius: var(--radius-md);
      padding: 0.75rem;
      font-size: 0.825rem;
      margin-bottom: 1.25rem;
    }
    .unlocked-header {
      font-weight: 800;
      color: var(--primary);
      font-size: 0.7rem;
      margin-bottom: 0.35rem;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .contact-line {
      color: var(--heading);
      margin-bottom: 0.15rem;
      font-weight: 600;
    }
    .masked-box {
      background: rgba(245, 158, 11, 0.12);
      border: 1px solid rgba(245, 158, 11, 0.3);
      color: #F59E0B;
      border-radius: var(--radius-md);
      padding: 0.85rem 1rem;
      font-size: 0.825rem;
      line-height: 1.4;
      display: flex;
      gap: 0.6rem;
      align-items: center;
      margin-bottom: 1.25rem;
    }

    .cand-card-actions {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-top: auto;
    }
    .unlocked-tag {
      font-size: 0.8rem;
      font-weight: 700;
      color: var(--primary);
    }

    /* Kanban Board */
    .kanban-board {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.25rem;
    }
    .kanban-col {
      background: var(--bg-subtle);
      border-radius: var(--radius-lg);
      padding: 1rem;
      min-height: 500px;
    }
    .col-header {
      padding: 0.65rem 0.85rem;
      border-radius: var(--radius-md);
      margin-bottom: 1rem;
    }
    .col-header h3 {
      font-size: 0.95rem;
      margin: 0;
      color: #FFFFFF;
    }
    .shortlisted-header { background: #64748B; }
    .interviewing-header { background: var(--primary); }
    .offered-header { background: #7C3AED; }
    .hired-header { background: #10B981; }

    .kanban-cards-list {
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
    }
    .kanban-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1rem;
      box-shadow: var(--shadow-sm);
      color: var(--text-main);
    }
    .k-title { font-weight: 700; font-size: 0.95rem; color: var(--heading); margin-bottom: 0.25rem; }
    .k-track { font-size: 0.775rem; color: var(--primary); font-weight: 600; margin-bottom: 0.25rem; }
    .k-score { font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.75rem; }
    .k-actions button { width: 100%; }
    .hired-badge {
      display: inline-block;
      font-size: 0.7rem;
      font-weight: 800;
      background: var(--primary-subtle);
      color: var(--primary);
      padding: 0.25rem 0.5rem;
      border-radius: var(--radius-full);
      margin-top: 0.5rem;
    }

    /* Posted Requirements */
    .reqs-header-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }
    .requirements-list {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }
    .req-card {
      padding: 1.5rem;
    }
    .req-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }
    .req-title { font-size: 1.2rem; margin: 0.25rem 0; }
    .client-tag { font-size: 0.8rem; color: var(--primary); font-weight: 600; }
    .req-salary { font-family: 'Outfit', sans-serif; font-size: 1.1rem; font-weight: 800; color: var(--heading); }
    .req-meta-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1rem;
      font-size: 0.85rem;
      color: var(--text-muted);
      background: var(--bg-subtle);
      padding: 0.85rem;
      border-radius: var(--radius-md);
    }

    /* Agency Clients */
    .agency-banner {
      background: linear-gradient(135deg, #1A1F2B 0%, #111827 100%);
      color: #FFFFFF;
      margin-bottom: 2rem;
    }
    .agency-banner h2 { color: #FFFFFF; font-size: 1.8rem; margin: 0.35rem 0; }
    .agency-banner p { color: #9CA3AF; font-size: 0.95rem; }

    .clients-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.5rem;
    }
    .client-card {
      display: flex;
      flex-direction: column;
    }
    .client-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }
    .c-name { font-size: 1.15rem; margin: 0; }
    .c-ind { font-size: 0.775rem; color: var(--text-muted); }
    .comm-badge {
      background: var(--accent-gold-light);
      color: #92400E;
      font-size: 0.75rem;
      font-weight: 800;
      padding: 0.2rem 0.5rem;
      border-radius: var(--radius-full);
    }
    .client-stats-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
      background: var(--bg-subtle);
      padding: 0.75rem;
      border-radius: var(--radius-md);
      margin-bottom: 1rem;
      text-align: center;
    }
    .client-stats-row .val { font-weight: 800; font-size: 1.2rem; display: block; }
    .client-stats-row .lbl { font-size: 0.7rem; color: var(--text-muted); }
    .client-contact { font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem; }

    /* Modals */
    .close-btn {
      background: var(--bg-subtle);
      border: none;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      font-size: 1.35rem;
      color: var(--text-muted);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all var(--transition-fast);
      line-height: 1;
    }
    .close-btn:hover {
      background: var(--border-color);
      color: var(--heading);
    }
    .modal-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid var(--border-color);
    }
    .modal-top h2 {
      color: var(--heading);
      margin: 0;
      font-size: 1.3rem;
    }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .modal-actions { display: flex; justify-content: flex-end; gap: 1rem; }

    .margin-left-auto { margin-left: auto; }
    .full-width { width: 100%; }
    .margin-top { margin-top: auto; }

    @media (max-width: 900px) {
      .metrics-grid, .candidates-grid, .kanban-board, .clients-grid, .req-meta-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class RecruiterDashboardComponent implements OnInit {
  recruiterService = inject(RecruiterService);
  candidateService = inject(CandidateService);
  authService = inject(AuthService);
  route = inject(ActivatedRoute);

  recruiterProfile = this.recruiterService.recruiterProfile;
  catalog = this.recruiterService.candidatesCatalog;

  activeTab: 'browse' | 'pipeline' | 'requirements' | 'agency_clients' = 'browse';

  ngOnInit() {
    this.route.fragment.subscribe(fragment => {
      if (fragment === 'candidates' || fragment === 'browse') {
        this.activeTab = 'browse';
      } else if (fragment === 'requests' || fragment === 'requirements') {
        this.activeTab = 'requirements';
      } else if (fragment === 'pipeline') {
        this.activeTab = 'pipeline';
      } else if (fragment === 'agency_clients') {
        this.activeTab = 'agency_clients';
      }
    });
  }

  // Filters
  filterDomain = 'ALL';
  filterExp = 'ALL';
  filterMinScore = 80;

  // Modals state
  isPostReqModalOpen = false;
  isPassportModalOpen = false;
  isSuccessModalOpen = false;
  successTitle = '';
  successMsg = '';

  selectedPassport: SkillPassport | null = null;

  newReqForm = {
    title: 'Associate QA Automation Engineer',
    domain: 'QA & Testing',
    experienceLevel: 'Fresher / 0-1 Yrs',
    minScore: 85,
    location: 'Bengaluru / Remote',
    salaryRange: '₹8 - 10 LPA',
    clientCompany: 'CloudScale Technologies'
  };

  get filteredCandidates(): PipelineCandidate[] {
    return this.catalog().filter(c => {
      if (this.filterDomain !== 'ALL' && c.track !== this.filterDomain) return false;
      if (this.filterExp === 'Fresher' && !c.experienceLevel.toLowerCase().includes('fresher')) return false;
      if (this.filterExp === 'Experienced' && c.experienceLevel.toLowerCase().includes('fresher')) return false;
      if (c.overallScore < this.filterMinScore) return false;
      return true;
    });
  }

  getUnlockedCount(): number {
    return this.catalog().filter(c => c.unlocked).length;
  }

  getInterviewingCount(): number {
    return this.catalog().filter(c => c.stage === 'interviewing').length;
  }

  getHiredCount(): number {
    return this.catalog().filter(c => c.stage === 'hired').length;
  }

  getCandidatesByStage(stage: PipelineCandidate['stage']): PipelineCandidate[] {
    return this.catalog().filter(c => c.stage === stage);
  }

  getStageCount(stage: PipelineCandidate['stage']): number {
    return this.getCandidatesByStage(stage).length;
  }

  unlockCandidate(id: string) {
    const success = this.recruiterService.unlockCandidate(id);
    if (success) {
      this.successTitle = 'Candidate Identity Unlocked!';
      this.successMsg = '1 Credit deducted. Candidate contact details and Skill Passport are now unmasked.';
      this.isSuccessModalOpen = true;
    } else {
      alert('Insufficient unlock credits! Please top up your subscription.');
    }
  }

  moveStage(candidateId: string, stage: PipelineCandidate['stage']) {
    this.recruiterService.updateStage(candidateId, stage);
  }

  viewPassportDetail(candidate: PipelineCandidate) {
    // Show mock passport from candidate service
    this.selectedPassport = this.candidateService.currentProfile().passport || null;
    this.isPassportModalOpen = true;
  }

  openPostReqModal() {
    this.isPostReqModalOpen = true;
  }

  closeOnPostReqBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-overlay')) {
      this.isPostReqModalOpen = false;
    }
  }

  submitNewReq() {
    this.recruiterService.addRequirement({
      title: this.newReqForm.title,
      domain: this.newReqForm.domain,
      experienceLevel: this.newReqForm.experienceLevel,
      minScore: Number(this.newReqForm.minScore),
      location: this.newReqForm.location,
      salaryRange: this.newReqForm.salaryRange,
      clientCompany: this.newReqForm.clientCompany
    });

    this.isPostReqModalOpen = false;
    this.successTitle = 'Hiring Requirement Posted!';
    this.successMsg = 'Matching candidates with verified passports will be automatically notified.';
    this.isSuccessModalOpen = true;
  }
}
