import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { SuccessModalComponent } from '../../shared/components/success-modal/success-modal.component';
import { CandidateService } from '../../core/services/candidate.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-candidate-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent, SuccessModalComponent],
  template: `
    <app-navbar [minimal]="true"></app-navbar>

    <main class="register-page">
      <div class="container container-narrow">
        <!-- Card Container -->
        <div class="register-card deservify-card">
          <!-- Stepper Header -->
          <div class="stepper-header">
            <div class="stepper-step" [class.active]="currentStep === 1" [class.completed]="currentStep > 1">
              <div class="step-number">1</div>
              <span class="step-label">Basic Info</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 2" [class.completed]="currentStep > 2">
              <div class="step-number">2</div>
              <span class="step-label">Education</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 3" [class.completed]="currentStep > 3">
              <div class="step-number">3</div>
              <span class="step-label">Domain Track</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 4" [class.completed]="currentStep > 4">
              <div class="step-number">4</div>
              <span class="step-label">ID Upload</span>
            </div>
            <div class="stepper-step" [class.active]="currentStep === 5" [class.completed]="currentStep > 5">
              <div class="step-number">5</div>
              <span class="step-label">Review & Submit</span>
            </div>
          </div>

          <!-- Step Title -->
          <div class="step-title-box">
            <h2>{{ getStepTitle() }}</h2>
            <p class="step-sub">{{ getStepSub() }}</p>
          </div>

          <!-- STEP 1: Basic Info -->
          <div *ngIf="currentStep === 1" class="step-form-content">
            <div class="form-group">
              <label class="form-label">Full Name (as per Govt ID)</label>
              <input type="text" class="form-control" [(ngModel)]="formData.fullName" placeholder="e.g. Rahul Sharma" required>
            </div>

            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input type="email" class="form-control" [(ngModel)]="formData.email" placeholder="rahul.sharma@example.com" required>
              <span class="form-hint">Your Admit Card & Skill Passport will be sent here.</span>
            </div>

            <div class="form-group">
              <label class="form-label">Phone Number</label>
              <input type="tel" class="form-control" [(ngModel)]="formData.phone" placeholder="+91 98765 43210" required>
            </div>

            <div class="form-group">
              <label class="form-label">Current City (Preferred Test Region)</label>
              <select class="form-control" [(ngModel)]="formData.city">
                <option value="Bengaluru">Bengaluru</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Delhi NCR">Delhi NCR</option>
                <option value="Pune">Pune</option>
                <option value="Mumbai">Mumbai</option>
                <option value="Chennai">Chennai</option>
              </select>
            </div>
          </div>

          <!-- STEP 2: Education -->
          <div *ngIf="currentStep === 2" class="step-form-content">
            <div class="form-group">
              <label class="form-label">College / University Name</label>
              <input type="text" class="form-control" [(ngModel)]="formData.college" placeholder="e.g. RV College of Engineering" required>
            </div>

            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-label">Degree</label>
                <select class="form-control" [(ngModel)]="formData.degree">
                  <option value="B.Tech">B.Tech / B.E.</option>
                  <option value="BCA">BCA</option>
                  <option value="M.Tech">M.Tech / M.E.</option>
                  <option value="MCA">MCA</option>
                  <option value="Diploma">Diploma CS/IT</option>
                  <option value="B.Sc CS">B.Sc Computer Science</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Graduation Year</label>
                <select class="form-control" [(ngModel)]="formData.graduationYear">
                  <option [ngValue]="2026">2026 (Final Year)</option>
                  <option [ngValue]="2025">2025 (Passed out)</option>
                  <option [ngValue]="2024">2024</option>
                  <option [ngValue]="2023">2023</option>
                  <option [ngValue]="2027">2027</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Stream / Branch</label>
              <input type="text" class="form-control" [(ngModel)]="formData.stream" placeholder="Computer Science & Engineering">
            </div>

            <div class="form-group">
              <label class="form-label">Current Work Status</label>
              <div class="status-radio-group">
                <label class="radio-card" [class.selected]="formData.status === 'student'">
                  <input type="radio" name="status" [(ngModel)]="formData.status" value="student">
                  <span>🎓 Student</span>
                </label>
                <label class="radio-card" [class.selected]="formData.status === 'fresher'">
                  <input type="radio" name="status" [(ngModel)]="formData.status" value="fresher">
                  <span>✨ Fresher (0 Exp)</span>
                </label>
                <label class="radio-card" [class.selected]="formData.status === 'experienced'">
                  <input type="radio" name="status" [(ngModel)]="formData.status" value="experienced">
                  <span>💼 Experienced</span>
                </label>
              </div>
            </div>
          </div>

          <!-- STEP 3: Domain Track Selection -->
          <div *ngIf="currentStep === 3" class="step-form-content">
            <p class="track-info-note">
              Choose the primary track you wish to get verified in at the partner exam centre.
            </p>

            <div class="track-cards-list">
              <div 
                *ngFor="let track of availableTracks" 
                class="track-card" 
                [class.selected]="formData.selectedTrack === track.id"
                (click)="formData.selectedTrack = track.id">
                <div class="track-card-header">
                  <span class="track-icon">{{ track.icon }}</span>
                  <div>
                    <span class="recommended-badge" *ngIf="track.recommended">RECOMMENDED</span>
                    <h3 class="track-title">{{ track.title }}</h3>
                  </div>
                </div>
                <p class="track-desc">{{ track.desc }}</p>
                <div class="track-footer">
                  <span class="duration">⏱️ {{ track.duration }}</span>
                  <span class="format">📍 {{ track.format }}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- STEP 4: ID Verification Upload -->
          <div *ngIf="currentStep === 4" class="step-form-content">
            <!-- Explanation Box -->
            <div class="id-explanation-box">
              <div class="shield-icon">🛡️</div>
              <div>
                <h4>Why Photo & ID Verification is Required</h4>
                <p>
                  Proveyu invigilators physically verify your identity at the test centre gate. Uploading your photo and ID ahead of time ensures instant biometric matching and seamless Admit Card generation.
                </p>
              </div>
            </div>

            <div class="upload-grid-2">
              <!-- Passport Photo Upload -->
              <div class="upload-dropzone">
                <span class="upload-icon">📷</span>
                <span class="upload-label">Upload Passport Photograph</span>
                <span class="upload-sub">Clear front face picture (JPEG/PNG)</span>
                <input type="file" (change)="onPhotoSelected($event)" accept="image/*" class="file-input">
                <div class="upload-preview" *ngIf="photoPreview">
                  <img [src]="photoPreview" alt="Photo Preview">
                  <span class="preview-tag">✓ Photo Uploaded</span>
                </div>
              </div>

              <!-- Govt / College ID Upload -->
              <div class="upload-dropzone">
                <span class="upload-icon">🪪</span>
                <span class="upload-label">Upload Govt ID / College ID Card</span>
                <span class="upload-sub">Aadhaar, PAN, Passport or Student ID (PDF/JPEG)</span>
                <input type="file" (change)="onIdSelected($event)" accept="image/*,.pdf" class="file-input">
                <div class="upload-preview" *ngIf="idPreview">
                  <span class="file-icon">📄</span>
                  <span class="preview-tag">✓ ID Document Attached</span>
                </div>
              </div>
            </div>
          </div>

          <!-- STEP 5: Review & Consent -->
          <div *ngIf="currentStep === 5" class="step-form-content">
            <div class="review-summary-card">
              <h3 class="review-title">Review Your Registration Details</h3>
              <div class="review-grid">
                <div class="review-item">
                  <span class="lbl">Full Name:</span>
                  <span class="val">{{ formData.fullName }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">Email / Phone:</span>
                  <span class="val">{{ formData.email }} | {{ formData.phone }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">City / Region:</span>
                  <span class="val">{{ formData.city }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">College / Degree:</span>
                  <span class="val">{{ formData.college }} ({{ formData.degree }} - {{ formData.graduationYear }})</span>
                </div>
                <div class="review-item full-width">
                  <span class="lbl">Selected Verification Track:</span>
                  <span class="val highlight-track">{{ getSelectedTrackTitle() }}</span>
                </div>
                <div class="review-item">
                  <span class="lbl">Photo ID Status:</span>
                  <span class="val text-green">✓ Attached & Ready</span>
                </div>
              </div>
            </div>

            <!-- Consent Checkboxes -->
            <div class="consent-group">
              <label class="checkbox-row">
                <input type="checkbox" [(ngModel)]="consentInvigilation" required>
                <span>I understand I must present original government ID at the physical partner test centre.</span>
              </label>

              <label class="checkbox-row">
                <input type="checkbox" [(ngModel)]="consentData" required>
                <span>I consent to sharing my invigilated Skill Passport scores with verified recruiters and hiring partners.</span>
              </label>
            </div>
          </div>

          <!-- Navigation Buttons -->
          <div class="stepper-actions">
            <button 
              *ngIf="currentStep > 1" 
              (click)="prevStep()" 
              class="btn btn-secondary">
              ← Back
            </button>

            <button 
              *ngIf="currentStep < 5" 
              (click)="nextStep()" 
              class="btn btn-primary margin-left-auto">
              Continue to Step {{ currentStep + 1 }} →
            </button>

            <button 
              *ngIf="currentStep === 5" 
              (click)="submitRegistration()" 
              [disabled]="!consentInvigilation || !consentData" 
              class="btn btn-primary btn-lg margin-left-auto">
              Create Candidate Account & Book Slot →
            </button>
          </div>
        </div>
      </div>
    </main>

    <!-- Confirmation Success Modal -->
    <app-success-modal
      [isOpen]="showSuccessModal"
      title="Candidate Registration Complete!"
      message="Your account has been created. Proceed to select your test date and exam centre."
      actionLabel="Book Test Slot Now →"
      [details]="modalDetails"
      (confirmed)="onModalConfirmed()">
    </app-success-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .register-page {
      padding: 4rem 0 6rem 0;
      background: radial-gradient(circle at 50% 15%, rgba(15, 122, 92, 0.06) 0%, transparent 60%);
    }
    .register-card {
      padding: 2.5rem;
    }
    .step-title-box {
      margin-bottom: 2rem;
      text-align: center;
    }
    .step-title-box h2 {
      font-size: 1.6rem;
      color: var(--heading);
    }
    .step-sub {
      color: var(--text-muted);
      font-size: 0.95rem;
    }
    .step-form-content {
      margin-bottom: 2rem;
    }
    .form-grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .status-radio-group {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.75rem;
    }
    .radio-card {
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 0.75rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.875rem;
      font-weight: 600;
      background: var(--bg-subtle);
    }
    .radio-card.selected {
      border-color: var(--primary);
      background: var(--primary-subtle);
      color: var(--primary);
    }
    .radio-card input {
      display: none;
    }
    .track-info-note {
      font-size: 0.9rem;
      color: var(--text-muted);
      margin-bottom: 1.25rem;
    }
    .track-cards-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .track-card {
      border: 2px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.25rem;
      cursor: pointer;
      background: var(--bg-main);
      transition: all var(--transition-fast);
    }
    .track-card:hover {
      border-color: rgba(15, 122, 92, 0.4);
    }
    .track-card.selected {
      border-color: var(--primary);
      background: var(--primary-subtle);
    }
    .track-card-header {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 0.5rem;
    }
    .track-icon {
      font-size: 1.6rem;
    }
    .track-title {
      font-size: 1.1rem;
      color: var(--heading);
      margin: 0;
    }
    .recommended-badge {
      background: var(--accent-gold-light);
      color: #92400E;
      font-size: 0.65rem;
      font-weight: 800;
      padding: 0.15rem 0.5rem;
      border-radius: var(--radius-full);
      display: inline-block;
      margin-bottom: 0.2rem;
    }
    .track-desc {
      font-size: 0.875rem;
      color: var(--text-muted);
      margin-bottom: 0.75rem;
    }
    .track-footer {
      display: flex;
      gap: 1.5rem;
      font-size: 0.775rem;
      font-weight: 600;
      color: var(--heading);
    }
    .id-explanation-box {
      background: var(--primary-subtle);
      border: 1px solid rgba(15, 122, 92, 0.3);
      border-radius: var(--radius-md);
      padding: 1.25rem;
      display: flex;
      gap: 1rem;
      align-items: flex-start;
      margin-bottom: 1.5rem;
    }
    .id-explanation-box .shield-icon {
      font-size: 1.8rem;
    }
    .id-explanation-box h4 {
      font-size: 0.95rem;
      color: var(--heading);
      margin-bottom: 0.25rem;
    }
    .id-explanation-box p {
      font-size: 0.85rem;
      color: var(--text-main);
    }
    .upload-grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.25rem;
    }
    .upload-dropzone {
      border: 2px dashed var(--border-color);
      border-radius: var(--radius-md);
      padding: 2rem 1.5rem;
      text-align: center;
      position: relative;
      background: var(--bg-subtle);
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
    }
    .upload-icon {
      font-size: 2.2rem;
      margin-bottom: 0.5rem;
    }
    .upload-label {
      font-size: 0.9rem;
      font-weight: 700;
      color: var(--heading);
    }
    .upload-sub {
      font-size: 0.775rem;
      color: var(--text-muted);
    }
    .file-input {
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      opacity: 0;
      cursor: pointer;
    }
    .upload-preview {
      margin-top: 1rem;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .upload-preview img {
      width: 70px;
      height: 70px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid var(--primary);
    }
    .preview-tag {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--primary);
      margin-top: 0.35rem;
    }
    .review-summary-card {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .review-title {
      font-size: 1.05rem;
      margin-bottom: 1rem;
    }
    .review-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.85rem;
    }
    .review-item {
      display: flex;
      flex-direction: column;
      font-size: 0.875rem;
    }
    .review-item.full-width {
      grid-column: span 2;
    }
    .review-item .lbl {
      color: var(--text-muted);
      font-size: 0.775rem;
    }
    .review-item .val {
      font-weight: 600;
      color: var(--heading);
    }
    .highlight-track {
      color: var(--primary-dark);
      font-weight: 700;
    }
    .text-green {
      color: var(--primary);
      font-weight: 700;
    }
    .consent-group {
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
      font-size: 0.875rem;
    }
    .checkbox-row {
      display: flex;
      gap: 0.65rem;
      align-items: flex-start;
      cursor: pointer;
      color: var(--text-main);
    }
    .checkbox-row input {
      margin-top: 3px;
    }
    .stepper-actions {
      display: flex;
      align-items: center;
      border-top: 1px solid var(--border-color);
      padding-top: 1.5rem;
    }
    .margin-left-auto {
      margin-left: auto;
    }

    @media (max-width: 650px) {
      .form-grid-2, .upload-grid-2, .status-radio-group, .review-grid {
        grid-template-columns: 1fr;
      }
      .review-item.full-width {
        grid-column: span 1;
      }
    }
  `]
})
export class CandidateRegisterComponent {
  candidateService = inject(CandidateService);
  authService = inject(AuthService);
  router = inject(Router);

  currentStep = 1;
  showSuccessModal = false;
  photoPreview: string | null = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200';
  idPreview = true;
  consentInvigilation = true;
  consentData = true;

  formData = {
    fullName: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    phone: '+91 98765 43210',
    city: 'Bengaluru',
    college: 'RV College of Engineering',
    degree: 'B.Tech',
    stream: 'Computer Science & Engineering',
    graduationYear: 2026,
    status: 'fresher' as 'student' | 'fresher' | 'experienced',
    selectedTrack: 'universal_fresher'
  };

  availableTracks = [
    {
      id: 'universal_fresher',
      icon: '✨',
      recommended: true,
      title: 'Universal Fresher Competency Assessment',
      desc: 'One comprehensive test mapping multi-dimensional backend, QA, and logic fit across recruiters.',
      duration: '3.0 Hours (Center)',
      format: 'Logic + QA + Practical Choice'
    },
    {
      id: 'java_backend',
      icon: '☕',
      recommended: false,
      title: 'Java Backend (Spring Boot)',
      desc: 'Hands-on live Spring Boot API build, JPA transactions, and JUnit scenario test suite.',
      duration: '3.5 Hours (Center)',
      format: 'Applied Coding + Debugging'
    },
    {
      id: 'qa_testing',
      icon: '🧪',
      recommended: false,
      title: 'QA & Automation Testing',
      desc: 'Scenario bug hunting, test case writing, Selenium/JUnit automation and edge-case validation.',
      duration: '2.5 Hours (Center)',
      format: 'Scenario & Automation'
    },
    {
      id: 'python_backend',
      icon: '🐍',
      recommended: false,
      title: 'Python Backend & Data Engineering',
      desc: 'FastAPI/Django microservices development, SQL optimization, and algorithm verification.',
      duration: '3.0 Hours (Center)',
      format: 'Practical Build'
    }
  ];

  modalDetails: Array<{ label: string; value: string }> = [];

  getStepTitle(): string {
    switch (this.currentStep) {
      case 1: return 'Step 1: Personal & Basic Info';
      case 2: return 'Step 2: Educational Qualifications';
      case 3: return 'Step 3: Choose Verification Track';
      case 4: return 'Step 4: ID & Photo Verification';
      case 5: return 'Step 5: Review & Submit Registration';
      default: return '';
    }
  }

  getStepSub(): string {
    switch (this.currentStep) {
      case 1: return 'Enter your official name and contact details.';
      case 2: return 'Specify your college, degree, and current employment status.';
      case 3: return 'Select the skill domain or opt for Universal Fresher verification.';
      case 4: return 'Upload candidate photo and ID for test centre gate entry.';
      case 5: return 'Verify all details before booking your physical exam slot.';
      default: return '';
    }
  }

  getSelectedTrackTitle(): string {
    const found = this.availableTracks.find(t => t.id === this.formData.selectedTrack);
    return found ? found.title : 'Universal Fresher Competency';
  }

  onPhotoSelected(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => this.photoPreview = reader.result as string;
      reader.readAsDataURL(file);
    }
  }

  onIdSelected(event: Event) {
    this.idPreview = true;
  }

  nextStep() {
    if (this.currentStep < 5) this.currentStep++;
  }

  prevStep() {
    if (this.currentStep > 1) this.currentStep--;
  }

  submitRegistration() {
    this.modalDetails = [
      { label: 'Candidate Name', value: this.formData.fullName },
      { label: 'Track Selected', value: this.getSelectedTrackTitle() },
      { label: 'Preferred City', value: this.formData.city }
    ];
    this.authService.login(this.formData.email, 'candidate');
    this.showSuccessModal = true;
  }

  onModalConfirmed() {
    this.showSuccessModal = false;
    this.router.navigate(['/dashboard/candidate']);
  }
}
