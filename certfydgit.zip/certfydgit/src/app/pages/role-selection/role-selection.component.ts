import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-role-selection',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="role-page-container">
      <div class="container container-narrow text-center">
        <span class="badge badge-teal">Choose Your Path</span>
        <h1 class="page-headline">Welcome to Proveyu</h1>
        <p class="page-subline">Select how you would like to proceed on the platform.</p>

        <div class="cards-grid">
          <!-- Candidate Card -->
          <div class="role-card candidate-card" (click)="selectRole('candidate')">
            <div class="card-icon">🎓</div>
            <div class="card-role-tag">For Job Seekers & Freshers</div>
            <h2>I'm a Candidate</h2>
            <p>
              Get your skills invigilated and verified at a partner exam centre. Earn a multi-dimensional Skill Passport and get hired on merit.
            </p>
            <ul class="role-highlights">
              <li>✓ Supervised in-person test at partner centre</li>
              <li>✓ Multi-role fit recommendation (QA, Java, Python, Web)</li>
              <li>✓ Skip online screening tests & get direct interviews</li>
            </ul>
            <button class="btn btn-primary btn-lg full-width margin-top">
              Continue as Candidate →
            </button>
          </div>

          <!-- Recruiter Card -->
          <div class="role-card recruiter-card" (click)="selectRole('recruiter')">
            <div class="card-icon">💼</div>
            <div class="card-role-tag">For Recruiters, Agencies & Startups</div>
            <h2>I'm Hiring Talent</h2>
            <p>
              Access pre-verified candidate passports with zero remote proctoring cheating or resume inflation. Hire 2x faster.
            </p>
            <ul class="role-highlights">
              <li>✓ Startups, Placement Agencies & Enterprise Companies</li>
              <li>✓ Filter by verified domain score & tier badges</li>
              <li>✓ Pipeline kanban & Agency client allocation view</li>
            </ul>
            <button class="btn btn-secondary btn-lg full-width margin-top">
              Continue as Recruiter / Agency →
            </button>
          </div>
        </div>
      </div>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .role-page-container {
      padding: 4rem 0 6rem 0;
      background: radial-gradient(circle at 50% 10%, rgba(15, 122, 92, 0.05) 0%, transparent 60%);
      min-height: calc(100vh - 72px - 300px);
    }
    .page-headline {
      font-size: 2.5rem;
      margin: 0.5rem 0 0.5rem 0;
      color: var(--heading);
    }
    .page-subline {
      color: var(--text-muted);
      font-size: 1.1rem;
      margin-bottom: 3rem;
    }
    .cards-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
      text-align: left;
    }
    .role-card {
      background: var(--bg-card);
      border: 2px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 2.25rem;
      box-shadow: var(--shadow-md);
      cursor: pointer;
      transition: all var(--transition-normal);
      display: flex;
      flex-direction: column;
    }
    .role-card:hover {
      border-color: var(--primary);
      transform: translateY(-4px);
      box-shadow: var(--shadow-lg);
    }
    .candidate-card:hover {
      background: var(--bg-subtle);
    }
    .recruiter-card:hover {
      background: var(--bg-subtle);
    }
    .card-icon {
      font-size: 2.5rem;
      margin-bottom: 1rem;
    }
    .card-role-tag {
      font-size: 0.775rem;
      font-weight: 700;
      color: var(--primary);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 0.5rem;
    }
    .role-card h2 {
      font-size: 1.6rem;
      color: var(--heading);
      margin-bottom: 0.75rem;
    }
    .role-card p {
      color: var(--text-muted);
      font-size: 0.95rem;
      line-height: 1.5;
      margin-bottom: 1.5rem;
    }
    .role-highlights {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.65rem;
      font-size: 0.875rem;
      color: var(--heading);
      font-weight: 500;
      margin-bottom: 1.5rem;
    }
    .full-width {
      width: 100%;
    }
    .margin-top {
      margin-top: auto;
    }

    @media (max-width: 768px) {
      .cards-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class RoleSelectionComponent {
  router = inject(Router);

  selectRole(role: 'candidate' | 'recruiter') {
    if (role === 'candidate') {
      this.router.navigate(['/register/candidate']);
    } else {
      this.router.navigate(['/register/recruiter']);
    }
  }
}
