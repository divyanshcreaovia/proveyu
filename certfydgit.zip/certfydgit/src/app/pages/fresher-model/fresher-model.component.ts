import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-fresher-model',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-gold">Game Changer for Campus & Fresher Hiring</span>
          <h1 class="page-title">The Universal Fresher Competency Model</h1>
          <p class="page-subtitle">
            Freshers don't come pre-specialized. Proveyu's single test evaluates core logic, problem-solving, and practical build choices to recommend exact role fit.
          </p>
        </div>
      </section>

      <!-- Main Explanation Section -->
      <section class="section-padding">
        <div class="container">
          
          <div class="fresher-grid">
            <div class="fresher-text-col">
              <span class="badge badge-teal">Multi-Role Aptitude</span>
              <h2>One Exam — Infinite Placement Opportunities</h2>
              <p class="lead-text">
                Traditional fresher hiring forces 2025/2026 graduates to apply for specific narrow roles before they even understand corporate technology stacks. Proveyu replaces narrow tests with a comprehensive competency evaluation.
              </p>

              <div class="pillar-cards-list">
                <div class="pillar-card deservify-card">
                  <span class="p-icon">🧠</span>
                  <div>
                    <h3>1. Core Algorithmic Logic & Control Flow</h3>
                    <p>Evaluates foundational problem-solving, data structure choices, and time/space complexity understanding.</p>
                  </div>
                </div>

                <div class="pillar-card deservify-card">
                  <span class="p-icon">🧪</span>
                  <div>
                    <h3>2. QA & Test Automation Aptitude</h3>
                    <p>Tests scenario thinking, edge-case coverage, REST assertion writing, and bug isolation skills.</p>
                  </div>
                </div>

                <div class="pillar-card deservify-card">
                  <span class="p-icon">⚙️</span>
                  <div>
                    <h3>3. Backend Microservices Comprehension</h3>
                    <p>Evaluates Java/Spring Boot or Python REST endpoint implementation, database queries, and code readability.</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Interactive Competency Mockup -->
            <div class="fresher-graphic-col">
              <div class="competency-card-full glass-card">
                <div class="comp-head">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150" class="c-avatar" alt="Candidate">
                  <div>
                    <h3 style="margin: 0;">Rahul Sharma (Fresher 2026)</h3>
                    <span style="font-size: 0.8rem; color: var(--primary); font-weight: 600;">Universal Fresher Passport #CF-9842</span>
                  </div>
                </div>

                <div class="radar-bars">
                  <div class="r-item">
                    <div class="r-head">
                      <span>Core Logic & Algorithms</span>
                      <span class="r-pts">95% (Strong)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 95%;"></div></div>
                  </div>

                  <div class="r-item">
                    <div class="r-head">
                      <span>QA & Automation Testing</span>
                      <span class="r-pts">94% (Strong)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 94%;"></div></div>
                  </div>

                  <div class="r-item">
                    <div class="r-head">
                      <span>Java Backend Microservices</span>
                      <span class="r-pts">88% (Proficient)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 88%;"></div></div>
                  </div>
                </div>

                <div class="rec-box">
                  <div class="rec-title">🎯 Ranked Placement Recommendation</div>
                  <div class="rec-roles">
                    <span>1st Choice: <strong>Associate QA Automation Engineer</strong></span>
                    <span>2nd Choice: <strong>Java Backend Microservices Developer</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Bottom Action Box -->
          <div class="cta-box text-center margin-top-xl">
            <h2>Get Verified on the Universal Fresher Model Today</h2>
            <div class="cta-btns">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">🎓 Register as Fresher Candidate</a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">💼 Access Fresher Talent Pool</a>
            </div>
          </div>

        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #0F7A5C 0%, #149B76 100%);
      color: #FFFFFF;
      padding: 4rem 0;
    }
    .page-title { font-size: 2.75rem; color: #FFFFFF; margin: 0.75rem 0; }
    .page-subtitle { font-size: 1.15rem; opacity: 0.95; max-width: 680px; margin: 0 auto; }
    .section-padding { padding: 4rem 0 6rem 0; background: var(--bg-subtle); }
    
    .fresher-grid {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 3rem;
      align-items: center;
    }
    .fresher-text-col h2 { font-size: 2.1rem; margin: 0.5rem 0 1rem 0; }
    .lead-text { font-size: 1.05rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 2rem; }
    .pillar-cards-list { display: flex; flex-direction: column; gap: 1rem; }
    .pillar-card { display: flex; gap: 1.25rem; align-items: flex-start; padding: 1.25rem; }
    .p-icon { font-size: 1.8rem; }
    .pillar-card h3 { font-size: 1.05rem; margin-bottom: 0.25rem; }
    .pillar-card p { font-size: 0.85rem; color: var(--text-muted); margin: 0; }

    .competency-card-full {
      padding: 2rem;
      border: 2px solid var(--primary);
    }
    .comp-head { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .c-avatar { width: 56px; height: 56px; border-radius: 50%; border: 2px solid var(--primary); }
    .radar-bars { display: flex; flex-direction: column; gap: 1.25rem; margin-bottom: 1.5rem; }
    .r-head { display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 700; margin-bottom: 0.35rem; }
    .r-bar { height: 8px; background: var(--border-color); border-radius: 9999px; overflow: hidden; }
    .r-fill { height: 100%; background: var(--primary); }
    .rec-box { background: var(--primary-subtle); border: 1px solid rgba(15, 122, 92, 0.3); border-radius: var(--radius-md); padding: 1rem; }
    .rec-title { font-size: 0.8rem; font-weight: 800; color: var(--primary); margin-bottom: 0.5rem; }
    .rec-roles { display: flex; flex-direction: column; gap: 0.25rem; font-size: 0.85rem; color: var(--heading); }

    .margin-top-xl { margin-top: 4rem; }
    .cta-box { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: 3rem; box-shadow: var(--shadow-md); }
    .cta-box h2 { margin-bottom: 1.5rem; color: var(--heading); }
    .cta-btns { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }

    @media (max-width: 900px) {
      .fresher-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class FresherModelComponent { }
