import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { AdmitCardModalComponent } from '../../shared/components/admit-card-modal/admit-card-modal.component';
import { PassportModalComponent } from '../../shared/components/passport-modal/passport-modal.component';
import { SuccessModalComponent } from '../../shared/components/success-modal/success-modal.component';
import { CandidateService } from '../../core/services/candidate.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    NavbarComponent,
    FooterComponent,
    AdmitCardModalComponent,
    PassportModalComponent,
    SuccessModalComponent
  ],
  template: `
    <app-navbar></app-navbar>

    <main class="dashboard-page">
      <div class="container">
        <!-- Dashboard Top Header -->
        <div class="dash-header">
          <div class="user-info-row">
            <img [src]="profile().photoUrl" alt="Avatar" class="avatar-large">
            <div>
              <div class="badge-row">
                <span class="badge badge-teal">Candidate Portal</span>
                <span class="badge badge-gold" *ngIf="profile().passport">{{ profile().passport?.tierBadge }}</span>
              </div>
              <h1 class="user-name">Welcome, {{ profile().fullName }}</h1>
              <p class="user-sub">
                {{ profile().college }} ({{ profile().degree }} {{ profile().graduationYear }}) | Track: <strong>{{ profile().selectedTrack }}</strong>
              </p>
            </div>
          </div>

          <div class="header-action-box">
            <button *ngIf="profile().passport" (click)="isPassportModalOpen = true" class="btn btn-primary btn-lg">
              <i class="fa-solid fa-id-card me-2"></i> View Skill Passport
            </button>
          </div>
        </div>

        <!-- Verification Lifecycle Status Stepper -->
        <div class="status-stepper-card deservify-card">
          <h3 class="card-title">Verification Lifecycle Status</h3>
          <div class="stepper-horizontal">
            <div class="step-item completed">
              <div class="circle">✓</div>
              <span class="label">1. Registration Done</span>
            </div>
            <div class="step-item" [class.completed]="profile().slotBooking">
              <div class="circle">{{ profile().slotBooking ? '✓' : '2' }}</div>
              <span class="label">2. Slot Booked</span>
            </div>
            <div class="step-item" [class.completed]="profile().testStatus === 'passport_ready' || profile().testStatus === 'test_completed'">
              <div class="circle">{{ profile().testStatus === 'passport_ready' ? '✓' : '3' }}</div>
              <span class="label">3. Centre Test Taken</span>
            </div>
            <div class="step-item" [class.completed]="profile().passport">
              <div class="circle">{{ profile().passport ? '✓' : '4' }}</div>
              <span class="label">4. Passport Issued</span>
            </div>
          </div>
        </div>

        <div class="dashboard-grid">
          <!-- Left Main Column -->
          <div class="dash-main-col">
            
            <!-- Skill Passport Section -->
            <div id="passport" class="deservify-card passport-summary-card" *ngIf="profile().passport; else noPassport">
              <div class="card-header-flex">
                <div>
                  <span class="badge badge-teal">Invigilated Record</span>
                  <h2>Official Skill Passport</h2>
                </div>
                <button (click)="isPassportModalOpen = true" class="btn btn-outline-primary btn-sm">
                  Full Details & PDF →
                </button>
              </div>

              <div class="passport-hero-box">
                <div class="score-circle-lg">
                  <span class="score-val">{{ profile().passport?.overallScore }}</span>
                  <span class="score-lbl">PASSPORT SCORE</span>
                </div>

                <div class="passport-meta-text">
                  <span class="badge badge-gold">{{ profile().passport?.tierBadge }}</span>
                  <h3 class="passport-id-title">Passport ID: {{ profile().passport?.passportId }}</h3>
                  <p class="centre-meta">📍 {{ profile().passport?.verificationCenter }}</p>

                  <div class="role-recs-mini">
                    <span>🎯 <strong>Primary Recommendation:</strong> {{ profile().passport?.primaryRoleRecommendation }}</span>
                    <span>⚡ <strong>Secondary Fit:</strong> {{ profile().passport?.secondaryRoleRecommendation }}</span>
                  </div>
                </div>
              </div>

              <!-- Competencies Breakdown Bars -->
              <div class="competency-bars-grid">
                <div class="comp-bar-item" *ngFor="let comp of profile().passport?.competencies">
                  <div class="comp-bar-head">
                    <span class="name">{{ comp.name }}</span>
                    <span class="pts">{{ comp.score }}% ({{ comp.status }})</span>
                  </div>
                  <div class="comp-bar-track">
                    <div class="comp-bar-fill" [style.width.%]="comp.score"></div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Fallback if no passport -->
            <ng-template #noPassport>
              <div id="passport" class="deservify-card empty-card">
                <h3>Passport Awaiting Assessment Completion</h3>
                <p>Complete your supervised test at the partner exam centre to unlock your Skill Passport.</p>
              </div>
            </ng-template>

            <!-- Opportunities & Recruiter Interest -->
            <div id="requests" class="deservify-card margin-top-card">
              <div class="card-header-flex">
                <div>
                  <span class="badge badge-gold">Direct Hiring Path</span>
                  <h2>Recruiter Interview Requests ({{ candidateService.recruiterInterviews().length }})</h2>
                </div>
              </div>
              <p class="section-hint">Recruiters who have viewed your invigilated Skill Passport and requested direct interviews.</p>

              <div class="interviews-list">
                <div class="interview-card" *ngFor="let item of candidateService.recruiterInterviews()">
                  <div class="int-header">
                    <div>
                      <h4 class="company">{{ item.companyName }}</h4>
                      <span class="role">{{ item.role }}</span>
                    </div>
                    <span class="package-badge">{{ item.package }}</span>
                  </div>

                  <div class="int-meta">
                    <span>🗓️ Proposed Time: <strong>{{ item.date }}</strong></span>
                    <span class="status-tag" [ngClass]="{
                      'text-green': item.status === 'accepted',
                      'text-muted': item.status === 'pending',
                      'text-red': item.status === 'declined'
                    }">Status: {{ item.status | uppercase }}</span>
                  </div>

                  <div class="int-actions" *ngIf="item.status === 'pending'">
                    <button (click)="respondInterview(item.id, 'accepted')" class="btn btn-sm btn-primary">
                      ✓ Accept Interview Request
                    </button>
                    <button (click)="respondInterview(item.id, 'declined')" class="btn btn-sm btn-secondary">
                      Decline
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Right Sidebar Column -->
          <div class="dash-side-col">
            
            <!-- Book Test Slot Card -->
            <div id="slots" class="deservify-card slot-card">
              <div class="side-card-title">
                <span class="icon">📅</span>
                <div>
                  <h3>Exam Centre Slot</h3>
                  <span class="sub">TCS iON / JEE Partner Network</span>
                </div>
              </div>

              <!-- If slot already booked -->
              <div *ngIf="profile().slotBooking; else bookSlotForm" class="booked-slot-info">
                <div class="booked-badge">✓ SLOT CONFIRMED</div>
                <h4 class="center-name">{{ profile().slotBooking?.centerName }}</h4>
                <p class="center-addr">{{ profile().slotBooking?.centerAddress }}</p>
                <div class="slot-time-box">
                  <div><strong>Date:</strong> {{ profile().slotBooking?.date }}</div>
                  <div><strong>Time:</strong> {{ profile().slotBooking?.timeSlot }}</div>
                  <div><strong>Reporting:</strong> {{ profile().slotBooking?.reportingTime }}</div>
                </div>

                <button (click)="isAdmitModalOpen = true" class="btn btn-primary full-width margin-top">
                  🖨️ View Admit Card & QR
                </button>
              </div>

              <!-- Slot booking form -->
              <ng-template #bookSlotForm>
                <form (ngSubmit)="onBookSlotSubmit()" class="slot-form">
                  <div class="form-group">
                    <label class="form-label">Select Exam Centre</label>
                    <select class="form-control" [(ngModel)]="slotForm.centerName" name="center">
                      <option value="TCS iON Digital Zone iDZ Koramangala, Bengaluru">TCS iON Koramangala (Bengaluru)</option>
                      <option value="TCS iON Digital Zone Noida Sector 62">TCS iON Sector 62 (Noida / Delhi NCR)</option>
                      <option value="TCS iON iDZ Powai, Mumbai">TCS iON Powai (Mumbai)</option>
                      <option value="TCS iON HITECH City, Hyderabad">TCS iON HITECH City (Hyderabad)</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label class="form-label">Test Date</label>
                    <input type="date" class="form-control" [(ngModel)]="slotForm.date" name="date">
                  </div>

                  <div class="form-group">
                    <label class="form-label">Time Slot</label>
                    <select class="form-control" [(ngModel)]="slotForm.timeSlot" name="slot">
                      <option value="09:30 AM - 12:30 PM">Morning: 09:30 AM - 12:30 PM</option>
                      <option value="01:30 PM - 04:30 PM">Afternoon: 01:30 PM - 04:30 PM</option>
                    </select>
                  </div>

                  <button type="submit" class="btn btn-primary full-width">
                    Confirm & Book Slot →
                  </button>
                </form>
              </ng-template>
            </div>

            <!-- Admit Card Download Quick Widget -->
            <div class="deservify-card admit-widget-card" *ngIf="profile().slotBooking">
              <div class="widget-head">
                <span class="icon">🪪</span>
                <h4>Hall Ticket & Admit Card</h4>
              </div>
              <p class="widget-desc">Roll No: <strong>{{ profile().slotBooking?.rollNumber }}</strong></p>
              <button (click)="isAdmitModalOpen = true" class="btn btn-secondary btn-sm full-width">
                Open Admit Card Modal
              </button>
            </div>

            <!-- Guidelines Info Widget -->
            <div class="deservify-card guidelines-widget">
              <h4>🛡️ Exam Gate Protocols</h4>
              <ul>
                <li>Original Govt Photo ID mandatory</li>
                <li>No phones / smartwatches inside lab</li>
                <li>Biometric fingerprint gate logging</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Admit Card Modal -->
    <app-admit-card-modal
      [isOpen]="isAdmitModalOpen"
      [admitCard]="admitCardData"
      (close)="isAdmitModalOpen = false">
    </app-admit-card-modal>

    <!-- Passport Modal -->
    <app-passport-modal
      [isOpen]="isPassportModalOpen"
      [passport]="profile().passport || null"
      (close)="isPassportModalOpen = false">
    </app-passport-modal>

    <!-- Confirmation Modal -->
    <app-success-modal
      [isOpen]="isSuccessModalOpen"
      title="Slot Booked Successfully!"
      message="Your exam slot has been reserved at the partner centre. Admit card is now ready."
      actionLabel="View Admit Card →"
      (confirmed)="onSuccessConfirmed()"
      (closed)="isSuccessModalOpen = false">
    </app-success-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .dashboard-page {
      padding: 3rem 0 5rem 0;
      background: var(--bg-subtle);
      min-height: calc(100vh - 72px - 300px);
    }
    .dash-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      flex-wrap: wrap;
      gap: 1rem;
    }
    .user-info-row {
      display: flex;
      align-items: center;
      gap: 1.25rem;
    }
    .avatar-large {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid var(--primary);
    }
    .badge-row {
      display: flex;
      gap: 0.5rem;
      margin-bottom: 0.35rem;
    }
    .user-name {
      font-size: 1.8rem;
      margin: 0;
      color: var(--heading);
    }
    .user-sub {
      color: var(--text-muted);
      font-size: 0.9rem;
    }

    /* Stepper */
    .status-stepper-card {
      margin-bottom: 2rem;
    }
    .card-title {
      font-size: 1.05rem;
      margin-bottom: 1.25rem;
    }
    .stepper-horizontal {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      position: relative;
    }
    .stepper-horizontal::before {
      content: '';
      position: absolute;
      top: 18px;
      left: 40px;
      right: 40px;
      height: 2px;
      background: var(--border-color);
      z-index: 0;
    }
    .step-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      z-index: 1;
      background: transparent;
    }
    .circle {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: var(--bg-subtle);
      border: 2px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 0.85rem;
      margin-bottom: 0.4rem;
      color: var(--text-muted);
    }
    .step-item.completed .circle {
      background: var(--primary);
      border-color: var(--primary);
      color: #FFFFFF;
    }
    .step-item .label {
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-muted);
    }
    .step-item.completed .label {
      color: var(--heading);
    }

    /* Dashboard Layout Grid */
    .dashboard-grid {
      display: grid;
      grid-template-columns: 2.1fr 1fr;
      gap: 2rem;
    }
    .card-header-flex {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1.5rem;
    }
    .card-header-flex h2 {
      font-size: 1.4rem;
      margin-top: 0.35rem;
    }
    .passport-summary-card {
      background: var(--bg-card);
      border: 1px solid rgba(15, 122, 92, 0.3);
      box-shadow: var(--shadow-md);
      color: var(--text-main);
    }
    .passport-hero-box {
      display: flex;
      align-items: center;
      gap: 1.5rem;
      background: var(--primary-subtle);
      border-radius: var(--radius-lg);
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      border: 1px solid rgba(15, 122, 92, 0.2);
    }
    .score-circle-lg {
      width: 96px;
      height: 96px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0F7A5C 0%, #064E3B 100%);
      color: #FFFFFF;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      flex-shrink: 0;
      padding: 0.25rem;
      box-shadow: 0 8px 24px rgba(15, 122, 92, 0.35);
      border: 3px solid var(--primary-light);
    }
    .score-circle-lg .score-val {
      font-family: 'Outfit', sans-serif;
      font-size: 1.8rem;
      font-weight: 800;
      line-height: 1;
      display: block;
    }
    .score-circle-lg .score-lbl {
      font-size: 0.55rem;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-align: center;
      line-height: 1.1;
      display: block;
      margin-top: 2px;
    }
    .passport-id-title {
      font-size: 1.05rem;
      margin: 0.25rem 0;
      color: var(--heading);
    }
    .centre-meta {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin-bottom: 0.5rem;
    }
    .role-recs-mini {
      display: flex;
      flex-direction: column;
      gap: 0.2rem;
      font-size: 0.825rem;
      color: var(--heading);
    }
    .competency-bars-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    .comp-bar-item {
      background: var(--bg-subtle);
      padding: 0.85rem;
      border-radius: var(--radius-md);
      border: 1px solid var(--border-color);
      color: var(--text-main);
    }
    .comp-bar-head {
      display: flex;
      justify-content: space-between;
      font-size: 0.8rem;
      font-weight: 700;
      margin-bottom: 0.35rem;
      color: var(--heading);
    }
    .comp-bar-track {
      height: 6px;
      background: var(--border-color);
      border-radius: 9999px;
      overflow: hidden;
    }
    .comp-bar-fill {
      height: 100%;
      background: var(--primary);
    }

    .margin-top-card {
      margin-top: 2rem;
    }
    .section-hint {
      font-size: 0.875rem;
      color: var(--text-muted);
      margin-bottom: 1.25rem;
    }
    .interviews-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .interview-card {
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1.25rem;
      background: var(--bg-card);
      color: var(--text-main);
    }
    .int-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.75rem;
    }
    .int-header .company {
      font-size: 1.05rem;
      margin: 0;
      color: var(--heading);
    }
    .int-header .role {
      font-size: 0.85rem;
      color: var(--primary);
      font-weight: 600;
    }
    .package-badge {
      background: var(--accent-gold-light);
      color: #92400E;
      font-size: 0.775rem;
      font-weight: 800;
      padding: 0.25rem 0.65rem;
      border-radius: var(--radius-full);
    }
    .int-meta {
      display: flex;
      justify-content: space-between;
      font-size: 0.85rem;
      color: var(--text-muted);
      margin-bottom: 1rem;
    }
    .int-actions {
      display: flex;
      gap: 0.75rem;
    }

    /* Right Side Cards */
    .side-card-title {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 1.25rem;
    }
    .side-card-title .icon { font-size: 1.6rem; }
    .side-card-title h3 { font-size: 1.1rem; margin: 0; color: var(--heading); }
    .side-card-title .sub { font-size: 0.75rem; color: var(--text-muted); }

    .booked-slot-info {
      background: var(--primary-subtle);
      border: 1px solid rgba(15, 122, 92, 0.3);
      padding: 1.25rem;
      border-radius: var(--radius-md);
      color: var(--text-main);
    }
    .booked-badge {
      font-size: 0.7rem;
      font-weight: 800;
      color: var(--primary);
      letter-spacing: 0.5px;
      margin-bottom: 0.5rem;
    }
    .center-name {
      font-size: 0.95rem;
      color: var(--heading);
      margin-bottom: 0.25rem;
    }
    .center-addr {
      font-size: 0.775rem;
      color: var(--text-muted);
      margin-bottom: 1rem;
    }
    .slot-time-box {
      font-size: 0.825rem;
      color: var(--text-main);
      display: flex;
      flex-direction: column;
      gap: 0.2rem;
    }
    .full-width { width: 100%; }
    .margin-top { margin-top: 1rem; }

    .admit-widget-card {
      margin-top: 1.5rem;
    }
    .widget-head {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-bottom: 0.35rem;
    }
    .widget-head h4 { font-size: 0.95rem; margin: 0; color: var(--heading); }
    .widget-desc { font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.75rem; }

    .guidelines-widget {
      margin-top: 1.5rem;
      background: var(--bg-subtle);
      color: var(--text-main);
    }
    .guidelines-widget h4 { font-size: 0.9rem; margin-bottom: 0.5rem; color: var(--heading); }
    .guidelines-widget ul { padding-left: 1.2rem; font-size: 0.8rem; color: var(--text-muted); }
    .guidelines-widget li { margin-bottom: 0.25rem; }

    @media (max-width: 900px) {
      .dashboard-grid { grid-template-columns: 1fr; }
      .competency-bars-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class CandidateDashboardComponent {
  candidateService = inject(CandidateService);
  authService = inject(AuthService);

  profile = this.candidateService.currentProfile;

  isAdmitModalOpen = false;
  isPassportModalOpen = false;
  isSuccessModalOpen = false;

  slotForm = {
    centerName: 'TCS iON Digital Zone iDZ Koramangala, Bengaluru',
    date: '2026-09-22',
    timeSlot: '09:30 AM - 12:30 PM'
  };

  get admitCardData() {
    return this.profile().slotBooking ? this.candidateService.getAdmitCard() : null;
  }

  onBookSlotSubmit() {
    this.candidateService.bookSlot(
      this.slotForm.centerName,
      this.slotForm.date,
      this.slotForm.timeSlot
    );
    this.isSuccessModalOpen = true;
  }

  onSuccessConfirmed() {
    this.isSuccessModalOpen = false;
    this.isAdmitModalOpen = true;
  }

  respondInterview(id: string, response: 'accepted' | 'declined') {
    this.candidateService.respondToInterview(id, response);
  }
}
