import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-why-in-person',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-gold">The Anti-Cheat Standard</span>
          <h1 class="page-title">Why Physical In-Person Verification Wins</h1>
          <p class="page-subtitle">
            Online proctoring has failed. Discover why high-stakes physical examination infrastructure is the only cheat-proof hiring signal.
          </p>
        </div>
      </section>

      <!-- Main Comparison Content -->
      <section class="section-padding">
        <div class="container">
          
          <div class="comparison-detailed-grid">
            
            <!-- Traditional Remote Online Proctoring -->
            <div class="card-col old-col deservify-card">
              <div class="tag red-tag">❌ Online Remote Proctoring</div>
              <h2>Broken & Vulnerable to AI Relays</h2>
              <p class="desc">Webcam-based proctoring software only monitors a single camera angle. It is fundamentally incapable of preventing modern proxy cheating methods.</p>

              <div class="vulnerability-list">
                <div class="v-item">
                  <h4>1. Second Screen & HDMI Hardware Relays</h4>
                  <p>External splitters feed test questions to a second laptop where an expert or LLM solves the test in real time.</p>
                </div>
                <div class="v-item">
                  <h4>2. Hidden Proxy Test-Takers</h4>
                  <p>In-person proxies sit just off-camera operating remote keyboards or ear-pieces to dictate correct answers.</p>
                </div>
                <div class="v-item">
                  <h4>3. Resume Inflation & Fake Certificates</h4>
                  <p>Up to 60% of applicants exaggerate or completely fabricate project experience, causing massive interview churn.</p>
                </div>
                <div class="v-item">
                  <h4>4. 15+ Wasted Engineering Hours Per Hire</h4>
                  <p>Senior developers spend hundreds of hours interviewing candidates who passed online tests but cannot code.</p>
                </div>
              </div>
            </div>

            <!-- Deservify Physical Supervision -->
            <div class="card-col new-col deservify-card">
              <div class="tag green-tag">🛡️ The Proveyu Physical Standard</div>
              <h2>Invigilated In-Person Exam Labs</h2>
              <p class="desc">Proveyu partners with national exam infrastructure (TCS iON / JEE test centres) with physical invigilator oversight and biometric entry control.</p>

              <div class="security-list">
                <div class="s-item">
                  <h4>1. Biometric Fingerprint & Govt ID Check</h4>
                  <p>Candidates must present original physical Govt photo IDs and undergo fingerprint scans at the hall entry gate.</p>
                </div>
                <div class="s-item">
                  <h4>2. Air-Gapped Test Terminals & CCTV Audit</h4>
                  <p>Tests are administered on locked-down lab machines with external USB block, webcam proctoring, and human invigilator patrolling.</p>
                </div>
                <div class="s-item">
                  <h4>3. Multi-Dimensional Skill Passport</h4>
                  <p>Provides granular competency ratings across algorithms, QA, backend, and debugging rather than a simple pass/fail mark.</p>
                </div>
                <div class="s-item">
                  <h4>4. Direct Fast-Track Technical Interviews</h4>
                  <p>Recruiters skip initial screening tests entirely, saving 18+ engineering hours per hired developer.</p>
                </div>
              </div>
            </div>

          </div>

          <!-- Bottom CTA -->
          <div class="bottom-cta-card text-center margin-top-xl">
            <h2>Experience Un-Cheatable Skill Signal Today</h2>
            <div class="cta-flex">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">🎓 Register for Verification</a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">💼 Partner as Recruiter / Agency</a>
            </div>
          </div>

        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
      color: #FFFFFF;
      padding: 4rem 0;
    }
    .page-title {
      font-size: 2.75rem;
      color: #FFFFFF;
      margin: 0.75rem 0;
    }
    .page-subtitle {
      font-size: 1.15rem;
      color: #94A3B8;
      max-width: 650px;
      margin: 0 auto;
    }
    .section-padding {
      padding: 4rem 0 6rem 0;
      background: var(--bg-subtle);
    }
    .comparison-detailed-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
    }
    .old-col {
      background: var(--bg-card);
      border: 1px solid rgba(239, 68, 68, 0.3);
    }
    .new-col {
      background: var(--bg-card);
      border: 1.5px solid rgba(16, 185, 129, 0.4);
      box-shadow: var(--shadow-lg);
    }
    .tag {
      display: inline-block;
      font-size: 0.8rem;
      font-weight: 700;
      padding: 0.35rem 0.85rem;
      border-radius: var(--radius-full);
      margin-bottom: 1rem;
    }
    .red-tag { background: var(--accent-red-light); color: var(--accent-red); }
    .green-tag { background: var(--primary-subtle); color: var(--primary); }
    .card-col h2 { font-size: 1.6rem; margin-bottom: 0.5rem; }
    .card-col .desc { font-size: 0.95rem; color: var(--text-muted); margin-bottom: 1.5rem; }
    
    .vulnerability-list, .security-list {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }
    .v-item, .s-item {
      background: var(--bg-subtle);
      padding: 1rem;
      border-radius: var(--radius-md);
      border: 1px solid var(--border-color);
    }
    .v-item h4 { color: var(--accent-red); font-size: 0.95rem; margin-bottom: 0.25rem; }
    .s-item h4 { color: var(--primary); font-size: 0.95rem; margin-bottom: 0.25rem; }
    .v-item p, .s-item p { font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; margin: 0; }

    .margin-top-xl { margin-top: 4rem; }
    .bottom-cta-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 3rem;
      box-shadow: var(--shadow-md);
    }
    .bottom-cta-card h2 { margin-bottom: 1.5rem; }
    .cta-flex { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }

    @media (max-width: 850px) {
      .comparison-detailed-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class WhyInPersonComponent { }
