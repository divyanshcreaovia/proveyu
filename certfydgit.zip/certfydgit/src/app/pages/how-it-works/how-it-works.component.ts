import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-how-it-works',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-teal">End-to-End Verification Journey</span>
          <h1 class="page-title">How Proveyu Skill Verification Works</h1>
          <p class="page-subtitle">
            From initial track selection to physical exam hall invigilation and direct recruiter placement — an un-cheatable merit system.
          </p>
        </div>
      </section>

      <!-- 4 Detailed Steps Section -->
      <section class="section-padding">
        <div class="container">
          <div class="steps-vertical-list">
            
            <!-- Step 1 -->
            <div class="step-detail-card deservify-card">
              <div class="step-num">01</div>
              <div class="step-body">
                <span class="badge badge-teal">Step 1: Account Registration & Track Choice</span>
                <h2>Select Your Skill Domain or Universal Fresher Track</h2>
                <p>
                  Candidates register their academic details and choose their specialization track (Java Spring Boot, QA & Test Automation, Python Data, Full Stack) or select the <strong>Universal Fresher Competency Passport</strong>.
                </p>
                <ul class="step-checklist">
                  <li>✓ Free initial profile creation for all candidates</li>
                  <li>✓ Multi-track flexibility for freshers and experienced engineers</li>
                  <li>✓ Pre-test practice materials and terminal simulator access</li>
                </ul>
              </div>
            </div>

            <!-- Step 2 -->
            <div class="step-detail-card deservify-card">
              <div class="step-num">02</div>
              <div class="step-body">
                <span class="badge badge-teal">Step 2: Partner Exam Centre Slot Booking</span>
                <h2>Reserve Your Spot at High-Stakes Test Infrastructure</h2>
                <p>
                  Pick a preferred date and partner examination center near your city (TCS iON Digital Zones, JEE Authorized Computer Labs). Receive an official digital Admit Card featuring biometric verification QR code.
                </p>
                <ul class="step-checklist">
                  <li>✓ Over 480+ partner test centres across major Indian tech hubs</li>
                  <li>✓ Flexible weekend slots (Morning & Afternoon sessions)</li>
                  <li>✓ Automated Admit Card PDF generation with roll number & hall instructions</li>
                </ul>
              </div>
            </div>

            <!-- Step 3 -->
            <div class="step-detail-card deservify-card">
              <div class="step-num">03</div>
              <div class="step-body">
                <span class="badge badge-gold">Step 3: In-Person Invigilated Assessment</span>
                <h2>Attempt Practical Coding & Scenario Tasks in Monitored Labs</h2>
                <p>
                  Present original photo ID at the test hall gate for biometric fingerprint verification. Candidates take practical 3-hour skill evaluations on air-gapped test terminals under human invigilator and CCTV supervision.
                </p>
                <ul class="step-checklist">
                  <li>✓ Zero secondary screen, proxy test-taker, or AI relay leakage</li>
                  <li>✓ Hands-on scenario tasks (bug fixing, API integration, REST assertions)</li>
                  <li>✓ In-person proctor audit logs cryptographically hashed</li>
                </ul>
              </div>
            </div>

            <!-- Step 4 -->
            <div class="step-detail-card deservify-card highlight-card">
              <div class="step-num">04</div>
              <div class="step-body">
                <span class="badge badge-green">Step 4: Skill Passport & Direct Interview Invites</span>
                <h2>Skip Initial Screening & Connect directly with Top Recruiters</h2>
                <p>
                  Your multi-dimensional Skill Passport is generated. Top startups, corporate enterprises, and placement agencies browse unmasked scores and send direct technical interview requests with zero extra screening tests.
                </p>
                <ul class="step-checklist">
                  <li>✓ Multi-dimensional score breakdown across logic, QA, and backend</li>
                  <li>✓ Direct interview scheduling bypassing resume filters</li>
                  <li>✓ 94% interview-to-placement success rate</li>
                </ul>
              </div>
            </div>

          </div>

          <div class="cta-box text-center margin-top-lg">
            <h2>Ready to Experience Verified Skill Hiring?</h2>
            <div class="cta-btn-row">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">
                🎓 Register as Candidate →
              </a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
                💼 Hire Verified Talent →
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #0F7A5C 0%, #0B5E46 100%);
      color: #FFFFFF;
      padding: 4rem 0;
    }
    .page-title {
      font-size: 2.75rem;
      color: #FFFFFF;
      margin: 0.75rem 0;
    }
    .page-subtitle {
      font-size: 1.15rem;
      opacity: 0.9;
      max-width: 650px;
      margin: 0 auto;
    }
    .section-padding {
      padding: 4rem 0 6rem 0;
      background: var(--bg-subtle);
    }
    .steps-vertical-list {
      display: flex;
      flex-direction: column;
      gap: 2rem;
    }
    .step-detail-card {
      display: grid;
      grid-template-columns: 80px 1fr;
      gap: 2rem;
      padding: 2.25rem;
      align-items: flex-start;
    }
    .highlight-card {
      border: 2px solid var(--primary);
      box-shadow: var(--shadow-md);
    }
    .step-num {
      font-family: 'Outfit', sans-serif;
      font-size: 2.8rem;
      font-weight: 800;
      color: var(--primary);
      line-height: 1;
      background: var(--primary-subtle);
      width: 70px;
      height: 70px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .step-body h2 {
      font-size: 1.6rem;
      margin: 0.5rem 0 0.75rem 0;
    }
    .step-body p {
      font-size: 1rem;
      color: var(--text-muted);
      line-height: 1.6;
      margin-bottom: 1.25rem;
    }
    .step-checklist {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.4rem;
      font-size: 0.9rem;
      font-weight: 600;
      color: var(--heading);
    }
    .margin-top-lg {
      margin-top: 4rem;
    }
    .cta-box {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 3rem;
      box-shadow: var(--shadow-md);
    }
    .cta-box h2 {
      margin-bottom: 1.5rem;
      color: var(--heading);
    }
    .cta-btn-row {
      display: flex;
      justify-content: center;
      gap: 1rem;
      flex-wrap: wrap;
    }
    @media (max-width: 768px) {
      .step-detail-card {
        grid-template-columns: 1fr;
        gap: 1rem;
      }
    }
  `]
})
export class HowItWorksComponent { }
