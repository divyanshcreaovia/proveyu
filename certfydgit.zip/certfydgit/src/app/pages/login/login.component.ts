import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { AuthService } from '../../core/services/auth.service';
import { UserRole } from '../../core/models/deservify.models';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="login-page">
      <div class="container container-narrow">
        <div class="login-card deservify-card">
          <div class="login-header text-center">
            <div class="logo-shield-mini">
              <svg width="24" height="28" viewBox="0 0 24 28" fill="none">
                <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
                <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
              </svg>
            </div>
            <h2>Sign in to Proveyu</h2>
            <p>Access your verified skill passport or recruiter candidate pipeline.</p>
          </div>

          <!-- Role Toggle Tabs -->
          <div class="role-tabs">
            <button 
              class="tab-btn" 
              [class.active]="selectedRole === 'candidate'" 
              (click)="selectedRole = 'candidate'">
              🎓 Candidate Portal
            </button>
            <button 
              class="tab-btn" 
              [class.active]="selectedRole.startsWith('recruiter')" 
              (click)="selectedRole = 'recruiter_agency'">
              💼 Recruiter Portal
            </button>
          </div>

          <!-- Login Form -->
          <form (ngSubmit)="onLogin()" class="login-form">
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input 
                type="email" 
                class="form-control" 
                [(ngModel)]="email" 
                name="email" 
                placeholder="name@example.com" 
                required>
            </div>

            <div class="form-group">
              <label class="form-label">Password</label>
              <input 
                type="password" 
                class="form-control" 
                [(ngModel)]="password" 
                name="password" 
                placeholder="••••••••" 
                required>
            </div>

            <!-- Recruiter Org Type Sub-selector -->
            <div class="form-group" *ngIf="selectedRole.startsWith('recruiter')">
              <label class="form-label">Account Type</label>
              <select class="form-control" [(ngModel)]="selectedRole" name="recruiterType">
                <option value="recruiter_agency">Placement Agency</option>
                <option value="recruiter_startup">Startup Recruiter</option>
                <option value="recruiter_company">Enterprise Company</option>
              </select>
            </div>

            <div class="form-options">
              <label class="remember-me">
                <input type="checkbox" [(ngModel)]="rememberMe" name="rememberMe">
                <span>Remember me on this device</span>
              </label>
              <a routerLink="/forgot-password" class="forgot-link">Forgot password?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-lg full-width">
              Sign In to Dashboard →
            </button>
          </form>

          <!-- Quick Demo Persona Fill Buttons -->
          <div class="demo-login-box">
            <span class="demo-title">⚡ Quick Demo Persona One-Click Logins:</span>
            <div class="demo-btns-grid">
              <button (click)="quickLogin('candidate')" class="demo-chip">
                🎓 Rahul Sharma (Candidate)
              </button>
              <button (click)="quickLogin('recruiter_agency')" class="demo-chip">
                💼 Apex Placement Agency
              </button>
              <button (click)="quickLogin('recruiter_startup')" class="demo-chip">
                🚀 CloudScale Startup
              </button>
              <button (click)="quickLogin('recruiter_company')" class="demo-chip">
                🏢 FinTech Enterprise
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .login-page {
      padding: 4rem 0 6rem 0;
      background: radial-gradient(circle at 50% 20%, rgba(15, 122, 92, 0.05) 0%, transparent 60%);
      min-height: calc(100vh - 72px - 300px);
    }
    .login-card {
      max-width: 480px;
      margin: 0 auto;
      padding: 2.25rem;
    }
    .logo-shield-mini {
      width: 48px;
      height: 48px;
      background: var(--primary-subtle);
      border-radius: var(--radius-md);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 0.85rem auto;
    }
    .login-header h2 {
      font-size: 1.6rem;
      margin-bottom: 0.35rem;
    }
    .login-header p {
      color: var(--text-muted);
      font-size: 0.9rem;
      margin-bottom: 1.75rem;
    }
    .role-tabs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      background: var(--bg-subtle);
      padding: 0.25rem;
      border-radius: var(--radius-md);
      margin-bottom: 1.5rem;
      border: 1px solid var(--border-color);
    }
    .tab-btn {
      padding: 0.65rem;
      border: none;
      background: none;
      font-weight: 600;
      font-size: 0.875rem;
      color: var(--text-muted);
      border-radius: var(--radius-sm);
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .tab-btn.active {
      background: var(--bg-card);
      color: var(--heading);
      box-shadow: var(--shadow-sm);
    }
    .login-form {
      margin-bottom: 1.75rem;
    }
    .form-options {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.85rem;
      margin-bottom: 1.5rem;
    }
    .remember-me {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      color: var(--text-muted);
      cursor: pointer;
    }
    .forgot-link {
      font-weight: 600;
    }
    .full-width {
      width: 100%;
    }
    .demo-login-box {
      border-top: 1px dashed var(--border-color);
      padding-top: 1.25rem;
    }
    .demo-title {
      font-size: 0.775rem;
      font-weight: 700;
      color: var(--text-muted);
      display: block;
      margin-bottom: 0.75rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .demo-btns-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
    }
    .demo-chip {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      padding: 0.5rem 0.65rem;
      border-radius: var(--radius-sm);
      font-size: 0.775rem;
      font-weight: 600;
      color: var(--heading);
      cursor: pointer;
      text-align: left;
      transition: all var(--transition-fast);
    }
    .demo-chip:hover {
      background: var(--primary-subtle);
      border-color: var(--primary);
      color: var(--primary);
    }
  `]
})
export class LoginComponent {
  authService = inject(AuthService);
  router = inject(Router);

  email = 'rahul.sharma@example.com';
  password = 'password123';
  selectedRole: UserRole = 'candidate';
  rememberMe = true;

  onLogin() {
    this.authService.login(this.email, this.selectedRole);
    if (this.selectedRole === 'candidate') {
      this.router.navigate(['/dashboard/candidate']);
    } else {
      this.router.navigate(['/dashboard/recruiter']);
    }
  }

  quickLogin(role: UserRole) {
    this.selectedRole = role;
    if (role === 'candidate') this.email = 'rahul.sharma@example.com';
    else if (role === 'recruiter_agency') this.email = 'vikram@apexplacements.com';
    else if (role === 'recruiter_startup') this.email = 'ananya@cloudscale.io';
    else this.email = 'siddharth.m@infosystems.com';

    this.onLogin();
  }
}
