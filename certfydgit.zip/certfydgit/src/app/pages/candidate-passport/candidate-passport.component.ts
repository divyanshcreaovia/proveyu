import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';
import { CandidateService } from '../../core/services/candidate.service';
import { PassportModalComponent } from '../../shared/components/passport-modal/passport-modal.component';

@Component({
  selector: 'app-candidate-passport',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent, PassportModalComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="passport-page">
      <div class="container">
        
        <!-- Breadcrumb & Top Bar -->
        <div class="top-bar">
          <a routerLink="/dashboard/candidate" class="back-link"><i class="fa-solid fa-arrow-left me-1"></i> Back to Candidate Dashboard</a>
          <div class="top-actions">
            <button (click)="isModalOpen = true" class="btn btn-secondary btn-sm">
              <i class="fa-solid fa-eye me-1"></i> Interactive Modal View
            </button>
            <button (click)="copyLink()" class="btn btn-primary btn-sm">
              <i class="fa-solid" [ngClass]="linkCopied ? 'fa-check' : 'fa-share-nodes'"></i> {{ linkCopied ? 'Link Copied!' : 'Share Verified Passport' }}
            </button>
          </div>
        </div>

        <!-- Main Passport Display Card -->
        <div class="passport-hero-card deservify-card">
          <div class="hero-top-ribbon">
            <div class="verified-seal">
              <svg width="24" height="28" viewBox="0 0 24 28" fill="none">
                <path d="M12 0L24 5V13C24 20.5 18.8 26.8 12 28C5.2 26.8 0 20.5 0 13V5L12 0Z" fill="#0F7A5C"/>
                <path d="M10.2 18L5.7 13.5L7.4 11.8L10.2 14.6L16.6 8.2L18.3 9.9L10.2 18Z" fill="#FFFFFF"/>
              </svg>
              <span>IN-PERSON INVIGILATED SKILL PASSPORT</span>
            </div>
            <span class="badge badge-gold"><i class="fa-solid fa-shield me-1"></i> {{ passport?.tierBadge || 'Platinum Verified' }}</span>
          </div>

          <div class="hero-content-grid">
            <div class="candidate-main-meta">
              <img [src]="profile().photoUrl" alt="Photo" class="candidate-passport-photo">
              <div>
                <h1 class="candidate-name">{{ profile().fullName }}</h1>
                <p class="candidate-sub">{{ profile().college }} ({{ profile().degree }}, {{ profile().graduationYear }})</p>
                <div class="meta-pills">
                  <span class="pill-tag"><i class="fa-solid fa-bullseye me-1 text-primary"></i> Track: {{ profile().selectedTrack }}</span>
                  <span class="pill-tag"><i class="fa-solid fa-fingerprint me-1 text-primary"></i> Passport ID: {{ passport?.passportId }}</span>
                  <span class="pill-tag text-green"><i class="fa-solid fa-circle-check me-1"></i> In-Person Audit Passed</span>
                </div>
              </div>
            </div>

            <div class="score-spotlight-box">
              <div class="score-ring">
                <span class="score-number">{{ passport?.overallScore }}</span>
                <span class="score-max">/ 100</span>
              </div>
              <span class="percentile-badge">Top 5% National Percentile</span>
            </div>
          </div>

          <!-- Recommendations Grid -->
          <div class="recommendations-box">
            <div class="rec-card">
              <span class="rec-icon"><i class="fa-solid fa-bolt text-warning"></i></span>
              <div>
                <span class="rec-label">Primary Role Recommendation</span>
                <h4 class="rec-title">{{ passport?.primaryRoleRecommendation }}</h4>
              </div>
            </div>
            <div class="rec-card">
              <span class="rec-icon"><i class="fa-solid fa-bullseye text-primary"></i></span>
              <div>
                <span class="rec-label">Secondary Role Fit</span>
                <h4 class="rec-title">{{ passport?.secondaryRoleRecommendation }}</h4>
              </div>
            </div>
            <div class="rec-card">
              <span class="rec-icon"><i class="fa-solid fa-location-dot text-danger"></i></span>
              <div>
                <span class="rec-label">Verification Exam Centre</span>
                <h4 class="rec-title">{{ passport?.verificationCenter }}</h4>
              </div>
            </div>
          </div>
        </div>

        <!-- Detailed Audit & Competency Breakdown -->
        <div class="passport-sections-grid">
          
          <!-- Competencies -->
          <div class="deservify-card">
            <div class="section-head">
              <h3>Invigilated Skill Evaluation</h3>
              <span class="section-sub">Standardized hands-on coding & architectural challenge breakdown</span>
            </div>

            <div class="comp-list">
              <div class="comp-item" *ngFor="let item of passport?.competencies">
                <div class="comp-meta">
                  <span class="comp-name">{{ item.name }}</span>
                  <span class="comp-status-badge" [ngClass]="{
                    'badge-teal': item.score >= 85,
                    'badge-gold': item.score < 85
                  }">{{ item.score }}% • {{ item.status }}</span>
                </div>
                <div class="bar-bg">
                  <div class="bar-fill" [style.width.%]="item.score"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Audit Proof & Anti-Cheat Record -->
          <div class="deservify-card audit-card">
            <div class="section-head">
              <h3>🛡️ Centre Security Audit Log</h3>
              <span class="section-sub">Immutable cryptographic proof of identity & supervised testing</span>
            </div>

            <div class="audit-details">
              <div class="audit-row">
                <span class="audit-key">Biometric Fingerprint Match:</span>
                <span class="audit-val text-green">✓ Verified at Entry Gate</span>
              </div>
              <div class="audit-row">
                <span class="audit-key">Govt ID Verification:</span>
                <span class="audit-val text-green">✓ Aadhaar / PAN Matched</span>
              </div>
              <div class="audit-row">
                <span class="audit-key">Proctor Supervision:</span>
                <span class="audit-val text-green">✓ TCS iON Certified Invigilator</span>
              </div>
              <div class="audit-row">
                <span class="audit-key">AI Sandbox Environment:</span>
                <span class="audit-val text-green">✓ Internet Restricted / Zero External Assistance</span>
              </div>
              <div class="audit-row">
                <span class="audit-key">Invigilation Hash:</span>
                <code class="audit-hash">sha256:e3b0c44298fc1c149afbf4c899...</code>
              </div>
            </div>

            <div class="pdf-download-box">
              <button (click)="downloadPdf()" class="btn btn-primary full-width">
                📥 Download Official Verified PDF Passport
              </button>
            </div>
          </div>
        </div>

      </div>
    </main>

    <app-passport-modal
      [isOpen]="isModalOpen"
      [passport]="passport || null"
      (close)="isModalOpen = false">
    </app-passport-modal>

    <app-footer></app-footer>
  `,
  styles: [`
    .passport-page {
      padding: 2.5rem 0 5rem 0;
      background: var(--bg-main);
      min-height: calc(100vh - 72px - 300px);
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }
    .back-link {
      font-weight: 600;
      color: var(--primary);
      font-size: 0.9rem;
      transition: color var(--transition-fast);
    }
    .back-link:hover {
      color: var(--primary-light);
    }
    .top-actions {
      display: flex;
      gap: 0.75rem;
    }
    .passport-hero-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 2.25rem;
      box-shadow: var(--shadow-lg);
      margin-bottom: 2rem;
      position: relative;
      overflow: hidden;
    }
    .hero-top-ribbon {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 1.25rem;
      border-bottom: 1px dashed var(--border-color);
      margin-bottom: 1.75rem;
    }
    .verified-seal {
      display: flex;
      align-items: center;
      gap: 0.65rem;
      font-weight: 800;
      font-size: 0.85rem;
      color: var(--primary);
      letter-spacing: 0.75px;
    }
    .hero-content-grid {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 2rem;
      margin-bottom: 2rem;
      flex-wrap: wrap;
    }
    .candidate-main-meta {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }
    .candidate-passport-photo {
      width: 92px;
      height: 92px;
      border-radius: var(--radius-lg);
      object-fit: cover;
      border: 3px solid var(--primary);
      box-shadow: 0 4px 14px var(--primary-glow);
    }
    .candidate-name {
      font-size: 1.9rem;
      margin: 0 0 0.25rem 0;
      color: var(--heading);
      font-weight: 800;
    }
    .candidate-sub {
      color: var(--text-muted);
      font-size: 0.925rem;
      margin-bottom: 0.75rem;
    }
    .meta-pills {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .pill-tag {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      color: var(--text-main);
      padding: 0.3rem 0.75rem;
      border-radius: var(--radius-full);
      font-size: 0.775rem;
      font-weight: 600;
    }
    .pill-tag.text-green {
      color: var(--primary);
      border-color: var(--primary-glow);
      background: var(--primary-subtle);
    }
    .score-spotlight-box {
      background: linear-gradient(135deg, rgba(15, 122, 92, 0.12) 0%, rgba(16, 185, 129, 0.05) 100%);
      border: 2px solid var(--primary);
      border-radius: var(--radius-lg);
      padding: 1.5rem 2.25rem;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      box-shadow: 0 8px 24px var(--primary-glow);
    }
    .score-ring {
      display: flex;
      align-items: baseline;
      gap: 0.35rem;
    }
    .score-number {
      font-family: 'Outfit', sans-serif;
      font-size: 3.25rem;
      font-weight: 800;
      line-height: 1;
      color: var(--primary);
      text-shadow: 0 2px 10px var(--primary-glow);
    }
    .score-max {
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--text-muted);
    }
    .percentile-badge {
      font-size: 0.775rem;
      font-weight: 800;
      color: #92400E;
      background: #FEF3C7;
      border: 1px solid #F59E0B;
      padding: 0.25rem 0.75rem;
      border-radius: var(--radius-full);
      margin-top: 0.65rem;
      letter-spacing: 0.3px;
    }
    .recommendations-box {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.25rem;
      background: var(--bg-subtle);
      padding: 1.25rem;
      border-radius: var(--radius-lg);
      border: 1px solid var(--border-color);
    }
    .rec-card {
      display: flex;
      align-items: center;
      gap: 0.85rem;
    }
    .rec-icon {
      font-size: 1.4rem;
      width: 42px;
      height: 42px;
      border-radius: var(--radius-md);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .rec-label {
      font-size: 0.7rem;
      color: var(--text-muted);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      display: block;
      margin-bottom: 2px;
    }
    .rec-title {
      font-size: 0.925rem;
      margin: 0;
      color: var(--heading);
      font-weight: 700;
    }

    .passport-sections-grid {
      display: grid;
      grid-template-columns: 1.35fr 1fr;
      gap: 1.75rem;
      margin-top: 2rem;
    }
    .section-head h3 {
      font-size: 1.2rem;
      margin: 0 0 0.25rem 0;
      color: var(--heading);
      font-weight: 700;
    }
    .section-sub {
      font-size: 0.825rem;
      color: var(--text-muted);
      display: block;
      margin-bottom: 1.5rem;
    }

    .comp-list {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }
    .comp-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.9rem;
      font-weight: 600;
      margin-bottom: 0.45rem;
      color: var(--heading);
    }
    .comp-status-badge {
      font-size: 0.775rem;
      font-weight: 700;
      padding: 0.25rem 0.65rem;
      border-radius: var(--radius-full);
    }
    .badge-teal {
      background: var(--primary-subtle);
      color: var(--primary);
      border: 1px solid var(--primary-glow);
    }
    .badge-gold {
      background: #FEF3C7;
      color: #B45309;
      border: 1px solid #F59E0B;
    }
    .bar-bg {
      height: 10px;
      background: var(--bg-subtle);
      border-radius: 9999px;
      overflow: hidden;
      border: 1px solid var(--border-color);
    }
    .bar-fill {
      height: 100%;
      background: linear-gradient(90deg, #0F7A5C 0%, #10B981 100%);
      border-radius: 9999px;
    }

    .audit-card {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .audit-details {
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
      margin-bottom: 1.75rem;
      font-size: 0.875rem;
    }
    .audit-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px dashed var(--border-color);
      padding-bottom: 0.6rem;
    }
    .audit-key {
      color: var(--text-muted);
      font-weight: 600;
    }
    .audit-val.text-green {
      color: var(--primary);
      font-weight: 700;
    }
    .audit-hash {
      font-family: monospace;
      font-size: 0.75rem;
      background: var(--bg-subtle);
      color: var(--text-main);
      padding: 0.25rem 0.5rem;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border-color);
    }
    .pdf-download-box {
      margin-top: auto;
    }
    .full-width {
      width: 100%;
    }

    /* Dark Mode Enhanced Overrides for Candidate Passport */
    [data-theme="dark"] .score-spotlight-box,
    body.dark-theme .score-spotlight-box {
      background: linear-gradient(135deg, rgba(15, 122, 92, 0.25) 0%, rgba(16, 185, 129, 0.1) 100%);
      border-color: #10B981;
      box-shadow: 0 0 25px rgba(16, 185, 129, 0.25);
    }

    [data-theme="dark"] .score-number,
    body.dark-theme .score-number {
      color: #34D399;
      text-shadow: 0 0 16px rgba(52, 211, 153, 0.4);
    }

    [data-theme="dark"] .score-max,
    body.dark-theme .score-max {
      color: #94A3B8;
    }

    [data-theme="dark"] .percentile-badge,
    body.dark-theme .percentile-badge {
      background: rgba(245, 158, 11, 0.2);
      color: #FBBF24;
      border-color: rgba(245, 158, 11, 0.4);
    }

    [data-theme="dark"] .pill-tag,
    body.dark-theme .pill-tag {
      background: #0F172A;
      border-color: #334155;
      color: #CBD5E1;
    }

    [data-theme="dark"] .pill-tag.text-green,
    body.dark-theme .pill-tag.text-green {
      background: rgba(15, 122, 92, 0.3);
      border-color: #10B981;
      color: #34D399;
    }

    [data-theme="dark"] .verified-seal,
    body.dark-theme .verified-seal {
      color: #34D399;
    }

    [data-theme="dark"] .audit-val.text-green,
    body.dark-theme .audit-val.text-green {
      color: #34D399 !important;
    }

    [data-theme="dark"] .badge-teal,
    body.dark-theme .badge-teal {
      background: rgba(15, 122, 92, 0.3) !important;
      color: #34D399 !important;
      border-color: #10B981 !important;
    }

    [data-theme="dark"] .audit-key,
    body.dark-theme .audit-key {
      color: #94A3B8;
    }

    [data-theme="dark"] .audit-hash,
    body.dark-theme .audit-hash {
      background: #0F172A;
      border-color: #334155;
      color: #94A3B8;
    }

    [data-theme="dark"] .rec-icon,
    body.dark-theme .rec-icon {
      background: #0F172A;
      border-color: #334155;
    }

    @media (max-width: 850px) {
      .passport-sections-grid { grid-template-columns: 1fr; }
      .recommendations-box { grid-template-columns: 1fr; }
    }
  `]
})
export class CandidatePassportComponent {
  candidateService = inject(CandidateService);
  profile = this.candidateService.currentProfile;
  passport = this.profile().passport;

  isModalOpen = false;
  linkCopied = false;

  copyLink() {
    this.linkCopied = true;
    setTimeout(() => this.linkCopied = false, 3000);
  }

  downloadPdf() {
    alert(`Downloading Official Skill Passport PDF for ${this.profile().fullName} (Passport ID: ${this.passport?.passportId})`);
  }
}
