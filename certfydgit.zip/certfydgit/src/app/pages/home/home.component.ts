import { Component, inject, OnInit, AfterViewInit, ElementRef, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <!-- AMBIENT FLOATING MESH BACKGROUND -->
    <div class="ambient-glow-wrapper">
      <div class="glow-orb orb-1"></div>
      <div class="glow-orb orb-2"></div>
      <div class="glow-orb orb-3"></div>
    </div>

    <!-- HERO SECTION -->
    <section class="hero-section">
      <div class="container hero-container">
        <div class="hero-text-col reveal-on-scroll">
          <div class="pill-badge">
            <span class="badge-dot"></span>
            <span>Skill Speaks Louder Than a Resume</span>
          </div>

          <h1 class="hero-title">
            Proof Over Resumes.<br>
            <span class="gradient-text">Hire on Proven Ability.</span>
          </h1>

          <p class="hero-subtitle">
            Proveyu replaces unverified resume claims with invigilated, in-person skill assessments at partner exam centres. Candidates get a multi-dimensional Skill Passport; recruiters get un-cheatable merit signal.
          </p>

          <!-- Dual Primary CTAs (Dynamically updated based on Auth State) -->
          <div class="hero-cta-group" *ngIf="!authService.isLoggedIn(); else heroAuthCtas">
            <a routerLink="/register/candidate" class="btn btn-lg btn-primary shadow-glow">
              <span>🎓 I'm a Candidate — Get Verified</span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
            <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
              <span>💼 I'm Hiring — Access Verified Talent</span>
            </a>
          </div>

          <ng-template #heroAuthCtas>
            <div class="hero-cta-group">
              <ng-container *ngIf="authService.currentRole() === 'candidate'">
                <a routerLink="/dashboard/candidate" class="btn btn-lg btn-primary shadow-glow">
                  <span>📊 Go to Candidate Dashboard</span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
                <a routerLink="/candidate/passport" class="btn btn-lg btn-secondary">
                  <span>🪪 View My Skill Passport</span>
                </a>
              </ng-container>

              <ng-container *ngIf="authService.currentRole() !== 'candidate'">
                <a routerLink="/dashboard/recruiter" class="btn btn-lg btn-primary shadow-glow">
                  <span>💼 Go to Recruiter Dashboard</span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
                <a routerLink="/recruiter/verifiedtalents" class="btn btn-lg btn-secondary">
                  <span>🔍 Search Verified Candidates</span>
                </a>
              </ng-container>
            </div>
          </ng-template>

          <div class="hero-trust-row">
            <div class="trust-stat">
              <span class="stat-num">15,000+</span>
              <span class="stat-lbl">Candidates Verified</span>
            </div>
            <div class="trust-divider"></div>
            <div class="trust-stat">
              <span class="stat-num">450+</span>
              <span class="stat-lbl">Partner Test Centres</span>
            </div>
            <div class="trust-divider"></div>
            <div class="trust-stat">
              <span class="stat-num">0%</span>
              <span class="stat-lbl">Remote Proxy Cheating</span>
            </div>
          </div>
        </div>

        <!-- Hero Mockup Card -->
        <div class="hero-visual-col reveal-on-scroll delay-1">
          <div class="passport-preview-card float-animation">
            <div class="card-top-bar">
              <div class="brand">
                <span class="shield-dot">🛡️</span>
                <span>PROVEYU SKILL PASSPORT</span>
              </div>
              <span class="badge badge-gold">Top 3% Verified</span>
            </div>

            <div class="candidate-header-mini">
              <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150" alt="Candidate" class="mini-avatar">
              <div>
                <h3 class="name">Rahul Sharma</h3>
                <span class="track">Universal Fresher Competency</span>
                <span class="centre">📍 TCS iON Center, Koramangala</span>
              </div>
              <div class="score-badge-circle">
                <span class="num">92</span>
                <span class="lbl">SCORE</span>
              </div>
            </div>

            <div class="skills-bars-mini">
              <div class="bar-row">
                <span>Core Logic & Algorithms</span>
                <div class="bar"><div class="fill" style="width: 95%"></div></div>
                <span class="pts">95%</span>
              </div>
              <div class="bar-row">
                <span>QA & Test Automation</span>
                <div class="bar"><div class="fill" style="width: 94%"></div></div>
                <span class="pts">94%</span>
              </div>
              <div class="bar-row">
                <span>Java Backend Development</span>
                <div class="bar"><div class="fill" style="width: 88%"></div></div>
                <span class="pts">88%</span>
              </div>
            </div>

            <div class="recommendation-pill">
              <span class="icon">🎯</span>
              <span><strong>Primary Fit:</strong> QA / Automation Engineer | <strong>Secondary:</strong> Java Microservices</span>
            </div>

            <div class="invigilated-stamp">
              <span class="stamp-icon">✓</span>
              <span>Invigilator Supervision Log #TCS-BLR-04 Confirmed</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- PROBLEM VS SOLUTION COMPARISON -->
    <section class="section-padding bg-subtle" id="value-props">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">The Core Problem</span>
          <h2>Why Online Assessments Fail & Physical Verification Wins</h2>
          <p class="section-desc">
            Online proctoring only watches the camera. It cannot see a second person sitting beside the candidate, an external keyboard relaying input, or real-time AI assistance.
          </p>
        </div>

        <div class="comparison-grid">
          <div class="comp-card old-way reveal-left">
            <div class="card-tag red-tag">❌ Traditional Resume & Remote Tests</div>
            <h3>Broken & Easy to Cheat</h3>
            <ul>
              <li><strong>Resume Inflation:</strong> Up to 60% of resumes contain exaggerated or fake project claims.</li>
              <li><strong>Remote Proxy Cheating:</strong> High test scores achieved via hidden proxy test-takers or relayed screens.</li>
              <li><strong>College-Brand Gatekeeping:</strong> Deserving candidates from tier-2/3 colleges are auto-rejected before anyone sees their actual ability.</li>
              <li><strong>Wasted Interview Hours:</strong> Engineering teams spend 15+ hours interviewing candidates who look great on paper but fail basic coding tasks.</li>
            </ul>
          </div>

          <div class="comp-card deservify-way reveal-right">
            <div class="card-tag green-tag">🛡️ The Deservify In-Person Supervised Standard</div>
            <h3>Verified, Un-cheatable Skill Proof</h3>
            <ul>
              <li><strong>Supervised Exam Centres:</strong> Invigilated at existing high-stakes exam infrastructure (TCS iON / JEE test centres) with photo ID & CCTV control.</li>
              <li><strong>Multi-Dimensional Skill Passport:</strong> Not a simple pass/fail score, but an in-depth breakdown across logic, QA, backend, and debugging.</li>
              <li><strong>Fair Access for All:</strong> Talent is recognized purely on ability — bypassing college brand bias and referral gatekeepers.</li>
              <li><strong>Direct Interview Shortcut:</strong> Verified candidates skip online screening tests completely and proceed directly to final tech rounds.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- HOW IT WORKS: 4-STEP VISUAL FLOW -->
    <section class="section-padding" id="how-it-works">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Simple 4-Step Process</span>
          <h2>How Deservify Works for Candidates & Recruiters</h2>
          <p class="section-desc">From registration to direct interview in 4 seamless steps.</p>
        </div>

        <div class="steps-flow-grid">
          <div class="flow-step-card reveal-on-scroll">
            <div class="step-num-badge">1</div>
            <h3>Register & Pick Track</h3>
            <p>Select your domain (Java, QA, Python, Web) or opt for the <strong>Universal Fresher Competency</strong> test.</p>
          </div>

          <div class="flow-step-card reveal-on-scroll delay-1">
            <div class="step-num-badge">2</div>
            <h3>Book In-Person Centre</h3>
            <p>Pick a date and partner exam centre (TCS iON / JEE labs) near your city. Receive your official Admit Card with QR code.</p>
          </div>

          <div class="flow-step-card reveal-on-scroll delay-2">
            <div class="step-num-badge">3</div>
            <h3>Invigilated Assessment</h3>
            <p>Attempt practical, scenario-based coding tasks supervised by human invigilators and evaluated by domain experts.</p>
          </div>

          <div class="flow-step-card reveal-on-scroll delay-3">
            <div class="step-num-badge highlight-step">4</div>
            <h3>Receive Passport & Get Hired</h3>
            <p>Your multi-dimensional Skill Passport is generated. Recruiters browse and send direct interview invites with zero extra screening.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- UNIVERSAL FRESHER COMPETENCY MODEL -->
    <section class="section-padding bg-subtle" id="universal-fresher">
      <div class="container">
        <div class="fresher-box">
          <div class="fresher-content reveal-left">
            <span class="badge badge-gold">Game Changer for Freshers</span>
            <h2>The Universal Fresher Competency Passport</h2>
            <p>
              Freshers don't come pre-specialized. Companies hire freshers and allocate them into roles (Backend, QA, Frontend) based on aptitude. Proveyu's Universal Fresher Test evaluates core logic, problem-solving, and hands-on build choices to recommend exact role alignment.
            </p>

            <div class="fresher-benefits">
              <div class="f-item">
                <span class="icon">✨</span>
                <div>
                  <strong>One Test, Multiple Opportunities:</strong>
                  <p>Candidates aren't pigeonholed into a single role. A single test opens doors for QA, Backend, and Full Stack positions.</p>
                </div>
              </div>
              <div class="f-item">
                <span class="icon">⚡</span>
                <div>
                  <strong>Evidence-Based Placement for Agencies & Recruiters:</strong>
                  <p>Agencies get a multi-faceted inventory of pre-verified freshers ready for client mapping with zero guess-work.</p>
                </div>
              </div>
            </div>

            <ng-container *ngIf="!authService.isLoggedIn()">
              <a routerLink="/register/candidate" class="btn btn-primary btn-lg margin-top">
                Register for Universal Fresher Verification →
              </a>
            </ng-container>

            <ng-container *ngIf="authService.isLoggedIn() && authService.currentRole() === 'candidate'">
              <a routerLink="/candidate/book-slot" class="btn btn-primary btn-lg margin-top">
                📅 Book Exam Slot for Fresher Verification →
              </a>
            </ng-container>

            <ng-container *ngIf="authService.isLoggedIn() && authService.currentRole() !== 'candidate'">
              <a routerLink="/recruiter/verifiedtalents" class="btn btn-primary btn-lg margin-top">
                🔍 Browse Verified Fresher Candidates →
              </a>
            </ng-container>
          </div>

          <div class="fresher-graphic reveal-right">
            <div class="radar-mockup-card">
              <h4>Multi-Dimensional Competency Radar</h4>
              <div class="competency-bars-full">
                <div class="c-row">
                  <span class="c-label">Core Logic & Control Flow</span>
                  <div class="c-bar"><div class="c-fill" style="width: 95%;"></div></div>
                  <span class="c-score">95/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">QA & Scenario Testing</span>
                  <div class="c-bar"><div class="c-fill" style="width: 92%;"></div></div>
                  <span class="c-score">92/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">Backend Spring Boot</span>
                  <div class="c-bar"><div class="c-fill" style="width: 88%;"></div></div>
                  <span class="c-score">88/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">Debugging & Comprehension</span>
                  <div class="c-bar"><div class="c-fill" style="width: 90%;"></div></div>
                  <span class="c-score">90/100</span>
                </div>
              </div>
              <div class="radar-footer">
                <span>Ranked Placement Recommendation:</span>
                <span class="rec-highlight">1st: QA Engineer | 2nd: Java Developer</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- TRUST & STATS STRIP -->
    <section class="stats-banner-section reveal-on-scroll">
      <div class="container stats-banner-grid">
        <div class="banner-stat">
          <div class="stat-number">15,000+</div>
          <div class="stat-text">Verified Candidates</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">450+</div>
          <div class="stat-text">Exam Centre Partners (TCS iON / JEE)</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">180+</div>
          <div class="stat-text">Hiring Partners & Agencies</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">94%</div>
          <div class="stat-text">Direct Interview-to-Hire Rate</div>
        </div>
      </div>
    </section>

    <!-- FAQ ACCORDION -->
    <section class="section-padding">
      <div class="container container-narrow">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Got Questions?</span>
          <h2>Frequently Asked Questions</h2>
        </div>

        <div class="faq-list reveal-on-scroll">
          <div class="faq-item" *ngFor="let item of faqs; let i = index">
            <button class="faq-question" (click)="toggleFaq(i)">
              <span>{{ item.q }}</span>
              <span class="faq-icon">{{ activeFaq === i ? '−' : '+' }}</span>
            </button>
            <div class="faq-answer" *ngIf="activeFaq === i">
              <p>{{ item.a }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- BOTTOM CTA -->
    <section class="bottom-cta-section">
      <div class="container text-center reveal-on-scroll">
        <h2>Ready to Replace Resumes with Real Proof?</h2>
        <p>Join thousands of candidates and top hiring partners on Proveyu today.</p>
        <div class="cta-btns" *ngIf="!authService.isLoggedIn(); else bottomAuthCtas">
          <a routerLink="/select-role" class="btn btn-lg btn-primary">
            Get Started Now →
          </a>
          <a routerLink="/login" class="btn btn-lg btn-secondary">
            Sign In to Existing Account
          </a>
        </div>

        <ng-template #bottomAuthCtas>
          <div class="cta-btns">
            <ng-container *ngIf="authService.currentRole() === 'candidate'">
              <a routerLink="/dashboard/candidate" class="btn btn-lg btn-primary">
                📊 Open Candidate Dashboard →
              </a>
              <a routerLink="/candidate/book-slot" class="btn btn-lg btn-secondary">
                📅 Book Exam Slot
              </a>
            </ng-container>
            <ng-container *ngIf="authService.currentRole() !== 'candidate'">
              <a routerLink="/dashboard/recruiter" class="btn btn-lg btn-primary">
                💼 Open Recruiter Dashboard →
              </a>
              <a routerLink="/recruiter/verifiedtalents" class="btn btn-lg btn-secondary">
                🔍 Browse Verified Talent
              </a>
            </ng-container>
          </div>
        </ng-template>
      </div>
    </section>

    <app-footer></app-footer>
  `,
  styles: [`
    /* AMBIENT FLOATING MESH BACKGROUND */
    .ambient-glow-wrapper {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      overflow: hidden;
      z-index: 0;
    }
    .glow-orb {
      position: absolute;
      border-radius: 50%;
      filter: blur(110px);
      opacity: 0.18;
      animation: floatOrb 20s ease-in-out infinite alternate;
    }
    .orb-1 {
      width: 550px;
      height: 550px;
      background: radial-gradient(circle, #0F7A5C 0%, #10B981 100%);
      top: -140px;
      right: -100px;
    }
    .orb-2 {
      width: 460px;
      height: 460px;
      background: radial-gradient(circle, #D97706 0%, #F59E0B 100%);
      bottom: 8%;
      left: -160px;
      animation-delay: -6s;
    }
    .orb-3 {
      width: 400px;
      height: 400px;
      background: radial-gradient(circle, #0284C7 0%, #38BDF8 100%);
      top: 38%;
      right: 8%;
      animation-delay: -12s;
    }
    @keyframes floatOrb {
      0% { transform: translate(0, 0) scale(1); }
      100% { transform: translate(60px, 70px) scale(1.15); }
    }

    /* HERO SECTION ENTRANCE */
    @keyframes heroFadeSlide {
      0% { opacity: 0; transform: translateY(30px); }
      100% { opacity: 1; transform: translateY(0); }
    }

    .hero-section .reveal-on-scroll,
    .hero-section .reveal-left,
    .hero-section .reveal-right {
      animation: heroFadeSlide 0.85s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      opacity: 1 !important;
      transform: translate(0) !important;
    }

    .reveal-on-scroll, .reveal-left, .reveal-right {
      opacity: 0;
      transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
      will-change: opacity, transform;
    }
    .reveal-on-scroll { transform: translateY(35px); }
    .reveal-left { transform: translateX(-40px); }
    .reveal-right { transform: translateX(40px); }

    .reveal-on-scroll.is-visible, 
    .reveal-left.is-visible, 
    .reveal-right.is-visible {
      opacity: 1 !important;
      transform: translate(0) !important;
    }
    .delay-1 { transition-delay: 0.12s; }
    .delay-2 { transition-delay: 0.24s; }
    .delay-3 { transition-delay: 0.36s; }

    .hero-section {
      position: relative;
      z-index: 1;
      padding: 5.5rem 0 4.5rem 0;
      background: 
        radial-gradient(circle at 70% 20%, rgba(15, 122, 92, 0.09) 0%, transparent 60%),
        radial-gradient(circle at 20% 80%, rgba(16, 185, 129, 0.05) 0%, transparent 50%);
    }
    .hero-container {
      display: grid;
      grid-template-columns: 1.15fr 0.85fr;
      gap: 3.5rem;
      align-items: center;
    }
    .pill-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.4rem 0.95rem;
      background: var(--primary-subtle);
      border: 1px solid rgba(15, 122, 92, 0.3);
      border-radius: var(--radius-full);
      color: var(--primary);
      font-size: 0.825rem;
      font-weight: 700;
      margin-bottom: 1.35rem;
      box-shadow: 0 2px 10px rgba(15, 122, 92, 0.08);
      transition: all var(--transition-fast);
    }
    .pill-badge:hover {
      border-color: var(--primary);
      transform: translateY(-1px);
    }
    .badge-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.3);
      animation: dotPulse 2s infinite;
    }
    @keyframes dotPulse {
      0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.6); }
      70% { box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
      100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
    }
    .hero-title {
      font-size: 3.4rem;
      font-weight: 800;
      letter-spacing: -0.03em;
      margin-bottom: 1.25rem;
      color: var(--heading);
      line-height: 1.12;
    }
    .gradient-text {
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 50%, #059669 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .hero-subtitle {
      font-size: 1.15rem;
      color: var(--text-muted);
      margin-bottom: 2.25rem;
      max-width: 600px;
      line-height: 1.65;
    }
    .hero-cta-group {
      display: flex;
      gap: 1.1rem;
      flex-wrap: wrap;
      margin-bottom: 2.75rem;
    }
    .shadow-glow {
      box-shadow: 0 10px 30px rgba(15, 122, 92, 0.35);
      position: relative;
      overflow: hidden;
      transition: all var(--transition-fast);
    }
    .shadow-glow:hover {
      box-shadow: 0 14px 38px rgba(15, 122, 92, 0.45);
      transform: translateY(-2px);
    }
    .hero-trust-row {
      display: flex;
      align-items: center;
      gap: 1.75rem;
      padding-top: 1.75rem;
      border-top: 1px solid var(--border-color);
    }
    .trust-stat {
      display: flex;
      flex-direction: column;
    }
    .stat-num {
      font-family: 'Outfit', sans-serif;
      font-size: 1.45rem;
      font-weight: 800;
      color: var(--heading);
      letter-spacing: -0.02em;
    }
    .stat-lbl {
      font-size: 0.775rem;
      color: var(--text-muted);
      font-weight: 500;
    }
    .trust-divider {
      width: 1px;
      height: 32px;
      background: var(--border-color);
    }

    /* HERO VISUAL CARD (PASSPORT SHOWCASE) */
    .passport-preview-card {
      background: var(--bg-card);
      border: 2px solid var(--primary);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-xl), 0 0 35px var(--primary-glow);
      color: var(--text-main);
      position: relative;
      transition: transform 0.5s ease, box-shadow 0.5s ease;
    }
    .passport-preview-card:hover {
      transform: translateY(-6px) scale(1.01);
      box-shadow: var(--shadow-xl), 0 12px 45px rgba(15, 122, 92, 0.25);
    }
    .card-top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.85rem;
      border-bottom: 1px dashed var(--border-color);
    }
    .card-top-bar .brand {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-weight: 800;
      font-size: 0.825rem;
      color: var(--primary);
      letter-spacing: 0.5px;
    }
    .candidate-header-mini {
      display: flex;
      align-items: center;
      gap: 1.1rem;
      margin-bottom: 1.35rem;
    }
    .mini-avatar {
      width: 58px;
      height: 58px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid var(--primary);
      box-shadow: 0 4px 12px var(--primary-glow);
    }
    .candidate-header-mini .name {
      font-size: 1.15rem;
      color: var(--heading);
      margin: 0;
      font-weight: 700;
    }
    .candidate-header-mini .track {
      font-size: 0.775rem;
      color: var(--primary);
      font-weight: 600;
      display: block;
    }
    .candidate-header-mini .centre {
      font-size: 0.725rem;
      color: var(--text-muted);
      display: block;
      margin-top: 2px;
    }
    .score-badge-circle {
      margin-left: auto;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 100%);
      color: #FFFFFF;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      flex-shrink: 0;
      box-shadow: 0 4px 14px var(--primary-glow);
    }
    .score-badge-circle .num {
      font-family: 'Outfit', sans-serif;
      font-weight: 800;
      font-size: 1.25rem;
      line-height: 1;
      display: block;
    }
    .score-badge-circle .lbl {
      font-size: 0.55rem;
      font-weight: 800;
      letter-spacing: 0.5px;
      display: block;
      line-height: 1;
      margin-top: 2px;
    }
    .skills-bars-mini {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-bottom: 1.35rem;
    }
    .bar-row {
      display: grid;
      grid-template-columns: 145px 1fr 42px;
      align-items: center;
      gap: 0.6rem;
      font-size: 0.775rem;
      font-weight: 600;
      color: var(--heading);
    }
    .bar {
      height: 7px;
      background: var(--bg-subtle);
      border-radius: 9999px;
      overflow: hidden;
      border: 1px solid var(--border-color);
    }
    .fill {
      height: 100%;
      background: linear-gradient(90deg, #0F7A5C 0%, #10B981 100%);
      border-radius: 9999px;
    }
    .recommendation-pill {
      background: var(--primary-subtle);
      border: 1px solid var(--primary-glow);
      border-radius: var(--radius-md);
      padding: 0.75rem;
      font-size: 0.775rem;
      color: var(--heading);
      margin-bottom: 1.1rem;
    }
    .invigilated-stamp {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--primary);
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }

    /* SECTION LAYOUTS & PADDINGS */
    .section-padding {
      padding: 6rem 0;
      position: relative;
      z-index: 1;
    }
    .bg-subtle {
      background-color: var(--bg-subtle);
    }
    .section-header {
      margin-bottom: 3.5rem;
    }
    .section-header h2 {
      font-size: 2.35rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      margin-top: 0.5rem;
      color: var(--heading);
    }
    .section-desc {
      color: var(--text-muted);
      font-size: 1.075rem;
      max-width: 660px;
      margin: 0.65rem auto 0 auto;
      line-height: 1.6;
    }

    /* COMPARISON CARDS */
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2.25rem;
    }
    .comp-card {
      background: var(--bg-card);
      border-radius: var(--radius-xl);
      padding: 2.5rem;
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-md);
      transition: all var(--transition-normal);
      color: var(--text-main);
    }
    .comp-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-xl);
    }
    .old-way {
      background: var(--bg-card);
      border: 1px solid rgba(239, 68, 68, 0.3);
    }
    .deservify-way {
      background: var(--bg-card);
      border: 1.5px solid #10B981;
      box-shadow: 0 10px 30px var(--primary-glow);
    }
    .card-tag {
      display: inline-block;
      font-size: 0.8rem;
      font-weight: 700;
      padding: 0.35rem 0.85rem;
      border-radius: var(--radius-full);
      margin-bottom: 1.25rem;
    }
    .red-tag { background: #FEE2E2; color: #DC2626; border: 1px solid #FCA5A5; }
    .green-tag { background: var(--primary-subtle); color: var(--primary); border: 1px solid var(--primary-glow); }
    .comp-card h3 { font-size: 1.4rem; margin-bottom: 1.35rem; font-weight: 700; color: var(--heading); }
    .comp-card ul { list-style: none; display: flex; flex-direction: column; gap: 0.95rem; }
    .comp-card li { font-size: 0.95rem; color: var(--text-main); line-height: 1.55; }

    /* STEPS FLOW GRID */
    .steps-flow-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.5rem;
    }
    .flow-step-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 1.75rem;
      position: relative;
      transition: all var(--transition-normal);
    }
    .flow-step-card:hover {
      transform: translateY(-4px);
      border-color: var(--primary-glow);
      box-shadow: var(--shadow-lg);
    }
    .step-num-badge {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      background: var(--primary-subtle);
      color: var(--primary);
      font-weight: 800;
      font-size: 1.15rem;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 1.15rem;
      border: 1px solid var(--primary-glow);
    }
    .highlight-step {
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 100%);
      color: #FFFFFF;
      box-shadow: 0 4px 12px var(--primary-glow);
    }
    .flow-step-card h3 { font-size: 1.15rem; margin-bottom: 0.5rem; font-weight: 700; color: var(--heading); }
    .flow-step-card p { font-size: 0.875rem; color: var(--text-muted); line-height: 1.55; }

    /* UNIVERSAL FRESHER SECTION */
    .fresher-box {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 3.5rem;
      align-items: center;
    }
    .fresher-content h2 { font-size: 2.3rem; margin: 0.5rem 0 1rem 0; font-weight: 800; color: var(--heading); }
    .fresher-benefits { margin-top: 1.75rem; display: flex; flex-direction: column; gap: 1.15rem; }
    .f-item { display: flex; gap: 1.1rem; }
    .f-item .icon { font-size: 1.6rem; }
    .margin-top { margin-top: 2.25rem; }

    .radar-mockup-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-lg);
      color: var(--text-main);
    }
    .radar-mockup-card h4 { font-size: 1.15rem; margin-bottom: 1.35rem; font-weight: 700; color: var(--heading); }
    .competency-bars-full { display: flex; flex-direction: column; gap: 1.1rem; margin-bottom: 1.35rem; }
    .c-row { display: grid; grid-template-columns: 175px 1fr 50px; align-items: center; gap: 0.6rem; font-size: 0.85rem; font-weight: 600; color: var(--heading); }
    .c-bar { height: 9px; background: var(--bg-subtle); border-radius: 9999px; overflow: hidden; border: 1px solid var(--border-color); }
    .c-fill { height: 100%; background: linear-gradient(90deg, #0F7A5C 0%, #10B981 100%); border-radius: 9999px; }
    .radar-footer {
      background: var(--primary-subtle);
      border: 1px solid var(--primary-glow);
      padding: 0.85rem 1rem;
      border-radius: var(--radius-md);
      font-size: 0.825rem;
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }
    .rec-highlight { font-weight: 700; color: var(--primary); }

    /* STATS BANNER */
    .stats-banner-section {
      background: #0B1120;
      color: #FFFFFF;
      padding: 4rem 0;
      position: relative;
      z-index: 1;
      border-top: 1px solid #1E293B;
      border-bottom: 1px solid #1E293B;
    }
    .stats-banner-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 2.25rem;
      text-align: center;
    }
    .stat-number {
      font-family: 'Outfit', sans-serif;
      font-size: 2.75rem;
      font-weight: 800;
      color: #34D399;
      text-shadow: 0 0 20px rgba(52, 211, 153, 0.3);
      letter-spacing: -0.02em;
    }
    .stat-text {
      font-size: 0.925rem;
      color: #94A3B8;
      margin-top: 0.4rem;
      font-weight: 500;
    }

    .container-narrow { max-width: 920px; margin: 0 auto; }

    /* FAQ ACCORDION */
    .faq-list { display: flex; flex-direction: column; gap: 1.15rem; }
    .faq-item {
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      background: var(--bg-card);
      overflow: hidden;
      transition: border-color var(--transition-fast), box-shadow var(--transition-fast);
    }
    .faq-item:hover {
      border-color: var(--primary-glow);
    }
    .faq-question {
      width: 100%;
      text-align: left;
      padding: 1.35rem 1.6rem;
      background: none;
      border: none;
      font-size: 1.075rem;
      font-weight: 700;
      color: var(--heading);
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .faq-icon {
      font-size: 1.35rem;
      font-weight: 400;
      color: var(--primary);
      transition: transform 0.3s ease;
    }
    .faq-answer {
      padding: 0 1.6rem 1.35rem 1.6rem;
      color: var(--text-muted);
      font-size: 0.95rem;
      line-height: 1.65;
      border-top: 1px dashed var(--border-color);
      padding-top: 1.1rem;
    }

    /* BOTTOM CTA SECTION */
    .bottom-cta-section {
      padding: 5.5rem 0;
      background: linear-gradient(135deg, #064E3B 0%, #0F7A5C 50%, #065F46 100%);
      color: #FFFFFF;
      position: relative;
      z-index: 1;
      overflow: hidden;
    }
    .bottom-cta-section h2 { color: #FFFFFF; font-size: 2.6rem; margin-bottom: 0.85rem; font-weight: 800; letter-spacing: -0.02em; }
    .bottom-cta-section p { font-size: 1.15rem; opacity: 0.92; margin-bottom: 2.25rem; max-width: 620px; margin-left: auto; margin-right: auto; }
    .cta-btns { display: flex; justify-content: center; gap: 1.35rem; flex-wrap: wrap; }

    /* DARK MODE SPECIFIC HOME PAGE OVERRIDES */
    [data-theme="dark"] .gradient-text,
    body.dark-theme .gradient-text {
      background: linear-gradient(135deg, #10B981 0%, #34D399 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    [data-theme="dark"] .pill-badge,
    body.dark-theme .pill-badge {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #34D399;
    }

    [data-theme="dark"] .passport-preview-card,
    body.dark-theme .passport-preview-card {
      background: #0F172A;
      border-color: #10B981;
      box-shadow: 0 0 30px rgba(16, 185, 129, 0.2);
    }

    [data-theme="dark"] .deservify-way,
    body.dark-theme .deservify-way {
      background: #0F172A;
      border-color: #10B981;
      box-shadow: 0 0 30px rgba(16, 185, 129, 0.15);
    }

    [data-theme="dark"] .old-way,
    body.dark-theme .old-way {
      background: #0F172A;
      border-color: rgba(239, 68, 68, 0.4);
    }

    [data-theme="dark"] .red-tag,
    body.dark-theme .red-tag {
      background: rgba(239, 68, 68, 0.2);
      color: #FCA5A5;
      border-color: rgba(239, 68, 68, 0.4);
    }

    [data-theme="dark"] .green-tag,
    body.dark-theme .green-tag {
      background: rgba(15, 122, 92, 0.3);
      color: #34D399;
      border-color: #10B981;
    }

    [data-theme="dark"] .recommendation-pill,
    body.dark-theme .recommendation-pill {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #F8FAFC;
    }

    [data-theme="dark"] .radar-footer,
    body.dark-theme .radar-footer {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #CBD5E1;
    }

    [data-theme="dark"] .rec-highlight,
    body.dark-theme .rec-highlight {
      color: #34D399;
    }

    @media (max-width: 950px) {
      .hero-container, .fresher-box { grid-template-columns: 1fr; }
      .comparison-grid { grid-template-columns: 1fr; }
      .steps-flow-grid { grid-template-columns: 1fr 1fr; }
      .stats-banner-grid { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 600px) {
      .steps-flow-grid { grid-template-columns: 1fr; }
      .stats-banner-grid { grid-template-columns: 1fr; }
      .hero-title { font-size: 2.35rem; }
    }
  `]
})
export class HomeComponent implements OnInit, AfterViewInit {
  authService = inject(AuthService);
  elementRef = inject(ElementRef);
  private platformId = inject(PLATFORM_ID);

  activeFaq: number | null = 0;

  ngOnInit() {
    this.authService.logout();
  }

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      requestAnimationFrame(() => {
        this.initScrollObserver();
      });
    }
  }

  private initScrollObserver() {
    if (typeof window === 'undefined') return;

    const elements = Array.from(
      this.elementRef.nativeElement.querySelectorAll(
        '.reveal-on-scroll, .reveal-left, .reveal-right'
      )
    ) as HTMLElement[];

    const revealInView = () => {
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      elements.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < windowHeight * 0.95 && rect.bottom > 0) {
          el.classList.add('is-visible');
        }
      });
    };

    revealInView();

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              observer.unobserve(entry.target);
            }
          });
        },
        { 
          threshold: 0.05,
          rootMargin: '0px 0px -20px 0px'
        }
      );

      elements.forEach((el) => {
        if (!el.classList.contains('is-visible')) {
          observer.observe(el);
        }
      });
    } else {
      elements.forEach((el) => el.classList.add('is-visible'));
    }

    setTimeout(revealInView, 100);
    setTimeout(revealInView, 300);
  }

  faqs = [
    {
      q: 'How does Proveyu prevent cheating during skill verification tests?',
      a: 'We partner with established high-stakes examination infrastructure (such as TCS iON and JEE test centres) equipped with biometric fingerprint scans, physical invigilators, CCTV logging, and air-gapped exam terminals. This completely eliminates remote cheating, proxy test takers, and AI relay assistance.'
    },
    {
      q: 'What is the Universal Fresher Competency Passport?',
      a: 'Freshers are evaluated through a single comprehensive test assessing core programming logic, scenario QA aptitude, and hands-on build track choices. The resulting Skill Passport highlights multi-dimensional role matches (e.g. Primary: QA Engineer, Secondary: Java Backend), maximizing candidate placement across multiple recruiter openings.'
    },
    {
      q: 'Do candidates pay to get verified?',
      a: 'Initial registration and slot booking at partner centres is free or offered at a nominal booking fee during pilot batches. Recruiters pay a placement commission or subscription fee to access verified candidate passports.'
    },
    {
      q: 'How do recruiters skip the online assessment phase?',
      a: 'Because candidates have already completed an in-person, invigilated practical coding and QA test, recruiters can trust the verified Skill Passport scores. Verified candidates move directly to final technical and culture interview rounds.'
    }
  ];

  toggleFaq(index: number) {
    this.activeFaq = this.activeFaq === index ? null : index;
  }
}
