import { Injectable, signal } from '@angular/core';
import { CandidateProfile, SlotBooking, AdmitCard, SkillPassport } from '../models/deservify.models';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {
  currentProfile = signal<CandidateProfile>({
    id: 'CF-CAND-9842',
    fullName: 'Rahul Sharma',
    email: 'rahul.sharma@example.com',
    phone: '+91 98765 43210',
    city: 'Bengaluru',
    college: 'RV College of Engineering',
    degree: 'B.Tech',
    stream: 'Computer Science & Engineering',
    graduationYear: 2026,
    status: 'fresher',
    selectedTrack: 'Universal Fresher Competency',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
    idProofUrl: 'govt_id_aadhaar_front_verified.pdf',
    isRegistrationComplete: true,
    testStatus: 'passport_ready',
    slotBooking: {
      bookingId: 'BK-TCS-8921',
      centerName: 'TCS iON Digital Zone iDZ Koramangala',
      centerAddress: 'Plot 42, 80 Feet Road, 4th Block, Koramangala, Bengaluru, Karnataka 560034',
      city: 'Bengaluru',
      date: '2026-09-18',
      timeSlot: '09:30 AM - 12:30 PM',
      reportingTime: '08:45 AM',
      rollNumber: 'CF2026-BLR-09842'
    },
    passport: {
      passportId: 'PASSPORT-CF-9842-VERIFIED',
      issueDate: '12 Sep 2026',
      overallScore: 92,
      tierBadge: 'Tier 1 Verified (Top 3%)',
      primaryRoleRecommendation: 'QA / Automation Engineer',
      secondaryRoleRecommendation: 'Java Backend Developer (Spring Boot)',
      verificationCenter: 'TCS iON Digital Zone Koramangala (Invigilator Code: TCS-BLR-04)',
      invigilatorVerified: true,
      practicalBuildSummary: 'Built a robust RESTful API order-processing pipeline with JUnit 5 test suite and Mockito isolation. Zero uncaught exceptions on edge cases.',
      evaluatorFeedback: [
        'Demonstrated strong practical grasp of OOP principles and custom exception handling.',
        'Wrote 14 comprehensive test cases covering boundary values and concurrency mock failures.',
        'Successfully debugged and patched a memory-leak flaw in under 18 minutes during section 3.'
      ],
      competencies: [
        {
          name: 'Core Logic & Algorithms',
          score: 95,
          status: 'Strong',
          description: 'Data structures, control flow, complexity awareness, clean code practices.'
        },
        {
          name: 'QA & Test Automation Aptitude',
          score: 94,
          status: 'Strong',
          description: 'Test scenario generation, JUnit/Selenium fundamentals, edge-case identification.'
        },
        {
          name: 'Backend Microservices (Spring Boot)',
          score: 88,
          status: 'Proficient',
          description: 'REST API design, Spring Data JPA, basic transactional boundaries.'
        },
        {
          name: 'Code Comprehension & Debugging',
          score: 91,
          status: 'Strong',
          description: 'Ability to read legacy codebases, isolate runtime errors, and refactor cleanly.'
        }
      ]
    }
  });

  // Mock Recruiter Direct Interview Requests for Candidate
  recruiterInterviews = signal<Array<{ id: string; companyName: string; role: string; date: string; package: string; status: 'pending' | 'accepted' | 'declined' }>>([
    {
      id: 'INT-01',
      companyName: 'CloudScale Technologies',
      role: 'Associate QA Automation Engineer',
      date: '15 Sep 2026, 11:00 AM',
      package: '₹8.5 - 10 LPA',
      status: 'pending'
    },
    {
      id: 'INT-02',
      companyName: 'Apex Placement Solutions (Client: FinTech Systems)',
      role: 'Java Backend Engineer (Fresher)',
      date: '17 Sep 2026, 02:30 PM',
      package: '₹9.0 LPA',
      status: 'accepted'
    }
  ]);

  bookSlot(centerName: string, date: string, timeSlot: string) {
    const booking: SlotBooking = {
      bookingId: `BK-TCS-${Math.floor(1000 + Math.random() * 9000)}`,
      centerName,
      centerAddress: `${centerName}, Tech Corridor Sector 4`,
      city: this.currentProfile().city,
      date,
      timeSlot,
      reportingTime: '08:45 AM',
      rollNumber: `CF2026-BLR-${Math.floor(10000 + Math.random() * 90000)}`
    };

    this.currentProfile.update(profile => ({
      ...profile,
      testStatus: 'slot_booked',
      slotBooking: booking
    }));
  }

  getAdmitCard(): AdmitCard {
    const profile = this.currentProfile();
    const slot = profile.slotBooking!;
    return {
      rollNumber: slot.rollNumber,
      candidateName: profile.fullName,
      email: profile.email,
      phone: profile.phone,
      centerName: slot.centerName,
      centerAddress: slot.centerAddress,
      examDate: slot.date,
      examTime: slot.timeSlot,
      reportingTime: slot.reportingTime,
      trackName: profile.selectedTrack,
      qrCodeMock: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=DESERVIFY-ROLL-${slot.rollNumber}`
    };
  }

  respondToInterview(id: string, response: 'accepted' | 'declined') {
    this.recruiterInterviews.update(list =>
      list.map(item => item.id === id ? { ...item, status: response } : item)
    );
  }
}
