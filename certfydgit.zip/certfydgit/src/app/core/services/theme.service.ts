import { Injectable, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

export type Theme = 'light' | 'dark';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private readonly THEME_KEY = 'deservify_theme';
  private platformId = inject(PLATFORM_ID);
  readonly isDarkMode = signal<boolean>(false);

  constructor() {
    this.initTheme();
  }

  private initTheme(): void {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    let initialDark = false;
    try {
      const savedTheme = localStorage.getItem(this.THEME_KEY) as Theme | null;
      if (savedTheme) {
        initialDark = savedTheme === 'dark';
      } else if (window.matchMedia) {
        initialDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      }
    } catch {
      initialDark = false;
    }

    this.isDarkMode.set(initialDark);
    this.applyThemeToDOM(initialDark ? 'dark' : 'light');
  }

  toggleTheme(event?: MouseEvent): void {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    const newDarkState = !this.isDarkMode();

    // Trigger circular radial sweep animation if click event provided
    if (event) {
      this.animateThemeSwitch(event, newDarkState);
    } else {
      this.applyTheme(newDarkState);
    }
  }

  private applyTheme(isDark: boolean): void {
    this.isDarkMode.set(isDark);
    const themeName: Theme = isDark ? 'dark' : 'light';

    if (isPlatformBrowser(this.platformId)) {
      try {
        localStorage.setItem(this.THEME_KEY, themeName);
      } catch {
        // Ignore quota/private browsing errors
      }
      this.applyThemeToDOM(themeName);
    }
  }

  private applyThemeToDOM(theme: Theme): void {
    if (typeof document === 'undefined') return;

    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
      document.body.classList.add('dark-theme');
    } else {
      document.documentElement.removeAttribute('data-theme');
      document.body.classList.remove('dark-theme');
    }
  }

  private animateThemeSwitch(event: MouseEvent, newDarkState: boolean): void {
    if (typeof document === 'undefined' || typeof window === 'undefined') {
      this.applyTheme(newDarkState);
      return;
    }

    const x = event.clientX;
    const y = event.clientY;

    // Calculate maximum radius to cover the entire screen from click location
    const endRadius = Math.hypot(
      Math.max(x, window.innerWidth - x),
      Math.max(y, window.innerHeight - y)
    );

    // Create dynamic overlay element for radial sweep
    const overlay = document.createElement('div');
    overlay.className = 'theme-transition-sweep';

    // Style overlay to match upcoming background color
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.pointerEvents = 'none';
    overlay.style.zIndex = '99999';
    overlay.style.backgroundColor = newDarkState ? '#0B1120' : '#F8FAFC';
    overlay.style.clipPath = `circle(0px at ${x}px ${y}px)`;
    overlay.style.transition = 'clip-path 0.55s cubic-bezier(0.4, 0, 0.2, 1)';

    document.body.appendChild(overlay);

    // Force reflow
    void overlay.offsetWidth;

    // Expand circle
    overlay.style.clipPath = `circle(${endRadius}px at ${x}px ${y}px)`;

    // Apply theme state halfway into animation for seamless feel
    setTimeout(() => {
      this.applyTheme(newDarkState);
    }, 200);

    // Cleanup overlay
    setTimeout(() => {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }, 600);
  }
}
