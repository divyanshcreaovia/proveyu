import { Injectable, signal, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { UserRole } from '../models/deservify.models';

const STORAGE_KEY = 'deservify_auth_session';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private platformId = inject(PLATFORM_ID);
  private router = inject(Router);

  currentRole = signal<UserRole | null>(null);
  userEmail = signal<string>('');
  userName = signal<string>('');
  isLoggedIn = signal<boolean>(false);

  constructor() {
    this.initSession();

    if (isPlatformBrowser(this.platformId)) {
      this.router.events.pipe(
        filter((event): event is NavigationEnd => event instanceof NavigationEnd)
      ).subscribe((event: NavigationEnd) => {
        this.checkRouteAndSyncSession(event.urlAfterRedirects || event.url);
      });
    }
  }

  private initSession() {
    if (!isPlatformBrowser(this.platformId)) return;

    let restored = false;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.isLoggedIn && parsed.currentRole) {
          this.currentRole.set(parsed.currentRole);
          this.userName.set(parsed.userName || this.getDefaultNameForRole(parsed.currentRole));
          this.userEmail.set(parsed.userEmail || this.getDefaultEmailForRole(parsed.currentRole));
          this.isLoggedIn.set(true);
          restored = true;
        }
      }
    } catch (e) {
      console.warn('Could not restore auth session from localStorage:', e);
    }

    if (!restored) {
      const currentPath = window.location.pathname;
      this.checkRouteAndSyncSession(currentPath);
    }
  }

  private checkRouteAndSyncSession(path: string) {
    const cleanPath = (path || '').split('?')[0].split('#')[0];
    if (cleanPath === '/' || cleanPath === '') {
      this.logout();
      return;
    }
    if (cleanPath.includes('/register') || cleanPath.includes('/login') || cleanPath.includes('/select-role')) {
      return;
    }
    if (cleanPath.includes('/candidate') || cleanPath.includes('/dashboard/candidate')) {
      if (!this.isLoggedIn() || this.currentRole() !== 'candidate') {
        this.setRole('candidate');
      }
    } else if (cleanPath.includes('/recruiter') || cleanPath.includes('/dashboard/recruiter')) {
      if (!this.isLoggedIn() || !this.currentRole()?.startsWith('recruiter')) {
        this.setRole('recruiter_company');
      }
    }
  }

  private getDefaultNameForRole(role: UserRole): string {
    switch (role) {
      case 'candidate': return 'Rahul Sharma';
      case 'recruiter_agency': return 'Vikram Malhotra';
      case 'recruiter_startup': return 'Ananya Roy';
      case 'recruiter_company': default: return 'Siddharth Mehta';
    }
  }

  private getDefaultEmailForRole(role: UserRole): string {
    switch (role) {
      case 'candidate': return 'rahul.sharma@example.com';
      case 'recruiter_agency': return 'vikram@apexplacements.com';
      case 'recruiter_startup': return 'ananya@cloudscale.io';
      case 'recruiter_company': default: return 'siddharth.m@infosystems.com';
    }
  }

  private persistSession() {
    if (!isPlatformBrowser(this.platformId)) return;

    if (this.isLoggedIn()) {
      const data = {
        currentRole: this.currentRole(),
        userName: this.userName(),
        userEmail: this.userEmail(),
        isLoggedIn: true
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  setRole(role: UserRole) {
    this.currentRole.set(role);
    this.userName.set(this.getDefaultNameForRole(role));
    this.userEmail.set(this.getDefaultEmailForRole(role));
    this.isLoggedIn.set(true);
    this.persistSession();
  }

  login(email: string, role: UserRole) {
    this.setRole(role);
    if (email) {
      this.userEmail.set(email);
    }
    this.isLoggedIn.set(true);
    this.persistSession();
  }

  logout() {
    this.isLoggedIn.set(false);
    this.currentRole.set(null);
    this.userName.set('');
    this.userEmail.set('');
    this.persistSession();
  }
}
