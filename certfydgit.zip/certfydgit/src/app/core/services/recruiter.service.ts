import { Injectable, signal } from '@angular/core';
import { PipelineCandidate, JobRequirement, AgencyClient, RecruiterProfile } from '../models/deservify.models';

@Injectable({
  providedIn: 'root'
})
export class RecruiterService {
  recruiterProfile = signal<RecruiterProfile>({
    id: 'REC-ORG-4819',
    orgType: 'agency',
    orgName: 'Apex Placement Solutions',
    website: 'https://apexplacements.example.com',
    industry: 'Technology & IT Recruitment',
    companySize: '50-100 Employees',
    contactName: 'Vikram Malhotra',
    contactRole: 'Lead Placement Director',
    email: 'vikram@apexplacements.com',
    phone: '+91 98112 34567',
    agencyLicense: 'LIC-KA-2024-8849',
    hiringDomains: ['Java Backend', 'QA & Testing', 'Universal Fresher'],
    monthlyVolume: '25-50 Candidates',
    experienceFocus: 'both',
    unlockedCredits: 12
  });

  candidatesCatalog = signal<PipelineCandidate[]>([
    {
      candidateId: 'CF-9842',
      maskedName: 'Candidate #CF-9842',
      photoAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      track: 'Universal Fresher Competency',
      overallScore: 92,
      tierBadge: 'Tier 1 Verified (Top 3%)',
      experienceLevel: 'Fresher (2026)',
      college: 'RV College of Engineering',
      location: 'Bengaluru',
      stage: 'interviewing',
      unlocked: true,
      realName: 'Rahul Sharma',
      realEmail: 'rahul.sharma@example.com',
      realPhone: '+91 98765 43210',
      targetClient: 'FinTech Systems Pvt Ltd'
    },
    {
      candidateId: 'CF-7412',
      maskedName: 'Candidate #CF-7412',
      photoAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      track: 'Java Backend (Spring Boot)',
      overallScore: 89,
      tierBadge: 'Tier 1 Verified (Top 5%)',
      experienceLevel: '1-3 Yrs Exp',
      college: 'BMS College of Engineering',
      location: 'Bengaluru',
      stage: 'shortlisted',
      unlocked: false,
      targetClient: 'CloudScale Technologies'
    },
    {
      candidateId: 'CF-6190',
      maskedName: 'Candidate #CF-6190',
      photoAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
      track: 'QA & Automation Testing',
      overallScore: 95,
      tierBadge: 'Tier 1 Verified (Top 1%)',
      experienceLevel: 'Fresher (2026)',
      college: 'PES University',
      location: 'Hyderabad',
      stage: 'offered',
      unlocked: true,
      realName: 'Priya Nambiar',
      realEmail: 'priya.n@example.com',
      realPhone: '+91 98451 12345',
      targetClient: 'NextGen Retail'
    },
    {
      candidateId: 'CF-8820',
      maskedName: 'Candidate #CF-8820',
      photoAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      track: 'Python Backend & Data',
      overallScore: 86,
      tierBadge: 'Tier 2 Verified (Top 10%)',
      experienceLevel: 'Fresher (2025)',
      college: 'IIT Kanpur',
      location: 'Delhi NCR',
      stage: 'hired',
      unlocked: true,
      realName: 'Amitav Ghosh',
      realEmail: 'amitav.g@example.com',
      realPhone: '+91 99100 88776',
      targetClient: 'DataSprint Labs'
    },
    {
      candidateId: 'CF-3301',
      maskedName: 'Candidate #CF-3301',
      photoAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
      track: 'Web Development (Full Stack)',
      overallScore: 88,
      tierBadge: 'Tier 1 Verified (Top 6%)',
      experienceLevel: '2 Yrs Exp',
      college: 'Manipal Institute of Tech',
      location: 'Pune',
      stage: 'shortlisted',
      unlocked: false
    }
  ]);

  jobRequirements = signal<JobRequirement[]>([
    {
      id: 'REQ-01',
      title: 'Associate QA Automation Engineer',
      domain: 'QA & Testing',
      experienceLevel: 'Fresher / 0-1 Yrs',
      minScore: 85,
      location: 'Bengaluru / Remote',
      salaryRange: '₹8 - 10 LPA',
      clientCompany: 'CloudScale Technologies',
      active: true,
      applicantsCount: 14
    },
    {
      id: 'REQ-02',
      title: 'Java Microservices Backend Developer',
      domain: 'Java Backend',
      experienceLevel: '1-3 Yrs',
      minScore: 88,
      location: 'Hyderabad',
      salaryRange: '₹12 - 16 LPA',
      clientCompany: 'FinTech Systems Pvt Ltd',
      active: true,
      applicantsCount: 9
    }
  ]);

  agencyClients = signal<AgencyClient[]>([
    {
      id: 'CLI-01',
      clientName: 'FinTech Systems Pvt Ltd',
      industry: 'Banking & Financial Software',
      activeOpenings: 6,
      placedCandidates: 14,
      commissionRate: '12% of CTC',
      contactPerson: 'Sandeep Varma (VP HR)'
    },
    {
      id: 'CLI-02',
      clientName: 'CloudScale Technologies',
      industry: 'Cloud Infrastructure SaaS',
      activeOpenings: 4,
      placedCandidates: 8,
      commissionRate: '10% of CTC',
      contactPerson: 'Ritu Kapoor (Talent Lead)'
    },
    {
      id: 'CLI-03',
      clientName: 'NextGen Retail Solutions',
      industry: 'E-Commerce Tech',
      activeOpenings: 8,
      placedCandidates: 19,
      commissionRate: '15% of CTC',
      contactPerson: 'Arun Dev (Director Operations)'
    }
  ]);

  unlockCandidate(candidateId: string) {
    const profile = this.recruiterProfile();
    if (profile.unlockedCredits <= 0) return false;

    this.recruiterProfile.update(p => ({
      ...p,
      unlockedCredits: p.unlockedCredits - 1
    }));

    this.candidatesCatalog.update(list =>
      list.map(c => {
        if (c.candidateId === candidateId) {
          return {
            ...c,
            unlocked: true,
            unlockedAt: new Date().toLocaleDateString(),
            realName: c.realName || `Verified Candidate (${c.candidateId})`,
            realEmail: c.realEmail || `candidate.${c.candidateId.toLowerCase()}@verified-deservify.org`,
            realPhone: c.realPhone || '+91 98000 12345'
          };
        }
        return c;
      })
    );
    return true;
  }

  updateStage(candidateId: string, newStage: PipelineCandidate['stage']) {
    this.candidatesCatalog.update(list =>
      list.map(c => c.candidateId === candidateId ? { ...c, stage: newStage } : c)
    );
  }

  addRequirement(req: Omit<JobRequirement, 'id' | 'applicantsCount' | 'active'>) {
    const newReq: JobRequirement = {
      ...req,
      id: `REQ-0${this.jobRequirements().length + 1}`,
      applicantsCount: 0,
      active: true
    };
    this.jobRequirements.update(list => [newReq, ...list]);
  }
}
