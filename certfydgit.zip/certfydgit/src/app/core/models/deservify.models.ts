export type UserRole = 'candidate' | 'recruiter_startup' | 'recruiter_agency' | 'recruiter_company';

export interface CandidateProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  city: string;
  college: string;
  degree: string;
  stream: string;
  graduationYear: number;
  status: 'student' | 'fresher' | 'experienced';
  selectedTrack: string;
  photoUrl?: string;
  idProofUrl?: string;
  isRegistrationComplete: boolean;
  testStatus: 'pending_slot' | 'slot_booked' | 'test_completed' | 'passport_ready';
  slotBooking?: SlotBooking;
  passport?: SkillPassport;
}

export interface SlotBooking {
  bookingId: string;
  centerName: string;
  centerAddress: string;
  city: string;
  date: string;
  timeSlot: string;
  reportingTime: string;
  rollNumber: string;
}

export interface AdmitCard {
  rollNumber: string;
  candidateName: string;
  email: string;
  phone: string;
  centerName: string;
  centerAddress: string;
  examDate: string;
  examTime: string;
  reportingTime: string;
  trackName: string;
  qrCodeMock: string;
}

export interface CompetencyScore {
  name: string;
  score: number; // 0-100
  description: string;
  status: 'Strong' | 'Proficient' | 'Developing';
}

export interface SkillPassport {
  passportId: string;
  issueDate: string;
  overallScore: number; // 0-100
  tierBadge: string; // e.g. "Tier 1 Verified (Top 5%)"
  primaryRoleRecommendation: string;
  secondaryRoleRecommendation: string;
  competencies: CompetencyScore[];
  practicalBuildSummary: string;
  evaluatorFeedback: string[];
  verificationCenter: string;
  invigilatorVerified: boolean;
}

export interface RecruiterProfile {
  id: string;
  orgType: 'startup' | 'agency' | 'company';
  orgName: string;
  website: string;
  industry: string;
  companySize: string;
  contactName: string;
  contactRole: string;
  email: string;
  phone: string;
  gstOrCin?: string;
  agencyLicense?: string;
  hiringDomains: string[];
  monthlyVolume: string;
  experienceFocus: 'fresher' | 'experienced' | 'both';
  unlockedCredits: number;
}

export interface JobRequirement {
  id: string;
  title: string;
  domain: string;
  experienceLevel: string;
  minScore: number;
  location: string;
  salaryRange: string;
  clientCompany?: string; // For placement agencies
  active: boolean;
  applicantsCount: number;
}

export interface PipelineCandidate {
  candidateId: string;
  maskedName: string;
  photoAvatar: string;
  track: string;
  overallScore: number;
  tierBadge: string;
  experienceLevel: string;
  college: string;
  location: string;
  stage: 'shortlisted' | 'interviewing' | 'offered' | 'hired' | 'rejected';
  unlocked: boolean;
  unlockedAt?: string;
  realName?: string;
  realEmail?: string;
  realPhone?: string;
  targetClient?: string; // Agency client mapping
}

export interface AgencyClient {
  id: string;
  clientName: string;
  industry: string;
  activeOpenings: number;
  placedCandidates: number;
  commissionRate: string;
  contactPerson: string;
}
