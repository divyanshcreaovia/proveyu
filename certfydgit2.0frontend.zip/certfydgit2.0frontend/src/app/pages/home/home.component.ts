import { Component, inject, OnInit, AfterViewInit, ElementRef, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <!-- AMBIENT FLOATING MESH BACKGROUND -->
    <div class="ambient-glow-wrapper">
      <div class="glow-orb orb-1"></div>
      <div class="glow-orb orb-2"></div>
      <div class="glow-orb orb-3"></div>
    </div>

    <!-- HERO SECTION -->
    <section class="hero-section">
      <div class="container hero-container">
        <div class="hero-text-col reveal-on-scroll">
       
          <h1 class="hero-title">
            Proof Over Resumes.<br>
            <span class="gradient-text">Hire on Proven Ability.</span>
          </h1>

          <p class="hero-subtitle">
            Proveyu replaces unverified resume claims with invigilated, in-person skill assessments at partner exam centres. Candidates get a multi-dimensional Skill Passport; recruiters get un-cheatable merit signal.
          </p>

          <!-- Dual Primary CTAs (Dynamically updated based on Auth State) -->
          <div class="hero-cta-group" *ngIf="!authService.isLoggedIn(); else heroAuthCtas">
            <a routerLink="/register/candidate" class="btn btn-lg btn-primary shadow-glow">
              <span>I'm a Candidate — Get Verified</span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
            <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
              <span>I'm Hiring — Access Verified Talent</span>
            </a>
          </div>

          <ng-template #heroAuthCtas>
            <div class="hero-cta-group">
              <ng-container *ngIf="authService.currentRole() === 'candidate'">
                <a routerLink="/dashboard/candidate" class="btn btn-lg btn-primary shadow-glow">
                  <span>Go to Candidate Dashboard</span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
                <a routerLink="/candidate/passport" class="btn btn-lg btn-secondary">
                  <span>View My Skill Passport</span>
                </a>
              </ng-container>

              <ng-container *ngIf="authService.currentRole() !== 'candidate'">
                <a routerLink="/dashboard/recruiter" class="btn btn-lg btn-primary shadow-glow">
                  <span>Go to Recruiter Dashboard</span>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
                <a routerLink="/recruiter/verifiedtalents" class="btn btn-lg btn-secondary">
                  <span>Search Verified Candidates</span>
                </a>
              </ng-container>
            </div>
          </ng-template>

          <div class="hero-trust-row">
            <div class="trust-stat">
              <span class="stat-num">100%</span>
              <span class="stat-lbl">In-Person Supervision</span>
            </div>
            <div class="trust-divider"></div>
            <div class="trust-stat">
              <span class="stat-num">Air-Gapped</span>
              <span class="stat-lbl">Terminal Lockdown</span>
            </div>
            <div class="trust-divider"></div>
            <div class="trust-stat">
              <span class="stat-num">0%</span>
              <span class="stat-lbl">Proxy Cheating Vulnerability</span>
            </div>
          </div>
        </div>

        <!-- Hero Mockup Card -->
        <div class="hero-visual-col reveal-on-scroll delay-1">
          <div class="passport-preview-card float-animation">
            <div class="card-top-bar">
              <div class="brand">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                <span>PROVEYU SKILL PASSPORT</span>
              </div>
              <span class="badge badge-gold">Top 3% Verified</span>
            </div>

            <div class="candidate-header-mini">
              <div class="mini-avatar-initials">RS</div>
              <div>
                <h3 class="name">Rahul Sharma</h3>
                <span class="track">Universal Fresher Competency</span>
                <span class="centre">TCS iON Center, Koramangala</span>
              </div>
              <div class="score-badge-circle">
                <span class="num">92</span>
                <span class="lbl">SCORE</span>
              </div>
            </div>

            <div class="skills-bars-mini">
              <div class="bar-row">
                <span>Core Logic & Algorithms</span>
                <div class="bar"><div class="fill" style="width: 95%"></div></div>
                <span class="pts">95%</span>
              </div>
              <div class="bar-row">
                <span>QA & Test Automation</span>
                <div class="bar"><div class="fill" style="width: 94%"></div></div>
                <span class="pts">94%</span>
              </div>
              <div class="bar-row">
                <span>Java Backend Development</span>
                <div class="bar"><div class="fill" style="width: 88%"></div></div>
                <span class="pts">88%</span>
              </div>
            </div>

            <div class="recommendation-pill">
              <span><strong>Primary Fit:</strong> QA / Automation Engineer | <strong>Secondary:</strong> Java Microservices</span>
            </div>

            <div class="invigilated-stamp">
              <span class="stamp-icon">✓</span>
              <span>Invigilator Supervision Log #TCS-BLR-04 Confirmed</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 2: VISUAL PLATFORM ARCHITECTURE & WORKFLOW SHOWCASE -->
    <section class="section-padding bg-subtle" id="architecture-showcase">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Platform Architecture</span>
          <h2>How Proveyu Eliminates Hiring Risk</h2>
          <p class="section-desc">
            Designed for high-stakes pre-employment verification. Built on physical invigilation, lockdown browser terminals, and multi-dimensional skill evaluation.
          </p>
        </div>

        <!-- 3 Executive Architecture Cards -->
        <div class="architecture-grid reveal-on-scroll">
          
          <!-- Card 1: Physical Check-In & Identity Audit -->
          <div class="arch-card deservify-card">
            <h3>Biometric & Physical Check-In</h3>
            <p>Government ID verification and biometric authentication at authorized physical exam hubs before entering the testing terminal.</p>
            
            <div class="arch-visual-box">
              <div class="arch-visual-front">
                <div class="ui-mock-header">
                  <span class="dot red"></span><span class="dot yellow"></span><span class="dot green"></span>
                  <span class="ui-title">VERIFY_GATEWAY_V1.2</span>
                </div>
                <div class="ui-mock-body">
                  <div class="step-status-row">
                    <span class="lbl">Government ID Audit:</span>
                    <span class="val green">CONFIRMED ✓</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">Biometric Hash:</span>
                    <span class="val blue">MATCHED (0.002s)</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">Invigilator Station:</span>
                    <span class="val">LAB_AUTH_GATE_04</span>
                  </div>
                </div>
              </div>
              <div class="arch-visual-back">
                <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=600" alt="Identity Verification">
                <div class="visual-back-badge">Stage 1 Photo Audit</div>
              </div>
            </div>
          </div>

          <!-- Card 2: Air-Gapped Terminal Environment -->
          <div class="arch-card deservify-card">
            <h3>Air-Gapped Assessment Terminals</h3>
            <p>Strict browser lockdown environments that block screen relays, secondary monitors, unauthorized shortcuts, or external AI assistants.</p>
            
            <div class="arch-visual-box">
              <div class="arch-visual-front">
                <div class="ui-mock-header">
                  <span class="dot red"></span><span class="dot yellow"></span><span class="dot green"></span>
                  <span class="ui-title">LOCKDOWN_ENGINE</span>
                </div>
                <div class="ui-mock-body">
                  <div class="step-status-row">
                    <span class="lbl">External Input Devices:</span>
                    <span class="val green">BLOCKED (0 Detected)</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">Screen Relay / HDMI:</span>
                    <span class="val green">ISOLATED ✓</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">Live Proctor Supervision:</span>
                    <span class="val gold">ACTIVE LOG #774</span>
                  </div>
                </div>
              </div>
              <div class="arch-visual-back">
                <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=600" alt="Assessment Lab Terminal">
                <div class="visual-back-badge">Stage 2 Terminal Hub</div>
              </div>
            </div>
          </div>

          <!-- Card 3: Skill Passport Generation -->
          <div class="arch-card deservify-card">
            <h3>Tamper-Proof Skill Passport</h3>
            <p>Multi-dimensional scoring engine generating verifiable skill metrics across core logic, QA testing, and backend engineering capabilities.</p>
            
            <div class="arch-visual-box">
              <div class="arch-visual-front">
                <div class="ui-mock-header">
                  <span class="dot red"></span><span class="dot yellow"></span><span class="dot green"></span>
                  <span class="ui-title">PASSPORT_GENERATOR</span>
                </div>
                <div class="ui-mock-body">
                  <div class="step-status-row">
                    <span class="lbl">Core Problem Solving:</span>
                    <span class="val green">95% (Evaluated)</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">QA & Automation:</span>
                    <span class="val green">94% (Evaluated)</span>
                  </div>
                  <div class="step-status-row">
                    <span class="lbl">Audit Hash Signature:</span>
                    <span class="val blue">0x89F4...2E01</span>
                  </div>
                </div>
              </div>
              <div class="arch-visual-back">
                <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=600" alt="Skill Passport Analytics">
                <div class="visual-back-badge">Stage 3 Skill Matrix</div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- PROBLEM VS SOLUTION COMPARISON: EXECUTIVE DIAGNOSTIC GRID -->
    <section class="section-padding bg-white-section" id="value-props">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Diagnostic Analysis</span>
          <h2>Why Online Assessments Fail & Physical Verification Wins</h2>
          <p class="section-desc">
            Online proctoring software only monitors camera feeds. It cannot detect screen relays, secondary keyboards, or live AI helpers. In-person invigilation provides un-cheatable merit signal.
          </p>
        </div>

        <!-- Diagnostic Executive Summary Strip -->
        <div class="diag-summary-strip reveal-on-scroll">
          <div class="diag-summary-item red-alert">
            <span class="d-metric">60%</span>
            <span class="d-text">Resume Claim Inflation</span>
          </div>
          <div class="diag-summary-divider"></div>
          <div class="diag-summary-item green-verified">
            <span class="d-metric">0%</span>
            <span class="d-text">Remote Proxy Risk</span>
          </div>
          <div class="diag-summary-divider"></div>
          <div class="diag-summary-item blue-info">
            <span class="d-metric">15+ Hrs</span>
            <span class="d-text">Tech Bandwidth Saved</span>
          </div>
        </div>

        <div class="comparison-grid">
          <!-- Left Panel: Broken Remote Model -->
          <div class="comp-card old-way reveal-left">
            <h3>Broken & Easy to Cheat</h3>
            <p class="comp-card-sub">Remote online proctoring creates a false sense of security while letting high-scoring proxies bypass evaluation.</p>

            <div class="comp-feature-stack">
              <div class="comp-feature-row">
                <div>
                  <h4>Resume Inflation & Overstated Claims</h4>
                  <p>Up to 60% of resumes contain exaggerated project experience, forcing hiring teams to waste time on unqualified candidates.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>Remote Proxy Test-Takers & AI Assistance</h4>
                  <p>Webcam algorithms miss secondary monitors, HDMI relays, under-desk keyboards, and live AI coding helpers.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>College Brand & Referral Gatekeeping</h4>
                  <p>ATS filters auto-reject deserving candidates from tier-2/3 colleges before anyone evaluates their actual coding ability.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>15+ Engineering Hours Wasted Per Opening</h4>
                  <p>Senior devs spend hours conducting technical interviews for candidates who look great on paper but fail basic coding tasks.</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Right Panel: Deservify Supervised Standard -->
          <div class="comp-card deservify-way reveal-right">
            <h3>Verified, Un-Cheatable Skill Proof</h3>
            <p class="comp-card-sub">In-person invigilation at official exam centers provides cryptographic, un-cheatable merit signals.</p>

            <div class="comp-feature-stack">
              <div class="comp-feature-row">
                <div>
                  <h4>Physical Exam Lab Invigilation</h4>
                  <p>Supervised at existing high-stakes exam infrastructure (TCS iON / JEE test hubs) with photo ID scans, biometric checks, and CCTV control.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>Multi-Dimensional Skill Passport</h4>
                  <p>Comprehensive competency breakdown across logic, scenario QA, Spring Boot backend, and hands-on debugging.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>Equal Merit Access for All Colleges</h4>
                  <p>Talent is recognized purely on execution ability—bypassing tier-3 college brand bias and referral gatekeeping completely.</p>
                </div>
              </div>

              <div class="comp-feature-row">
                <div>
                  <h4>Direct Tech Interview Shortcut</h4>
                  <p>Verified candidates bypass preliminary online screening tests completely and proceed directly to final technical rounds.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- HOW IT WORKS: CONNECTED PIPELINE FLOW -->
    <section class="section-padding bg-subtle" id="how-it-works">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Seamless Pipeline</span>
          <h2>How Proveyu Works for Candidates & Recruiters</h2>
          <p class="section-desc">From registration to direct interview in 4 connected, invigilated steps.</p>
        </div>

        <!-- Connected Horizontal Pipeline Component -->
        <div class="pipeline-container reveal-on-scroll">
          
          <!-- Step 1 -->
          <div class="pipeline-step-col">
            <div class="pipeline-header-node">
              <span class="pipeline-tag badge-teal">Step 01</span>
              <div class="pipeline-connector">
                <span class="connector-line"></span>
                <span class="connector-arrow">➔</span>
              </div>
            </div>
            <div class="pipeline-card deservify-card">
              <h3>Register & Pick Track</h3>
              <p>Select your domain (Java, QA, Python, Web) or opt for the <strong>Universal Fresher Competency</strong> test track.</p>
            </div>
          </div>

          <!-- Step 2 -->
          <div class="pipeline-step-col">
            <div class="pipeline-header-node">
              <span class="pipeline-tag badge-teal">Step 02</span>
              <div class="pipeline-connector">
                <span class="connector-line"></span>
                <span class="connector-arrow">➔</span>
              </div>
            </div>
            <div class="pipeline-card deservify-card">
              <h3>Book In-Person Centre</h3>
              <p>Pick a date and partner exam centre (TCS iON / JEE labs) near your city. Receive your official Admit Card with QR code.</p>
            </div>
          </div>

          <!-- Step 3 -->
          <div class="pipeline-step-col">
            <div class="pipeline-header-node">
              <span class="pipeline-tag badge-teal">Step 03</span>
              <div class="pipeline-connector">
                <span class="connector-line"></span>
                <span class="connector-arrow">➔</span>
              </div>
            </div>
            <div class="pipeline-card deservify-card">
              <h3>Invigilated Assessment</h3>
              <p>Attempt practical, scenario-based coding tasks supervised by human invigilators and evaluated by domain experts.</p>
            </div>
          </div>

          <!-- Step 4 -->
          <div class="pipeline-step-col">
            <div class="pipeline-header-node">
              <span class="pipeline-tag badge-gold">Step 04</span>
            </div>
            <div class="pipeline-card deservify-card highlight-pipeline-card">
              <h3>Receive Passport & Get Hired</h3>
              <p>Your multi-dimensional Proveyu Skill Passport is generated. Recruiters browse and send direct interview invites with zero screening.</p>
            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- UNIVERSAL FRESHER COMPETENCY MODEL -->
    <section class="section-padding bg-white-section" id="universal-fresher">
      <div class="container">
        <div class="fresher-box">
          <div class="fresher-content reveal-left">
            <span class="badge badge-gold">Game Changer for Freshers</span>
            <h2>The Universal Fresher Competency Passport</h2>
            <p>
              Freshers don't come pre-specialized. Companies hire freshers and allocate them into roles (Backend, QA, Frontend) based on aptitude. Proveyu's Universal Fresher Test evaluates core logic, problem-solving, and hands-on build choices to recommend exact role alignment.
            </p>

            <div class="fresher-benefits">
              <div class="f-item">
                <div>
                  <h4>One Test, Multiple Opportunities</h4>
                  <p>Candidates aren't pigeonholed into a single role. A single test opens doors for QA, Backend, and Full Stack positions.</p>
                </div>
              </div>
              <div class="f-item">
                <div>
                  <h4>Evidence-Based Placement for Agencies & Recruiters</h4>
                  <p>Agencies get a multi-faceted inventory of pre-verified freshers ready for client mapping with zero guess-work.</p>
                </div>
              </div>
            </div>

            <ng-container *ngIf="!authService.isLoggedIn()">
              <a routerLink="/register/candidate" class="btn btn-primary btn-lg margin-top">
                Register for Universal Fresher Verification →
              </a>
            </ng-container>

            <ng-container *ngIf="authService.isLoggedIn() && authService.currentRole() === 'candidate'">
              <a routerLink="/candidate/book-slot" class="btn btn-primary btn-lg margin-top">
                Book Exam Slot for Fresher Verification →
              </a>
            </ng-container>

            <ng-container *ngIf="authService.isLoggedIn() && authService.currentRole() !== 'candidate'">
              <a routerLink="/recruiter/verifiedtalents" class="btn btn-primary btn-lg margin-top">
                Browse Verified Fresher Candidates →
              </a>
            </ng-container>
          </div>

          <div class="fresher-graphic reveal-right">
            <div class="radar-mockup-card">
              <h4>Multi-Dimensional Competency Radar</h4>
              <div class="competency-bars-full">
                <div class="c-row">
                  <span class="c-label">Core Logic & Control Flow</span>
                  <div class="c-bar"><div class="c-fill" style="width: 95%;"></div></div>
                  <span class="c-score">95/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">QA & Scenario Testing</span>
                  <div class="c-bar"><div class="c-fill" style="width: 92%;"></div></div>
                  <span class="c-score">92/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">Backend Spring Boot</span>
                  <div class="c-bar"><div class="c-fill" style="width: 88%;"></div></div>
                  <span class="c-score">88/100</span>
                </div>
                <div class="c-row">
                  <span class="c-label">Debugging & Comprehension</span>
                  <div class="c-bar"><div class="c-fill" style="width: 90%;"></div></div>
                  <span class="c-score">90/100</span>
                </div>
              </div>
              <div class="radar-footer">
                <span>Ranked Placement Recommendation:</span>
                <span class="rec-highlight">1st: QA Engineer | 2nd: Java Developer</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- PLACED STUDENTS & TESTIMONIALS SECTION -->
    <section class="section-padding bg-subtle" id="testimonials">
      <div class="container">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-gold">Verified Student Placements</span>
          <h2>Real Proof, Real Careers: Placed Student Reviews</h2>
          <p class="section-desc">
            Discover how candidates from tier-1, tier-2, and tier-3 colleges unlocked high-growth tech careers based purely on verified skill proof.
          </p>
        </div>

        <!-- Metric Highlights Strip -->
        <div class="placement-stats-strip reveal-on-scroll">
          <div class="p-stat-box">
            <span class="p-num">94%</span>
            <span class="p-lbl">Placement Success Rate</span>
          </div>
          <div class="p-stat-divider"></div>
          <div class="p-stat-box">
            <span class="p-num">₹8.5 LPA</span>
            <span class="p-lbl">Average Package Offered</span>
          </div>
          <div class="p-stat-divider"></div>
          <div class="p-stat-box">
            <span class="p-num">180+</span>
            <span class="p-lbl">Hiring Enterprise Partners</span>
          </div>
          <div class="p-stat-divider"></div>
          <div class="p-stat-box">
            <span class="p-num">&lt; 7 Days</span>
            <span class="p-lbl">Avg Time from Exam to Offer</span>
          </div>
        </div>

        <!-- Toggle Tabs: Placed Students / Recruiter Feedback -->
        <div class="testimonial-toggle-bar reveal-on-scroll">
          <button 
            class="t-toggle-btn" 
            [class.active]="activeTestimonialTab === 'students'"
            (click)="activeTestimonialTab = 'students'">
            Placed Student Reviews ({{ placedStudents.length }})
          </button>
          <button 
            class="t-toggle-btn" 
            [class.active]="activeTestimonialTab === 'recruiters'"
            (click)="activeTestimonialTab = 'recruiters'">
            Recruiter & Hiring Manager Reviews ({{ recruiterTestimonials.length }})
          </button>
        </div>

        <!-- Student Testimonials Grid -->
        <div class="testimonials-grid" *ngIf="activeTestimonialTab === 'students'">
          <div *ngFor="let s of placedStudents" class="testimonial-card student-card">
            <!-- Card Header: Image Avatar, Name, College, Score -->
            <div class="t-card-top">
              <img [src]="s.avatar" [alt]="s.name" class="t-avatar-img">
              <div class="t-user-info">
                <h3 class="t-name">{{ s.name }}</h3>
                <span class="t-college">{{ s.college }}</span>
              </div>
              <div class="t-score-box">
                <span class="t-score-val">{{ s.score }}</span>
                <span class="t-score-lbl">Score</span>
              </div>
            </div>

            <!-- Placements Highlight Tag: Company & Package -->
            <div class="t-placement-banner">
              <div class="t-placement-info">
                <span class="t-placed-at">Placed at <strong>{{ s.company }}</strong></span>
                <span class="t-role-text">• {{ s.role }}</span>
              </div>
              <span class="t-package-badge">{{ s.package }}</span>
            </div>

            <!-- Quote Review -->
            <div class="t-quote-body">
              <div class="t-stars">
                <svg *ngFor="let star of [1,2,3,4,5]" width="13" height="13" viewBox="0 0 24 24" fill="#F59E0B" stroke="#F59E0B" stroke-width="1">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
              </div>
              <p class="t-quote">"{{ s.review }}"</p>
            </div>

            <div class="t-card-footer">
              <span class="t-verified-stamp">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                  <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                Invigilated Exam Verification
              </span>
            </div>
          </div>
        </div>

        <!-- Recruiter Testimonials Grid -->
        <div class="testimonials-grid" *ngIf="activeTestimonialTab === 'recruiters'">
          <div *ngFor="let r of recruiterTestimonials" class="testimonial-card recruiter-card">
            <div class="t-card-top">
              <img [src]="r.avatar" [alt]="r.name" class="t-avatar-img">
              <div class="t-user-info">
                <h3 class="t-name">{{ r.name }}</h3>
                <span class="t-college">{{ r.role }} @ {{ r.company }}</span>
              </div>
            </div>

            <div class="t-quote-body">
              <div class="t-stars">
                <svg *ngFor="let star of [1,2,3,4,5]" width="13" height="13" viewBox="0 0 24 24" fill="#F59E0B" stroke="#F59E0B" stroke-width="1">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
              </div>
              <p class="t-quote">"{{ r.review }}"</p>
            </div>

            <div class="t-card-footer">
              <span class="t-verified-stamp">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                  <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                Verified Employer Partner
              </span>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- PLATFORM STANDARDS STRIP -->
    <section class="stats-banner-section reveal-on-scroll">
      <div class="container stats-banner-grid">
        <div class="banner-stat">
          <div class="stat-number">100%</div>
          <div class="stat-text">In-Person Physical Invigilation Standard</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">Air-Gapped</div>
          <div class="stat-text">Lockdown Assessment Infrastructure</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">3-Track</div>
          <div class="stat-text">Universal Skill Passport Framework</div>
        </div>
        <div class="banner-stat">
          <div class="stat-number">0%</div>
          <div class="stat-text">Remote Proxy & AI Relay Vulnerability</div>
        </div>
      </div>
    </section>

    <!-- FAQ ACCORDION SECTION -->
    <section class="section-padding bg-subtle" id="faq">
      <div class="container container-narrow">
        <div class="section-header text-center reveal-on-scroll">
          <span class="badge badge-teal">Clear Answers</span>
          <h2>Frequently Asked Questions</h2>
          <p class="section-desc">Everything you need to know about physical invigilation, skill passports, and direct interviews.</p>
        </div>

        <div class="faq-accordion-list reveal-on-scroll">
          <div 
            class="faq-accordion-card" 
            *ngFor="let item of faqs; let i = index"
            [class.is-open]="activeFaq === i">
            <button class="faq-accordion-head" (click)="toggleFaq(i)" type="button">
              <span class="faq-accordion-title">{{ item.q }}</span>
              <div class="faq-accordion-icon">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="chevron-svg">
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </div>
            </button>
            <div class="faq-accordion-body" *ngIf="activeFaq === i">
              <p>{{ item.a }}</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- BOTTOM CTA SECTION -->
    <section class="bottom-cta-section">
      <div class="container">
        <div class="bottom-cta-card reveal-on-scroll">
          <div class="cta-glow-orb"></div>
          <h2 class="cta-title">Ready to Replace Resumes with Real Proof?</h2>
          <p class="cta-desc">Join thousands of candidates and top hiring partners on Proveyu today.</p>

          <div class="bottom-cta-actions" *ngIf="!authService.isLoggedIn(); else bottomAuthCtas">
            <a routerLink="/select-role" class="btn btn-lg btn-white-primary">
              Get Started Now →
            </a>
            <a routerLink="/login" class="btn btn-lg btn-glass-secondary">
              Sign In to Existing Account
            </a>
          </div>

          <ng-template #bottomAuthCtas>
            <div class="bottom-cta-actions">
              <ng-container *ngIf="authService.currentRole() === 'candidate'">
                <a routerLink="/dashboard/candidate" class="btn btn-lg btn-white-primary">
                  Open Candidate Dashboard →
                </a>
                <a routerLink="/candidate/book-slot" class="btn btn-lg btn-glass-secondary">
                  Book Exam Slot
                </a>
              </ng-container>
              <ng-container *ngIf="authService.currentRole() !== 'candidate'">
                <a routerLink="/dashboard/recruiter" class="btn btn-lg btn-white-primary">
                  Open Recruiter Dashboard →
                </a>
                <a routerLink="/recruiter/verifiedtalents" class="btn btn-lg btn-glass-secondary">
                  Browse Verified Talent
                </a>
              </ng-container>
            </div>
          </ng-template>
        </div>
      </div>
    </section>

    <app-footer></app-footer>
  `,
  styles: [`
    /* AMBIENT FLOATING MESH BACKGROUND */
    .ambient-glow-wrapper {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      overflow: hidden;
      z-index: 0;
    }
    .glow-orb {
      position: absolute;
      border-radius: 50%;
      filter: blur(110px);
      opacity: 0.18;
      animation: floatOrb 20s ease-in-out infinite alternate;
    }
    .orb-1 {
      width: 550px;
      height: 550px;
      background: radial-gradient(circle, #0F7A5C 0%, #10B981 100%);
      top: -140px;
      right: -100px;
    }
    .orb-2 {
      width: 460px;
      height: 460px;
      background: radial-gradient(circle, #D97706 0%, #F59E0B 100%);
      bottom: 8%;
      left: -160px;
      animation-delay: -6s;
    }
    .orb-3 {
      width: 400px;
      height: 400px;
      background: radial-gradient(circle, #0284C7 0%, #38BDF8 100%);
      top: 38%;
      right: 8%;
      animation-delay: -12s;
    }
    @keyframes floatOrb {
      0% { transform: translate(0, 0) scale(1); }
      100% { transform: translate(60px, 70px) scale(1.15); }
    }

    /* HERO SECTION ENTRANCE */
    @keyframes heroFadeSlide {
      0% { opacity: 0; transform: translateY(30px); }
      100% { opacity: 1; transform: translateY(0); }
    }

    .hero-section .reveal-on-scroll,
    .hero-section .reveal-left,
    .hero-section .reveal-right {
      animation: heroFadeSlide 0.85s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      opacity: 1 !important;
      transform: translate(0) !important;
    }

    .reveal-on-scroll, .reveal-left, .reveal-right {
      opacity: 0;
      transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
      will-change: opacity, transform;
    }
    .reveal-on-scroll { transform: translateY(35px); }
    .reveal-left { transform: translateX(-40px); }
    .reveal-right { transform: translateX(40px); }

    .reveal-on-scroll.is-visible, 
    .reveal-left.is-visible, 
    .reveal-right.is-visible {
      opacity: 1 !important;
      transform: translate(0) !important;
    }
    .delay-1 { transition-delay: 0.12s; }
    .delay-2 { transition-delay: 0.24s; }
    .delay-3 { transition-delay: 0.36s; }

    .hero-section {
      position: relative;
      z-index: 1;
      padding: 4.25rem 0 3.5rem 0;
      background: 
        radial-gradient(circle at 70% 20%, rgba(15, 122, 92, 0.08) 0%, transparent 60%),
        radial-gradient(circle at 20% 80%, rgba(16, 185, 129, 0.04) 0%, transparent 50%);
      border-bottom: 1px solid var(--border-color);
    }

    /* SECTION LAYOUTS & DISTINCT VISUAL SEPARATION */
    .section-padding {
      padding: 4.5rem 0;
      position: relative;
      z-index: 1;
    }
    .bg-subtle {
      background-color: var(--bg-subtle);
      border-top: 1px solid var(--border-color);
      border-bottom: 1px solid var(--border-color);
    }

    /* Architecture Showcase CSS */
    .architecture-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1.75rem;
      margin-top: 2.5rem;
    }
    .arch-card {
      padding: 1.75rem;
      display: flex;
      flex-direction: column;
      border-radius: var(--radius-xl);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      transition: all var(--transition-normal);
    }
    .arch-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-lg);
      border-color: var(--primary-glow);
    }
    .arch-card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.25rem;
    }
    .arch-icon-box {
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: rgba(15, 122, 92, 0.08);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(15, 122, 92, 0.2);
    }
    .arch-card h3 {
      font-size: 1.25rem;
      font-weight: 800;
      color: var(--heading);
      margin-bottom: 0.6rem;
    }
    .arch-card p {
      font-size: 0.9rem;
      color: var(--text-muted);
      line-height: 1.55;
      margin-bottom: 1.5rem;
      flex-grow: 1;
    }
    .arch-visual-box {
      position: relative;
      background: #0F172A;
      border-radius: 8px;
      overflow: hidden;
      border: 1px solid #1E293B;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);
      height: 125px;
      cursor: pointer;
    }
    .arch-visual-front {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      background: #0F172A;
      opacity: 0;
      transform: scale(0.96);
      transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 1;
    }
    .arch-visual-back {
      position: absolute;
      inset: 0;
      opacity: 1;
      transform: scale(1);
      transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 2;
    }
    .arch-visual-back img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .visual-back-badge {
      position: absolute;
      bottom: 8px;
      right: 8px;
      background: rgba(15, 23, 42, 0.85);
      color: #F8FAFC;
      border: 1px solid rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(4px);
      padding: 0.25rem 0.6rem;
      border-radius: 4px;
      font-size: 0.675rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    .arch-card:hover .arch-visual-front,
    .arch-visual-box:hover .arch-visual-front {
      opacity: 1;
      transform: scale(1);
    }
    .arch-card:hover .arch-visual-back,
    .arch-visual-box:hover .arch-visual-back {
      opacity: 0;
      transform: scale(1.06);
      pointer-events: none;
    }
    .ui-mock-header {
      background: #1E293B;
      padding: 0.4rem 0.75rem;
      display: flex;
      align-items: center;
      gap: 0.35rem;
      border-bottom: 1px solid #334155;
    }
    .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
    }
    .dot.red { background: #EF4444; }
    .dot.yellow { background: #F59E0B; }
    .dot.green { background: #10B981; }
    .ui-title {
      font-family: monospace;
      font-size: 0.675rem;
      color: #94A3B8;
      margin-left: 0.4rem;
      letter-spacing: 0.05em;
      font-weight: 600;
    }
    .ui-mock-body {
      padding: 0.85rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }
    .step-status-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: monospace;
      font-size: 0.725rem;
    }
    .step-status-row .lbl { color: #94A3B8; }
    .step-status-row .val { color: #F8FAFC; font-weight: 700; }
    .step-status-row .val.green { color: #34D399; }
    .step-status-row .val.blue { color: #60A5FA; }
    .step-status-row .val.gold { color: #FBBF24; }
    @media (max-width: 992px) {
      .architecture-grid { grid-template-columns: 1fr; }
    }

    /* Connected Pipeline Flow CSS */
    .pipeline-container {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.5rem;
      margin-top: 2.5rem;
      position: relative;
    }
    .pipeline-step-col {
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .pipeline-header-node {
      display: flex;
      align-items: center;
      margin-bottom: 1.25rem;
      position: relative;
      height: 36px;
    }
    .pipeline-tag {
      font-size: 0.725rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      padding: 0.4rem 0.85rem;
      border-radius: 6px;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .pipeline-connector {
      display: flex;
      align-items: center;
      flex-grow: 1;
      margin-left: 0.75rem;
      position: relative;
    }
    .connector-line {
      height: 2px;
      flex-grow: 1;
      background: linear-gradient(90deg, #0F7A5C 0%, rgba(15, 122, 92, 0.25) 100%);
    }
    .connector-arrow {
      font-size: 0.85rem;
      color: #0F7A5C;
      margin-left: -2px;
      font-weight: 800;
    }
    .pipeline-card {
      padding: 1.75rem 1.5rem;
      border-radius: var(--radius-xl);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      flex-grow: 1;
      transition: all var(--transition-normal);
      display: flex;
      flex-direction: column;
    }
    .pipeline-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-md);
      border-color: var(--primary-glow);
    }
    .pipeline-card h3 {
      font-size: 1.15rem;
      font-weight: 800;
      color: var(--heading);
      margin-bottom: 0.65rem;
    }
    .pipeline-card p {
      font-size: 0.875rem;
      color: var(--text-muted);
      line-height: 1.55;
      margin: 0;
    }
    .highlight-pipeline-card {
      border: 1.5px solid var(--primary);
      box-shadow: 0 4px 20px rgba(15, 122, 92, 0.1);
    }
    @media (max-width: 992px) {
      .pipeline-container {
        grid-template-columns: 1fr;
        gap: 2rem;
      }
      .pipeline-connector {
        display: none;
      }
    }
    .bg-white-section {
      background-color: var(--bg-main);
    }
    .section-header {
      margin-bottom: 2.75rem;
    }

    .hero-container {
      display: grid;
      grid-template-columns: 1.15fr 0.85fr;
      gap: 3.5rem;
      align-items: center;
    }
    .pill-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.45rem 0.95rem;
      background: rgba(15, 122, 92, 0.08);
      border: 1px solid rgba(15, 122, 92, 0.25);
      border-left: 3.5px solid #0F7A5C;
      border-radius: 6px;
      color: #0B4F3C;
      font-size: 0.775rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      margin-bottom: 1.35rem;
      box-shadow: 0 1px 4px rgba(15, 122, 92, 0.06);
      transition: all var(--transition-fast);
    }
    .pill-badge:hover {
      border-color: var(--primary);
      transform: translateY(-1px);
    }
    .badge-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.3);
      animation: dotPulse 2s infinite;
    }
    @keyframes dotPulse {
      0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.6); }
      70% { box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
      100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
    }
    .hero-title {
      font-size: 3.4rem;
      font-weight: 800;
      letter-spacing: -0.03em;
      margin-bottom: 1.25rem;
      color: var(--heading);
      line-height: 1.12;
    }
    .gradient-text {
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 50%, #059669 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .hero-subtitle {
      font-size: 1.15rem;
      color: var(--text-muted);
      margin-bottom: 2.25rem;
      max-width: 600px;
      line-height: 1.65;
    }
    .hero-cta-group {
      display: flex;
      gap: 1.1rem;
      flex-wrap: wrap;
      margin-bottom: 2.75rem;
    }
    .shadow-glow {
      box-shadow: 0 10px 30px rgba(15, 122, 92, 0.35);
      position: relative;
      overflow: hidden;
      transition: all var(--transition-fast);
    }
    .shadow-glow:hover {
      box-shadow: 0 14px 38px rgba(15, 122, 92, 0.45);
      transform: translateY(-2px);
    }
    .hero-trust-row {
      display: flex;
      align-items: center;
      gap: 1.75rem;
      padding-top: 1.75rem;
      border-top: 1px solid var(--border-color);
    }
    .trust-stat {
      display: flex;
      flex-direction: column;
    }
    .stat-num {
      font-family: 'Outfit', sans-serif;
      font-size: 1.45rem;
      font-weight: 800;
      color: var(--heading);
      letter-spacing: -0.02em;
    }
    .stat-lbl {
      font-size: 0.775rem;
      color: var(--text-muted);
      font-weight: 500;
    }
    .trust-divider {
      width: 1px;
      height: 32px;
      background: var(--border-color);
    }

    /* HERO VISUAL CARD (PASSPORT SHOWCASE) */
    .passport-preview-card {
      background: var(--bg-card);
      border: 2px solid var(--primary);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-xl), 0 0 35px var(--primary-glow);
      color: var(--text-main);
      position: relative;
      transition: transform 0.5s ease, box-shadow 0.5s ease;
    }
    .passport-preview-card:hover {
      transform: translateY(-6px) scale(1.01);
      box-shadow: var(--shadow-xl), 0 12px 45px rgba(15, 122, 92, 0.25);
    }
    .card-top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.85rem;
      border-bottom: 1px dashed var(--border-color);
    }
    .card-top-bar .brand {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-weight: 800;
      font-size: 0.825rem;
      color: var(--primary);
      letter-spacing: 0.5px;
    }
    .candidate-header-mini {
      display: flex;
      align-items: center;
      gap: 1.1rem;
      margin-bottom: 1.35rem;
    }
    .mini-avatar-initials {
      width: 58px;
      height: 58px;
      border-radius: 50%;
      border: 3px solid var(--primary);
      box-shadow: 0 4px 12px var(--primary-glow);
      background: linear-gradient(135deg, #0F7A5C, #0B4F3C);
      color: #FFFFFF;
      font-weight: 800;
      font-size: 1.25rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .candidate-header-mini .name {
      font-size: 1.15rem;
      color: var(--heading);
      margin: 0;
      font-weight: 700;
    }
    .candidate-header-mini .track {
      font-size: 0.775rem;
      color: var(--primary);
      font-weight: 600;
      display: block;
    }
    .candidate-header-mini .centre {
      font-size: 0.725rem;
      color: var(--text-muted);
      display: block;
      margin-top: 2px;
    }
    .score-badge-circle {
      margin-left: auto;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 100%);
      color: #FFFFFF;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      flex-shrink: 0;
      box-shadow: 0 4px 14px var(--primary-glow);
    }
    .score-badge-circle .num {
      font-family: 'Outfit', sans-serif;
      font-weight: 800;
      font-size: 1.25rem;
      line-height: 1;
      display: block;
    }
    .score-badge-circle .lbl {
      font-size: 0.55rem;
      font-weight: 800;
      letter-spacing: 0.5px;
      display: block;
      line-height: 1;
      margin-top: 2px;
    }
    .skills-bars-mini {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-bottom: 1.35rem;
    }
    .bar-row {
      display: grid;
      grid-template-columns: 145px 1fr 42px;
      align-items: center;
      gap: 0.6rem;
      font-size: 0.775rem;
      font-weight: 600;
      color: var(--heading);
    }
    .bar {
      height: 7px;
      background: var(--bg-subtle);
      border-radius: 9999px;
      overflow: hidden;
      border: 1px solid var(--border-color);
    }
    .fill {
      height: 100%;
      background: linear-gradient(90deg, #0F7A5C 0%, #10B981 100%);
      border-radius: 9999px;
    }
    .recommendation-pill {
      background: var(--primary-subtle);
      border: 1px solid var(--primary-glow);
      border-radius: var(--radius-md);
      padding: 0.75rem;
      font-size: 0.775rem;
      color: var(--heading);
      margin-bottom: 1.1rem;
    }
    .invigilated-stamp {
      font-size: 0.75rem;
      font-weight: 700;
      color: var(--primary);
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }

    /* SECTION LAYOUTS & PADDINGS */
    .section-padding {
      padding: 3rem 0;
      position: relative;
      z-index: 1;
    }
    .bg-subtle {
      background-color: var(--bg-subtle);
    }
    .section-header {
      margin-bottom: 2rem;
    }
    .section-header h2 {
      font-size: 2.35rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      margin-top: 0.5rem;
      color: var(--heading);
    }
    .section-desc {
      color: var(--text-muted);
      font-size: 1.075rem;
      max-width: 660px;
      margin: 0.65rem auto 0 auto;
      line-height: 1.6;
    }

    /* DIAGNOSTIC SUMMARY STRIP */
    .diag-summary-strip {
      display: flex;
      justify-content: space-around;
      align-items: center;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 1.25rem 2rem;
      margin-bottom: 2rem;
      box-shadow: var(--shadow-sm);
    }
    .diag-summary-item {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    .d-metric {
      font-family: 'Outfit', sans-serif;
      font-size: 1.75rem;
      font-weight: 800;
      line-height: 1;
    }
    .red-alert .d-metric { color: #DC2626; }
    .green-verified .d-metric { color: #10B981; }
    .blue-info .d-metric { color: #2563EB; }
    .d-text {
      font-size: 0.85rem;
      font-weight: 700;
      color: var(--heading);
      max-width: 140px;
      line-height: 1.3;
    }
    .diag-summary-divider {
      width: 1px;
      height: 40px;
      background: var(--border-color);
    }
    @media (max-width: 768px) {
      .diag-summary-strip { flex-direction: column; gap: 1rem; align-items: flex-start; }
      .diag-summary-divider { display: none; }
    }

    /* COMPARISON CARDS & FEATURE STACK */
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
    }
    .comp-card {
      background: var(--bg-card);
      border-radius: var(--radius-xl);
      padding: 2.25rem;
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-md);
      transition: all var(--transition-normal);
      color: var(--text-main);
    }
    .comp-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-xl);
    }
    .old-way {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-sm);
    }
    .old-way:hover {
      border-color: #CBD5E1;
      box-shadow: var(--shadow-lg);
    }
    .deservify-way {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-sm);
    }
    .deservify-way:hover {
      border-color: var(--primary);
      box-shadow: var(--shadow-lg);
    }
    .card-header-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.725rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      padding: 0.4rem 0.85rem;
      border-radius: 6px;
      margin-bottom: 1.1rem;
    }
    .red-tag {
      background: rgba(239, 68, 68, 0.07);
      color: #991B1B;
      border: 1px solid rgba(239, 68, 68, 0.25);
      border-left: 3.5px solid #DC2626;
    }
    .green-tag {
      background: rgba(15, 122, 92, 0.07);
      color: #0B4F3C;
      border: 1px solid rgba(15, 122, 92, 0.25);
      border-left: 3.5px solid #0F7A5C;
    }
    .comp-card h3 { font-size: 1.4rem; margin-bottom: 0.4rem; font-weight: 800; color: var(--heading); }
    .comp-card-sub { font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1.5rem; line-height: 1.5; }

    .comp-feature-stack {
      display: flex;
      flex-direction: column;
      gap: 1.15rem;
    }
    .comp-feature-row {
      display: flex;
      align-items: flex-start;
      gap: 0.85rem;
    }
    .f-icon-box {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      margin-top: 2px;
    }
    .f-icon-box.red-icon { background: #FEE2E2; color: #DC2626; }
    .f-icon-box.green-icon { background: var(--primary-subtle); color: #10B981; }
    .comp-feature-row h4 { font-size: 0.95rem; font-weight: 700; color: var(--heading); margin-bottom: 0.2rem; }
    .comp-feature-row p { font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; }

    .f-icon-badge {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--primary-subtle);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* STEPS FLOW GRID */
    .steps-flow-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.5rem;
    }
    .flow-step-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 1.85rem 1.65rem;
      position: relative;
      transition: all var(--transition-normal);
      display: flex;
      flex-direction: column;
    }
    .flow-step-card:hover {
      transform: translateY(-5px);
      border-color: rgba(15, 122, 92, 0.4);
      box-shadow: var(--shadow-lg);
    }
    .highlight-step-card {
      border: 1.5px solid var(--primary);
      box-shadow: var(--shadow-md), 0 0 20px rgba(15, 122, 92, 0.08);
    }
    .step-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
    }
    .step-num-badge {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      background: var(--primary-subtle);
      color: var(--primary);
      font-weight: 800;
      font-size: 1.05rem;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(15, 122, 92, 0.25);
    }
    .highlight-step {
      background: linear-gradient(135deg, #0F7A5C 0%, #10B981 100%);
      color: #FFFFFF;
      box-shadow: 0 4px 14px var(--primary-glow);
      border: none;
    }
    .step-icon-box {
      width: 40px;
      height: 40px;
      border-radius: var(--radius-md);
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all var(--transition-fast);
    }
    .highlight-icon {
      background: var(--primary-subtle);
      border-color: rgba(15, 122, 92, 0.3);
      color: var(--primary);
    }
    .flow-step-card:hover .step-icon-box {
      background: var(--primary-subtle);
      border-color: var(--primary);
      transform: scale(1.05);
    }
    .flow-step-card h3 { 
      font-size: 1.15rem; 
      margin-bottom: 0.6rem; 
      font-weight: 700; 
      color: var(--heading); 
      line-height: 1.3;
    }
    .flow-step-card p { 
      font-size: 0.875rem; 
      color: var(--text-muted); 
      line-height: 1.6; 
    }
    @media (max-width: 992px) {
      .steps-flow-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }
    @media (max-width: 576px) {
      .steps-flow-grid {
        grid-template-columns: 1fr;
      }
    }

    /* UNIVERSAL FRESHER SECTION */
    .fresher-box {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 3.5rem;
      align-items: center;
    }
    .fresher-content h2 { font-size: 2.3rem; margin: 0.5rem 0 1rem 0; font-weight: 800; color: var(--heading); }
    .fresher-benefits { margin-top: 1.75rem; display: flex; flex-direction: column; gap: 1.25rem; }
    .f-item { display: flex; flex-direction: column; gap: 0.3rem; }
    .f-item h4 { font-size: 1rem; font-weight: 700; color: var(--heading); margin: 0; }
    .f-item p { font-size: 0.875rem; color: var(--text-muted); line-height: 1.55; margin: 0; }
    .margin-top { margin-top: 2.25rem; }

    .radar-mockup-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 2rem;
      box-shadow: var(--shadow-lg);
      color: var(--text-main);
    }
    .radar-mockup-card h4 { font-size: 1.15rem; margin-bottom: 1.35rem; font-weight: 700; color: var(--heading); }
    .competency-bars-full { display: flex; flex-direction: column; gap: 1.1rem; margin-bottom: 1.35rem; }
    .c-row { display: grid; grid-template-columns: 175px 1fr 50px; align-items: center; gap: 0.6rem; font-size: 0.85rem; font-weight: 600; color: var(--heading); }
    .c-bar { height: 9px; background: var(--bg-subtle); border-radius: 9999px; overflow: hidden; border: 1px solid var(--border-color); }
    .c-fill { height: 100%; background: linear-gradient(90deg, #0F7A5C 0%, #10B981 100%); border-radius: 9999px; }
    .radar-footer {
      background: var(--primary-subtle);
      border: 1px solid var(--primary-glow);
      padding: 0.85rem 1rem;
      border-radius: var(--radius-md);
      font-size: 0.825rem;
      display: flex;
      flex-direction: column;
      gap: 0.35rem;
    }
    .rec-highlight { font-weight: 700; color: var(--primary); }

    /* STATS BANNER */
    .stats-banner-section {
      background: #0B1120;
      color: #FFFFFF;
      padding: 4rem 0;
      position: relative;
      z-index: 1;
      border-top: 1px solid #1E293B;
      border-bottom: 1px solid #1E293B;
    }
    .stats-banner-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 2.25rem;
      text-align: center;
    }
    .stat-number {
      font-family: 'Outfit', sans-serif;
      font-size: 2.75rem;
      font-weight: 800;
      color: #34D399;
      text-shadow: 0 0 20px rgba(52, 211, 153, 0.3);
      letter-spacing: -0.02em;
    }
    .stat-text {
      font-size: 0.925rem;
      color: #94A3B8;
      margin-top: 0.4rem;
      font-weight: 500;
    }

    .container-narrow { max-width: 820px; margin: 0 auto; }

    /* PROFESSIONAL FAQ ACCORDION STYLES */
    .faq-accordion-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .faq-accordion-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      overflow: hidden;
      transition: all var(--transition-fast);
      box-shadow: var(--shadow-sm);
    }
    .faq-accordion-card:hover {
      border-color: var(--primary-glow);
      box-shadow: var(--shadow-md);
    }
    .faq-accordion-card.is-open {
      border-color: #10B981;
      box-shadow: 0 6px 24px rgba(16, 185, 129, 0.12);
    }

    .faq-accordion-head {
      width: 100% !important;
      text-align: left !important;
      padding: 1.35rem 1.65rem !important;
      background: transparent !important;
      border: none !important;
      outline: none !important;
      box-shadow: none !important;
      appearance: none !important;
      -webkit-appearance: none !important;
      cursor: pointer !important;
      display: flex !important;
      justify-content: space-between !important;
      align-items: center !important;
      gap: 1.25rem !important;
      margin: 0 !important;
    }
    .faq-accordion-title {
      font-size: 1.05rem;
      font-weight: 700;
      color: var(--heading);
      line-height: 1.4;
      transition: color var(--transition-fast);
    }
    .faq-accordion-card.is-open .faq-accordion-title,
    .faq-accordion-head:hover .faq-accordion-title {
      color: var(--primary);
    }

    .faq-accordion-icon {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-muted);
      flex-shrink: 0;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .chevron-svg {
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .faq-accordion-card.is-open .faq-accordion-icon {
      background: var(--primary-subtle);
      border-color: var(--primary-glow);
      color: var(--primary);
    }
    .faq-accordion-card.is-open .chevron-svg {
      transform: rotate(180deg);
    }

    .faq-accordion-body {
      padding: 0 1.65rem 1.4rem 1.65rem;
      border-top: 1px dashed var(--border-color);
      margin-top: 0.1rem;
      padding-top: 1rem;
      animation: faqFadeIn 0.3s ease forwards;
    }
    .faq-accordion-body p {
      color: var(--text-muted);
      font-size: 0.95rem;
      line-height: 1.65;
      margin: 0;
    }

    @keyframes faqFadeIn {
      from { opacity: 0; transform: translateY(-4px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* BOTTOM CTA SECTION STYLES */
    .bottom-cta-section {
      padding: 3.5rem 0;
      position: relative;
      z-index: 1;
      background: var(--bg-subtle);
    }
    .bottom-cta-card {
      position: relative;
      background: linear-gradient(135deg, #0F7A5C 0%, #0B5E46 50%, #064E3B 100%);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: var(--radius-2xl);
      padding: 4rem 2rem;
      text-align: center;
      color: #FFFFFF;
      overflow: hidden;
      box-shadow: 0 20px 50px rgba(15, 122, 92, 0.25);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .cta-glow-orb {
      position: absolute;
      top: -50px;
      right: -50px;
      width: 250px;
      height: 250px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(16, 185, 129, 0.3) 0%, transparent 70%);
      pointer-events: none;
    }
    .bottom-cta-card .badge-gold {
      margin-bottom: 1.25rem;
    }
    .cta-title {
      color: #FFFFFF !important;
      font-size: 2.5rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      margin-bottom: 1rem;
      max-width: 750px;
      text-align: center;
    }
    .cta-desc {
      color: rgba(255, 255, 255, 0.9) !important;
      font-size: 1.15rem;
      max-width: 620px;
      margin: 0 auto 2.25rem auto;
      line-height: 1.6;
      text-align: center;
    }
    .bottom-cta-actions {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 1.25rem;
      flex-wrap: wrap;
    }
    
    /* SPECIFIC HIGH-CONTRAST BUTTONS FOR CTA BANNER */
    .btn-white-primary {
      background: #FFFFFF !important;
      color: #0F7A5C !important;
      font-weight: 800 !important;
      border: 1px solid #FFFFFF !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2) !important;
      transition: all var(--transition-fast) !important;
    }
    .btn-white-primary:hover {
      transform: translateY(-2px) scale(1.02) !important;
      background: #F8FAFC !important;
      color: #0B5E46 !important;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3) !important;
    }
    .btn-glass-secondary {
      background: rgba(255, 255, 255, 0.12) !important;
      color: #FFFFFF !important;
      font-weight: 700 !important;
      border: 1.5px solid rgba(255, 255, 255, 0.4) !important;
      backdrop-filter: blur(8px) !important;
      transition: all var(--transition-fast) !important;
    }
    .btn-glass-secondary:hover {
      transform: translateY(-2px) !important;
      background: rgba(255, 255, 255, 0.25) !important;
      border-color: #FFFFFF !important;
      color: #FFFFFF !important;
    }

    /* DARK MODE SPECIFIC HOME PAGE OVERRIDES */
    [data-theme="dark"] .gradient-text,
    body.dark-theme .gradient-text {
      background: linear-gradient(135deg, #10B981 0%, #34D399 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    [data-theme="dark"] .pill-badge,
    body.dark-theme .pill-badge {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #34D399;
    }

    [data-theme="dark"] .passport-preview-card,
    body.dark-theme .passport-preview-card {
      background: #0F172A;
      border-color: #10B981;
      box-shadow: 0 0 30px rgba(16, 185, 129, 0.2);
    }

    [data-theme="dark"] .deservify-way,
    body.dark-theme .deservify-way {
      background: #0F172A;
      border-color: #10B981;
      box-shadow: 0 0 30px rgba(16, 185, 129, 0.15);
    }

    [data-theme="dark"] .old-way,
    body.dark-theme .old-way {
      background: #0F172A;
      border-color: rgba(239, 68, 68, 0.4);
    }

    [data-theme="dark"] .red-tag,
    body.dark-theme .red-tag {
      background: rgba(239, 68, 68, 0.2);
      color: #FCA5A5;
      border-color: rgba(239, 68, 68, 0.4);
    }

    [data-theme="dark"] .green-tag,
    body.dark-theme .green-tag {
      background: rgba(15, 122, 92, 0.3);
      color: #34D399;
      border-color: #10B981;
    }

    [data-theme="dark"] .recommendation-pill,
    body.dark-theme .recommendation-pill {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #F8FAFC;
    }

    [data-theme="dark"] .radar-footer,
    body.dark-theme .radar-footer {
      background: rgba(15, 122, 92, 0.25);
      border-color: #10B981;
      color: #CBD5E1;
    }

    [data-theme="dark"] .rec-highlight,
    body.dark-theme .rec-highlight {
      color: #34D399;
    }



    /* PLACEMENT STATS STRIP */
    .placement-stats-strip {
      display: flex;
      align-items: center;
      justify-content: space-around;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 1.75rem 2rem;
      margin-bottom: 2.75rem;
      box-shadow: var(--shadow-md);
      flex-wrap: wrap;
      gap: 1.25rem;
    }
    .p-stat-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }
    .p-num {
      font-family: 'Outfit', sans-serif;
      font-size: 1.85rem;
      font-weight: 800;
      color: var(--heading);
      letter-spacing: -0.02em;
    }
    .p-lbl {
      font-size: 0.8rem;
      color: var(--text-muted);
      font-weight: 600;
      margin-top: 0.2rem;
    }
    .p-stat-divider {
      width: 1px;
      height: 40px;
      background: var(--border-color);
    }

    /* TESTIMONIAL TOGGLE BAR */
    .testimonial-toggle-bar {
      display: flex;
      justify-content: center;
      gap: 0.75rem;
      margin-bottom: 2.25rem;
      flex-wrap: wrap;
    }
    .t-toggle-btn {
      padding: 0.6rem 1.35rem;
      border-radius: var(--radius-full);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      color: var(--text-muted);
      font-weight: 700;
      font-size: 0.875rem;
      cursor: pointer;
      transition: all var(--transition-fast);
    }
    .t-toggle-btn:hover {
      color: var(--heading);
      border-color: #94A3B8;
    }
    .t-toggle-btn.active {
      background: #0F172A;
      color: #F8FAFC;
      border-color: #0F172A;
      box-shadow: 0 4px 14px rgba(15, 23, 42, 0.15);
    }

    /* TESTIMONIALS GRID (4 CARDS IN A ROW) */
    .testimonials-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 1.25rem;
    }
    .testimonial-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-lg);
      padding: 1.25rem;
      box-shadow: var(--shadow-sm);
      transition: all var(--transition-normal);
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .testimonial-card:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-md);
      border-color: #CBD5E1;
    }
    .t-card-top {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 0.85rem;
    }
    .t-avatar-img {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid var(--border-color);
      box-shadow: var(--shadow-sm);
      flex-shrink: 0;
    }
    .t-user-info {
      flex-grow: 1;
      min-width: 0;
    }
    .t-name {
      font-size: 0.95rem;
      font-weight: 700;
      color: var(--heading);
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .t-college {
      font-size: 0.725rem;
      color: var(--text-muted);
      display: block;
      margin-top: 1px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .t-score-box {
      background: var(--bg-subtle);
      color: var(--heading);
      border: 1px solid var(--border-color);
      padding: 0.25rem 0.55rem;
      border-radius: 6px;
      text-align: center;
      flex-shrink: 0;
    }
    .t-score-val {
      font-family: 'Outfit', sans-serif;
      font-weight: 800;
      font-size: 0.875rem;
      line-height: 1;
      display: block;
      color: var(--heading);
    }
    .t-score-lbl {
      font-size: 0.5rem;
      font-weight: 700;
      color: var(--text-muted);
      display: block;
      text-transform: uppercase;
      letter-spacing: 0.3px;
      margin-top: 2px;
    }

    /* PLACEMENT BANNER */
    .t-placement-banner {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 0.45rem 0.65rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.85rem;
      gap: 0.5rem;
    }
    .t-placement-info {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      min-width: 0;
      flex-wrap: wrap;
    }
    .t-placed-at {
      font-size: 0.75rem;
      color: var(--heading);
    }
    .t-role-text {
      font-size: 0.725rem;
      color: var(--text-muted);
    }
    .t-package-badge {
      font-size: 0.725rem;
      font-weight: 800;
      color: var(--heading);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      padding: 0.15rem 0.5rem;
      border-radius: 4px;
      display: inline-block;
      flex-shrink: 0;
    }

    .t-quote-body {
      flex-grow: 1;
      margin-bottom: 0.85rem;
    }
    .t-stars {
      display: flex;
      gap: 2px;
      margin-bottom: 0.4rem;
      font-size: 0.75rem;
    }
    .t-quote {
      font-size: 0.825rem;
      color: var(--text-main);
      line-height: 1.45;
      font-style: italic;
    }
    .t-card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 0.65rem;
      border-top: 1px dashed var(--border-color);
      font-size: 0.725rem;
    }
    .t-verified-stamp {
      font-size: 0.7rem;
      color: var(--text-muted);
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
    }
    .t-verified-stamp svg {
      color: #64748B;
    }
    .t-date {
      color: var(--text-muted);
      font-weight: 500;
    }

    @media (max-width: 1200px) {
      .testimonials-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 950px) {
      .hero-container, .fresher-box { grid-template-columns: 1fr; }
      .comparison-grid { grid-template-columns: 1fr; }
      .steps-flow-grid { grid-template-columns: 1fr 1fr; }
      .stats-banner-grid { grid-template-columns: 1fr 1fr; }
      .gallery-grid { grid-template-columns: repeat(2, 1fr); }
      .placement-stats-strip { flex-direction: column; text-align: center; gap: 1rem; }
      .p-stat-divider { display: none; }
    }
    @media (max-width: 640px) {
      .steps-flow-grid { grid-template-columns: 1fr; }
      .stats-banner-grid { grid-template-columns: 1fr; }
      .hero-title { font-size: 2.35rem; }
      .gallery-grid { grid-template-columns: 1fr; }
      .testimonials-grid { grid-template-columns: 1fr; }
      .t-placement-banner { flex-direction: column; align-items: flex-start; text-align: left; }
      .t-package-col { text-align: left; }
    }
    
    [data-theme="dark"] .t-package-badge,
    body.dark-theme .t-package-badge {
      background: rgba(16, 185, 129, 0.2);
      color: #34D399;
    }
    [data-theme="dark"] .gallery-modal-card,
    body.dark-theme .gallery-modal-card {
      background: #0F172A;
      border-color: #10B981;
    }
  `]
})
export class HomeComponent implements OnInit, AfterViewInit {
  authService = inject(AuthService);
  elementRef = inject(ElementRef);
  private platformId = inject(PLATFORM_ID);

  activeFaq: number | null = 0;



  // TESTIMONIALS & PLACED REVIEWS STATE
  activeTestimonialTab: string = 'students';

  placedStudents = [
    {
      id: 1,
      name: 'Priya Sundaram',
      role: 'QA Automation',
      company: 'TechCorp',
      package: '₹9.2 LPA',
      score: '96/100',
      college: 'Tier-3 Engineering College, Salem',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      badge: 'Gold Passport',
      review: 'Coming from a tier-3 college, my resume was auto-filtered. Proveyu gave me an equal stage. I scored 96% in QA at the TCS iON lab and got hired by TechCorp in 5 days!'
    },
    {
      id: 2,
      name: 'Vikramaditya Roy',
      role: 'Java Backend',
      company: 'CloudScale',
      package: '₹11.5 LPA',
      score: '94/100',
      college: 'Govt Inst of Tech, Kolkata',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      badge: 'Gold Passport',
      review: 'Invigilated exam centre proof gave recruiters 100% confidence. I bypassed online preliminary tests completely and went straight to the CTO round.'
    },
    {
      id: 3,
      name: 'Ananya Deshmukh',
      role: 'Full Stack Eng',
      company: 'InnovateX',
      package: '₹14.0 LPA',
      score: '98/100',
      college: 'State Tech Univ, Pune',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      badge: 'Top 1% Rank',
      review: 'The Universal Fresher Competency test mapped my skills to Backend & Full Stack. Received 4 direct interview invites within 7 days of my exam!'
    },
    {
      id: 4,
      name: 'Rohan Verma',
      role: 'SDET Engineer',
      company: 'Fintech Nexus',
      package: '₹10.8 LPA',
      score: '92/100',
      college: 'B.Tech IT, Bhopal',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      badge: 'Silver Passport',
      review: 'Biometric verification at the JEE lab center and multi-dimensional skill proof made hiring managers trust my capability immediately.'
    }
  ];

  recruiterTestimonials = [
    {
      id: 1,
      name: 'Rajesh Malhotra',
      role: 'VP of Engineering',
      company: 'Apex Digital',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      review: 'We reduced our fresher hiring cycle from 4 weeks to 3 days. Invigilated exam lab proof eliminates fake resumes and proxy-test takers completely.'
    },
    {
      id: 2,
      name: 'Meera Nambiar',
      role: 'Head of Talent',
      company: 'ScaleX Solutions',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      review: 'The multi-dimensional skill breakdown is outstanding. We get exact percentages in logic, QA, and backend before conducting final interviews.'
    },
    {
      id: 3,
      name: 'Sunil Kulkarni',
      role: 'Engineering Director',
      company: 'Fintech Corp',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      review: 'Physical invigilation completely removes remote cheating risk. Proveyu Skill Passports are our go-to standard for junior developer hiring.'
    },
    {
      id: 4,
      name: 'Kavita Iyer',
      role: 'Lead Campus Recruiter',
      company: 'TechCorp India',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
      rating: 5,
      review: 'We hired 15 Tier-2 and Tier-3 college freshers directly through Proveyu. Every hire was production-ready from day one.'
    }
  ];

  ngOnInit() {
    this.authService.logout();
  }

  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      requestAnimationFrame(() => {
        this.initScrollObserver();
      });
    }
  }

  private initScrollObserver() {
    if (typeof window === 'undefined') return;

    const elements = Array.from(
      this.elementRef.nativeElement.querySelectorAll(
        '.reveal-on-scroll, .reveal-left, .reveal-right'
      )
    ) as HTMLElement[];

    const revealInView = () => {
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      elements.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < windowHeight * 0.95 && rect.bottom > 0) {
          el.classList.add('is-visible');
        }
      });
    };

    revealInView();

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              observer.unobserve(entry.target);
            }
          });
        },
        {
          threshold: 0.05,
          rootMargin: '0px 0px -20px 0px'
        }
      );

      elements.forEach((el) => {
        if (!el.classList.contains('is-visible')) {
          observer.observe(el);
        }
      });
    } else {
      elements.forEach((el) => el.classList.add('is-visible'));
    }

    setTimeout(revealInView, 100);
    setTimeout(revealInView, 300);
  }

  faqs = [
    {
      q: 'How does Proveyu prevent cheating during skill verification tests?',
      a: 'We partner with established high-stakes examination infrastructure (such as TCS iON and JEE test centres) equipped with biometric fingerprint scans, physical invigilators, CCTV logging, and air-gapped exam terminals. This completely eliminates remote cheating, proxy test takers, and AI relay assistance.'
    },
    {
      q: 'What is the Universal Fresher Competency Passport?',
      a: 'Freshers are evaluated through a single comprehensive test assessing core programming logic, scenario QA aptitude, and hands-on build track choices. The resulting Skill Passport highlights multi-dimensional role matches (e.g. Primary: QA Engineer, Secondary: Java Backend), maximizing candidate placement across multiple recruiter openings.'
    },
    {
      q: 'Do candidates pay to get verified?',
      a: 'Initial registration and slot booking at partner centres is free or offered at a nominal booking fee during pilot batches. Recruiters pay a placement commission or subscription fee to access verified candidate passports.'
    },
    {
      q: 'How do recruiters skip the online assessment phase?',
      a: 'Because candidates have already completed an in-person, invigilated practical coding and QA test, recruiters can trust the verified Skill Passport scores. Verified candidates move directly to final technical and culture interview rounds.'
    }
  ];

  toggleFaq(index: number) {
    this.activeFaq = this.activeFaq === index ? null : index;
  }
}
