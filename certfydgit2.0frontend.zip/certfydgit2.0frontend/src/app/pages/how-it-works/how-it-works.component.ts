import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-how-it-works',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-teal-banner">End-to-End Verification Journey</span>
          <h1 class="page-title">How Proveyu Skill Verification Works</h1>
          <p class="page-subtitle">
            From initial track selection to physical exam hall invigilation and direct recruiter placement — an un-cheatable merit system.
          </p>
        </div>
      </section>

      <!-- 4 Detailed Steps Section -->
      <section class="section-padding">
        <div class="container">
          <div class="steps-vertical-list">
            
            <!-- Step 1 -->
            <div class="step-detail-card deservify-card">
              <div class="step-left">
                <div class="step-num">01</div>
                <div class="step-icon-badge">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>
                </div>
              </div>
              <div class="step-body">
                <span class="badge badge-teal">Step 1: Account Registration & Track Choice</span>
                <h2>Select Your Skill Domain or Universal Fresher Track</h2>
                <p>
                  Candidates register their academic details and choose their specialization track (Java Spring Boot, QA & Test Automation, Python Data, Full Stack) or select the <strong>Universal Fresher Competency Passport</strong>.
                </p>
                <ul class="step-checklist">
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Free initial profile creation for all candidates</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Multi-track flexibility for freshers and experienced engineers</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Pre-test practice materials and terminal simulator access</span>
                  </li>
                </ul>
              </div>
            </div>

            <!-- Step 2 -->
            <div class="step-detail-card deservify-card">
              <div class="step-left">
                <div class="step-num">02</div>
                <div class="step-icon-badge">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
              </div>
              <div class="step-body">
                <span class="badge badge-teal">Step 2: Partner Exam Centre Slot Booking</span>
                <h2>Reserve Your Spot at High-Stakes Test Infrastructure</h2>
                <p>
                  Pick a preferred date and partner examination center near your city (TCS iON Digital Zones, JEE Authorized Computer Labs). Receive an official digital Admit Card featuring biometric verification QR code.
                </p>
                <ul class="step-checklist">
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Over 480+ partner test centres across major Indian tech hubs</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Flexible weekend slots (Morning & Afternoon sessions)</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Automated Admit Card PDF generation with roll number & hall instructions</span>
                  </li>
                </ul>
              </div>
            </div>

            <!-- Step 3 -->
            <div class="step-detail-card deservify-card">
              <div class="step-left">
                <div class="step-num">03</div>
                <div class="step-icon-badge">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
                </div>
              </div>
              <div class="step-body">
                <span class="badge badge-gold">Step 3: In-Person Invigilated Assessment</span>
                <h2>Attempt Practical Coding & Scenario Tasks in Monitored Labs</h2>
                <p>
                  Present original photo ID at the test hall gate for biometric fingerprint verification. Candidates take practical 3-hour skill evaluations on air-gapped test terminals under human invigilator and CCTV supervision.
                </p>
                <ul class="step-checklist">
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Zero secondary screen, proxy test-taker, or AI relay leakage</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Hands-on scenario tasks (bug fixing, API integration, REST assertions)</span>
                  </li>
                  <li>
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>In-person proctor audit logs cryptographically hashed</span>
                  </li>
                </ul>
              </div>
            </div>

            <!-- Step 4 -->
            <div class="step-detail-card deservify-card highlight-card">
              <div class="step-left">
                <div class="step-num highlight-num">04</div>
                <div class="step-icon-badge highlight-icon">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>
                </div>
              </div>
              <div class="step-body">
                <span class="badge badge-green">Step 4: Skill Passport & Direct Interview Invites</span>
                <h2>Skip Initial Screening & Connect directly with Top Recruiters</h2>
                <p>
                  Your multi-dimensional Proveyu Skill Passport is generated. Top startups, corporate enterprises, and placement agencies browse unmasked scores and send direct technical interview requests with zero extra screening tests.
                </p>
                <ul class="step-checklist">
                  <li>
                    <svg class="check-icon green-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Multi-dimensional score breakdown across logic, QA, and backend</span>
                  </li>
                  <li>
                    <svg class="check-icon green-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Direct interview scheduling bypassing resume filters</span>
                  </li>
                  <li>
                    <svg class="check-icon green-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>94% interview-to-placement success rate</span>
                  </li>
                </ul>
              </div>
            </div>

          </div>

          <div class="cta-box text-center margin-top-lg">
            <h2>Ready to Experience Verified Skill Hiring?</h2>
            <div class="cta-btn-row">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">
                <span>Register as Candidate</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
                <span>Hire Verified Talent</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #0F7A5C 0%, #0B5E46 100%);
      color: #FFFFFF;
      padding: 4.5rem 0;
      position: relative;
    }
    .badge-teal-banner {
      background: rgba(255, 255, 255, 0.18);
      color: #FFFFFF;
      border: 1px solid rgba(255, 255, 255, 0.35);
      backdrop-filter: blur(4px);
    }
    .page-title {
      font-size: 2.85rem;
      font-weight: 800;
      color: #FFFFFF;
      margin: 0.85rem 0;
      letter-spacing: -0.02em;
    }
    .page-subtitle {
      font-size: 1.15rem;
      opacity: 0.95;
      max-width: 680px;
      margin: 0 auto;
      line-height: 1.65;
    }
    .section-padding {
      padding: 4.5rem 0 6rem 0;
      background: var(--bg-subtle);
    }
    .steps-vertical-list {
      display: flex;
      flex-direction: column;
      gap: 2rem;
    }
    .step-detail-card {
      display: grid;
      grid-template-columns: 90px 1fr;
      gap: 2.25rem;
      padding: 2.5rem;
      align-items: flex-start;
      border-radius: var(--radius-xl);
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-sm);
      transition: all var(--transition-normal);
    }
    .step-detail-card:hover {
      transform: translateY(-3px);
      box-shadow: var(--shadow-md);
      border-color: rgba(15, 122, 92, 0.3);
    }
    .highlight-card {
      border: 1.5px solid var(--primary);
      box-shadow: var(--shadow-md), 0 0 20px rgba(15, 122, 92, 0.08);
    }
    .step-left {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.75rem;
    }
    .step-num {
      font-family: 'Outfit', sans-serif;
      font-size: 1.8rem;
      font-weight: 800;
      color: var(--primary);
      line-height: 1;
      background: var(--primary-subtle);
      width: 58px;
      height: 58px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(15, 122, 92, 0.25);
    }
    .highlight-num {
      background: var(--gradient-primary);
      color: #FFFFFF;
      border: none;
    }
    .step-icon-badge {
      width: 38px;
      height: 38px;
      border-radius: var(--radius-md);
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .highlight-icon {
      background: var(--primary-subtle);
      border-color: rgba(15, 122, 92, 0.3);
    }
    .step-body h2 {
      font-size: 1.65rem;
      margin: 0.6rem 0 0.85rem 0;
      font-weight: 800;
      color: var(--heading);
      letter-spacing: -0.01em;
    }
    .step-body p {
      font-size: 1.025rem;
      color: var(--text-muted);
      line-height: 1.65;
      margin-bottom: 1.25rem;
    }
    .step-checklist {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.6rem;
      font-size: 0.925rem;
      font-weight: 600;
      color: var(--heading);
    }
    .step-checklist li {
      display: flex;
      align-items: center;
      gap: 0.6rem;
    }
    .check-icon {
      color: var(--primary);
      flex-shrink: 0;
    }
    .green-icon {
      color: #10B981;
    }
    .margin-top-lg {
      margin-top: 4rem;
    }
    .cta-box {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 3.5rem 2rem;
      box-shadow: var(--shadow-md);
    }
    .cta-box h2 {
      font-size: 2.1rem;
      font-weight: 800;
      margin-bottom: 1.75rem;
      color: var(--heading);
    }
    .cta-btn-row {
      display: flex;
      justify-content: center;
      gap: 1.25rem;
      flex-wrap: wrap;
    }
    @media (max-width: 768px) {
      .step-detail-card {
        grid-template-columns: 1fr;
        gap: 1.25rem;
      }
      .step-left {
        flex-direction: row;
        justify-content: flex-start;
      }
    }
  `]
})
export class HowItWorksComponent { }

