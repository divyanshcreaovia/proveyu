import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-fresher-model',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-gold-banner">Game Changer for Campus & Fresher Hiring</span>
          <h1 class="page-title">The Universal Fresher Competency Model</h1>
          <p class="page-subtitle">
            Freshers don't come pre-specialized. Proveyu's single test evaluates core logic, problem-solving, and practical build choices to recommend exact role fit.
          </p>
        </div>
      </section>

      <!-- Main Explanation Section -->
      <section class="section-padding">
        <div class="container">
          
          <div class="fresher-grid">
            <div class="fresher-text-col">
              <span class="badge badge-teal">Multi-Role Aptitude</span>
              <h2>One Exam — Infinite Placement Opportunities</h2>
              <p class="lead-text">
                Traditional fresher hiring forces graduates to apply for specific narrow roles before they even understand corporate technology stacks. Proveyu replaces narrow tests with a comprehensive competency evaluation.
              </p>

              <div class="pillar-cards-list">
                <div class="pillar-card deservify-card">
                  <div class="p-icon-box green-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/><circle cx="12" cy="12" r="4"/></svg>
                  </div>
                  <div>
                    <h3>1. Core Algorithmic Logic & Control Flow</h3>
                    <p>Evaluates foundational problem-solving, data structure choices, and time/space complexity understanding.</p>
                  </div>
                </div>

                <div class="pillar-card deservify-card">
                  <div class="p-icon-box green-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
                  </div>
                  <div>
                    <h3>2. QA & Test Automation Aptitude</h3>
                    <p>Tests scenario thinking, edge-case coverage, REST assertion writing, and bug isolation skills.</p>
                  </div>
                </div>

                <div class="pillar-card deservify-card">
                  <div class="p-icon-box green-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>
                  </div>
                  <div>
                    <h3>3. Backend Microservices Comprehension</h3>
                    <p>Evaluates Java/Spring Boot or Python REST endpoint implementation, database queries, and code readability.</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Interactive Competency Mockup -->
            <div class="fresher-graphic-col">
              <div class="competency-card-full glass-card">
                <div class="comp-head">
                  <div class="c-avatar-initials">RS</div>
                  <div>
                    <h3 style="margin: 0; font-weight: 800;">Rahul Sharma (Fresher)</h3>
                    <span style="font-size: 0.8rem; color: var(--primary); font-weight: 700;">Universal Fresher Passport #CF-9842</span>
                  </div>
                </div>

                <div class="radar-bars">
                  <div class="r-item">
                    <div class="r-head">
                      <span>Core Logic & Algorithms</span>
                      <span class="r-pts">95% (Strong)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 95%;"></div></div>
                  </div>

                  <div class="r-item">
                    <div class="r-head">
                      <span>QA & Automation Testing</span>
                      <span class="r-pts">94% (Strong)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 94%;"></div></div>
                  </div>

                  <div class="r-item">
                    <div class="r-head">
                      <span>Java Backend Microservices</span>
                      <span class="r-pts">88% (Proficient)</span>
                    </div>
                    <div class="r-bar"><div class="r-fill" style="width: 88%;"></div></div>
                  </div>
                </div>

                <div class="rec-box">
                  <div class="rec-title">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
                    <span>Ranked Placement Recommendation</span>
                  </div>
                  <div class="rec-roles">
                    <span>1st Choice: <strong>Associate QA Automation Engineer</strong></span>
                    <span>2nd Choice: <strong>Java Backend Microservices Developer</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Bottom Action Box -->
          <div class="cta-box text-center margin-top-xl">
            <h2>Get Verified on the Universal Fresher Model Today</h2>
            <div class="cta-btns">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">
                <span>Register as Fresher Candidate</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
                <span>Access Fresher Talent Pool</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </a>
            </div>
          </div>

        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #0F7A5C 0%, #149B76 100%);
      color: #FFFFFF;
      padding: 4.5rem 0;
      position: relative;
    }
    .badge-gold-banner {
      background: rgba(254, 243, 199, 0.2);
      color: #FEF3C7;
      border: 1px solid rgba(251, 191, 36, 0.35);
    }
    .page-title { 
      font-size: 2.85rem; 
      font-weight: 800; 
      color: #FFFFFF; 
      margin: 0.85rem 0; 
      letter-spacing: -0.02em; 
    }
    .page-subtitle { 
      font-size: 1.15rem; 
      opacity: 0.95; 
      max-width: 680px; 
      margin: 0 auto; 
      line-height: 1.65; 
    }
    .section-padding { 
      padding: 4.5rem 0 6rem 0; 
      background: var(--bg-subtle); 
    }
    
    .fresher-grid {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 3.5rem;
      align-items: center;
    }
    .fresher-text-col h2 { 
      font-size: 2.2rem; 
      font-weight: 800; 
      margin: 0.6rem 0 1rem 0; 
      color: var(--heading); 
      letter-spacing: -0.01em; 
    }
    .lead-text { 
      font-size: 1.05rem; 
      color: var(--text-muted); 
      line-height: 1.65; 
      margin-bottom: 2rem; 
    }
    .pillar-cards-list { 
      display: flex; 
      flex-direction: column; 
      gap: 1.15rem; 
    }
    .pillar-card { 
      display: flex; 
      gap: 1.25rem; 
      align-items: flex-start; 
      padding: 1.35rem 1.5rem; 
      border-radius: var(--radius-xl); 
      background: var(--bg-card); 
      border: 1px solid var(--border-color); 
      box-shadow: var(--shadow-sm); 
      transition: all var(--transition-normal); 
    }
    .pillar-card:hover { 
      transform: translateY(-2px); 
      box-shadow: var(--shadow-md); 
      border-color: rgba(15, 122, 92, 0.3); 
    }
    .p-icon-box { 
      width: 44px; 
      height: 44px; 
      border-radius: var(--radius-md); 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      flex-shrink: 0; 
    }
    .green-icon { 
      background: var(--primary-subtle); 
      color: var(--primary); 
      border: 1px solid rgba(15, 122, 92, 0.25); 
    }
    .pillar-card h3 { 
      font-size: 1.1rem; 
      font-weight: 700; 
      margin-bottom: 0.35rem; 
      color: var(--heading); 
    }
    .pillar-card p { 
      font-size: 0.875rem; 
      color: var(--text-muted); 
      line-height: 1.55; 
      margin: 0; 
    }

    .competency-card-full {
      padding: 2.25rem;
      border: 1.5px solid var(--primary);
      border-radius: var(--radius-xl);
      background: var(--bg-card);
      box-shadow: var(--shadow-lg), 0 0 25px rgba(15, 122, 92, 0.08);
    }
    .comp-head { 
      display: flex; 
      align-items: center; 
      gap: 1.1rem; 
      margin-bottom: 1.75rem; 
      padding-bottom: 1rem; 
      border-bottom: 1px dashed var(--border-color); 
    }
    .c-avatar-initials { 
      width: 58px; 
      height: 58px; 
      border-radius: 50%; 
      border: 2.5px solid var(--primary); 
      box-shadow: 0 4px 12px var(--primary-glow); 
      background: linear-gradient(135deg, #0F7A5C, #0B4F3C);
      color: #FFFFFF;
      font-weight: 800;
      font-size: 1.25rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .radar-bars { 
      display: flex; 
      flex-direction: column; 
      gap: 1.35rem; 
      margin-bottom: 1.75rem; 
    }
    .r-head { 
      display: flex; 
      justify-content: space-between; 
      font-size: 0.875rem; 
      font-weight: 700; 
      margin-bottom: 0.4rem; 
      color: var(--heading); 
    }
    .r-pts { 
      color: var(--primary); 
    }
    .r-bar { 
      height: 9px; 
      background: var(--bg-subtle); 
      border-radius: 9999px; 
      overflow: hidden; 
      border: 1px solid var(--border-color); 
    }
    .r-fill { 
      height: 100%; 
      background: var(--gradient-primary); 
      border-radius: 9999px; 
    }
    .rec-box { 
      background: var(--primary-subtle); 
      border: 1px solid rgba(15, 122, 92, 0.3); 
      border-radius: var(--radius-md); 
      padding: 1.15rem; 
    }
    .rec-title { 
      display: flex; 
      align-items: center; 
      gap: 0.45rem; 
      font-size: 0.825rem; 
      font-weight: 800; 
      color: var(--primary); 
      margin-bottom: 0.6rem; 
      letter-spacing: 0.5px; 
    }
    .rec-roles { 
      display: flex; 
      flex-direction: column; 
      gap: 0.35rem; 
      font-size: 0.875rem; 
      color: var(--heading); 
    }

    .margin-top-xl { margin-top: 4rem; }
    .cta-box { 
      background: var(--bg-card); 
      border: 1px solid var(--border-color); 
      border-radius: var(--radius-xl); 
      padding: 3.5rem 2rem; 
      box-shadow: var(--shadow-md); 
    }
    .cta-box h2 { 
      font-size: 2.1rem; 
      font-weight: 800; 
      margin-bottom: 1.75rem; 
      color: var(--heading); 
    }
    .cta-btns { 
      display: flex; 
      justify-content: center; 
      gap: 1.25rem; 
      flex-wrap: wrap; 
    }

    @media (max-width: 900px) {
      .fresher-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class FresherModelComponent { }

