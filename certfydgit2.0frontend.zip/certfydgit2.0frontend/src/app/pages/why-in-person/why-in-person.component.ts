import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from '../../shared/components/navbar/navbar.component';
import { FooterComponent } from '../../shared/components/footer/footer.component';

@Component({
  selector: 'app-why-in-person',
  standalone: true,
  imports: [CommonModule, RouterModule, NavbarComponent, FooterComponent],
  template: `
    <app-navbar></app-navbar>

    <main class="page-container">
      <!-- Header Banner -->
      <section class="page-banner">
        <div class="container text-center">
          <span class="badge badge-gold-banner">The Anti-Cheat Standard</span>
          <h1 class="page-title">Why Physical In-Person Verification Wins</h1>
          <p class="page-subtitle">
            Online proctoring has failed. Discover why high-stakes physical examination infrastructure is the only cheat-proof hiring signal.
          </p>
        </div>
      </section>

      <!-- Main Comparison Content -->
      <section class="section-padding">
        <div class="container">
          
          <div class="comparison-detailed-grid">
            
            <!-- Traditional Remote Online Proctoring -->
            <div class="card-col old-col deservify-card">
              <div class="tag red-tag">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                <span>Online Remote Proctoring</span>
              </div>
              <h2>Broken & Vulnerable to AI Relays</h2>
              <p class="desc">Webcam-based proctoring software only monitors a single camera angle. It is fundamentally incapable of preventing modern proxy cheating methods.</p>

              <div class="vulnerability-list">
                <div class="v-item">
                  <h4>1. Second Screen & HDMI Hardware Relays</h4>
                  <p>External splitters feed test questions to a second laptop where an expert or LLM solves the test in real time.</p>
                </div>
                <div class="v-item">
                  <h4>2. Hidden Proxy Test-Takers</h4>
                  <p>In-person proxies sit just off-camera operating remote keyboards or earpieces to dictate correct answers.</p>
                </div>
                <div class="v-item">
                  <h4>3. Resume Inflation & Fake Certificates</h4>
                  <p>Up to 60% of applicants exaggerate or completely fabricate project experience, causing massive interview churn.</p>
                </div>
                <div class="v-item">
                  <h4>4. 15+ Wasted Engineering Hours Per Hire</h4>
                  <p>Senior developers spend hundreds of hours interviewing candidates who passed online tests but cannot code.</p>
                </div>
              </div>
            </div>

            <!-- Proveyu Physical Supervision -->
            <div class="card-col new-col deservify-card">
              <div class="tag green-tag">
                <span>The Proveyu Physical Standard</span>
              </div>
              <h2>Invigilated In-Person Exam Labs</h2>
              <p class="desc">Proveyu partners with national exam infrastructure (TCS iON / JEE test centres) with physical invigilator oversight and biometric entry control.</p>

              <div class="security-list">
                <div class="s-item">
                  <h4>1. Biometric Fingerprint & Govt ID Check</h4>
                  <p>Candidates must present original physical Govt photo IDs and undergo fingerprint scans at the hall entry gate.</p>
                </div>
                <div class="s-item">
                  <h4>2. Air-Gapped Test Terminals & CCTV Audit</h4>
                  <p>Tests are administered on locked-down lab machines with external USB block, webcam proctoring, and human invigilator patrolling.</p>
                </div>
                <div class="s-item">
                  <h4>3. Multi-Dimensional Skill Passport</h4>
                  <p>Provides granular competency ratings across algorithms, QA, backend, and debugging rather than a simple pass/fail mark.</p>
                </div>
                <div class="s-item">
                  <h4>4. Direct Fast-Track Technical Interviews</h4>
                  <p>Recruiters skip initial screening tests entirely, saving 18+ engineering hours per hired developer.</p>
                </div>
              </div>
            </div>

          </div>

          <!-- Bottom CTA -->
          <div class="bottom-cta-card text-center margin-top-xl">
            <h2>Experience Un-Cheatable Skill Signal Today</h2>
            <div class="cta-flex">
              <a routerLink="/register/candidate" class="btn btn-lg btn-primary">
                <span>Register for Verification</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </a>
              <a routerLink="/register/recruiter" class="btn btn-lg btn-secondary">
                <span>Partner as Recruiter / Agency</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              </a>
            </div>
          </div>

        </div>
      </section>
    </main>

    <app-footer></app-footer>
  `,
  styles: [`
    .page-banner {
      background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
      color: #FFFFFF;
      padding: 4.5rem 0;
      position: relative;
    }
    .badge-gold-banner {
      background: rgba(217, 119, 6, 0.2);
      color: #FBBF24;
      border: 1px solid rgba(245, 158, 11, 0.35);
    }
    .page-title {
      font-size: 2.85rem;
      font-weight: 800;
      color: #FFFFFF;
      margin: 0.85rem 0;
      letter-spacing: -0.02em;
    }
    .page-subtitle {
      font-size: 1.15rem;
      color: #94A3B8;
      max-width: 680px;
      margin: 0 auto;
      line-height: 1.65;
    }
    .section-padding {
      padding: 4.5rem 0 6rem 0;
      background: var(--bg-subtle);
    }
    .comparison-detailed-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2.25rem;
    }
    .card-col {
      padding: 2.5rem;
      border-radius: var(--radius-xl);
      background: var(--bg-card);
      transition: all var(--transition-normal);
    }
    .old-col {
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-sm);
    }
    .old-col:hover {
      box-shadow: var(--shadow-md);
      border-color: #CBD5E1;
    }
    .new-col {
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow-sm);
    }
    .new-col:hover {
      box-shadow: var(--shadow-md);
      border-color: var(--primary);
    }
    .tag {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      padding: 0.45rem 0.95rem;
      border-radius: 6px;
      margin-bottom: 1.15rem;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }
    .red-tag {
      background: rgba(239, 68, 68, 0.07);
      color: #991B1B;
      border: 1px solid rgba(239, 68, 68, 0.25);
      border-left: 3.5px solid #DC2626;
    }
    .green-tag {
      background: rgba(15, 122, 92, 0.07);
      color: #0B4F3C;
      border: 1px solid rgba(15, 122, 92, 0.25);
      border-left: 3.5px solid #0F7A5C;
    }
    
    .card-col h2 { font-size: 1.75rem; font-weight: 800; margin-bottom: 0.6rem; color: var(--heading); }
    .card-col .desc { font-size: 1rem; color: var(--text-muted); margin-bottom: 1.75rem; line-height: 1.6; }
    
    .vulnerability-list, .security-list {
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }
    .v-item, .s-item {
      background: var(--bg-subtle);
      padding: 1.25rem;
      border-radius: var(--radius-lg);
      border: 1px solid var(--border-color);
      transition: all var(--transition-fast);
    }
    .v-item:hover, .s-item:hover {
      border-color: #CBD5E1;
      transform: translateY(-1px);
    }
    .v-head, .s-head {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 0.4rem;
    }
    .v-icon-box, .s-icon-box {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .red-icon { background: #FEE2E2; color: #DC2626; }
    .green-icon { background: var(--primary-subtle); color: var(--primary); }

    .v-item h4 { color: #DC2626; font-size: 0.975rem; font-weight: 700; margin: 0; }
    .s-item h4 { color: var(--heading); font-size: 0.975rem; font-weight: 700; margin: 0; }
    .v-item p, .s-item p { font-size: 0.875rem; color: var(--text-muted); line-height: 1.55; margin: 0; }

    .margin-top-xl { margin-top: 4rem; }
    .bottom-cta-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-xl);
      padding: 3.5rem 2rem;
      box-shadow: var(--shadow-md);
    }
    .bottom-cta-card h2 { font-size: 2.1rem; font-weight: 800; margin-bottom: 1.75rem; color: var(--heading); }
    .cta-flex { display: flex; justify-content: center; gap: 1.25rem; flex-wrap: wrap; }

    @media (max-width: 850px) {
      .comparison-detailed-grid { grid-template-columns: 1fr; }
    }
  `]
})
export class WhyInPersonComponent { }

